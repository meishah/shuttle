# Shuttle

A lightweight Android VPN client for OpenVPN, WireGuard and AmneziaWG.

## Features

- **OpenVPN** — import `.ovpn` files (single file or ZIP), saved username/password
- **WireGuard & AmneziaWG** — full Amnezia settings (Mimic QUIC/DNS/SIP, junk packets)
- **Kill switch**, auto-connect and auto-reconnect
- **Config groups** — custom names, reorderable, shown on the home screen
- **Ping & sort** — ping servers from the list, sort by lowest ping
- **Per-app VPN** — choose which apps use the tunnel
- **Quick Settings tile** and home-screen widget for connect/disconnect
- **Backup & export** — configs as a ZIP file, manual in-app editing
- **Connection log** for troubleshooting
- **Themes** — light, dark, auto; **languages** — English and Persian
- Designed for efficient background operation; permissions are requested only where required. Supports 64-bit and 32-bit ARM devices.

## Download

Get the latest APK from [Releases](https://github.com/meishah/shuttle/releases) — three variants:

| Variant | For |
|---|---|
| `universal` | Any device |
| `arm64-v8a` | Most modern phones (64-bit ARM) |
| `armeabi-v7a` | Older phones (32-bit ARM) |

## Screenshots

![Home — connected](screenshots/home-connected.jpg)
![Home — disconnected](screenshots/home-disconnected.jpg)
![Settings](screenshots/settings.jpg)

## Usage

1. Install the APK and import your configs (`+` → import file or ZIP).
2. Tap **Ping servers** to measure latency, then tap a config tile to connect; tap it again to disconnect.
3. Tap the **⋮** menu beside a config for Pin, Share, Edit, Rename, Move to group, Ping or Delete.
4. Long-press a group chip to reorder, rename or delete the group.

## Build from source

```bash
./build.sh assembleStandaloneRelease
```

Requires JDK 21 and the Android SDK (API 37).

## Credits, third-party components & licensing

Shuttle incorporates code and components from [WG Tunnel](https://github.com/wgtunnel/android), [ics-openvpn](https://github.com/schwabe/ics-openvpn), and other third-party libraries. Their respective copyright notices and license terms remain applicable to those components.

The repository-root `LICENSE` file contains the MIT License notice from the upstream project; it must not be read as relicensing third-party components. In particular, the OpenVPN component has its own GPL-family licensing terms and notices. Before redistributing modified source or binaries, review the license and notice files included with each component and preserve all required notices. The project should be treated as containing multiple licenses, not as uniformly MIT- or GPL-licensed, unless a complete rights and provenance review establishes otherwise.
