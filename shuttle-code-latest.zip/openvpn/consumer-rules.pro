# Shuttle :openvpn module — keeps R8 needs for the vendored ics-openvpn core.
# OpenVPNThreadv3 is loaded by reflection (Class.forName) from OpenVPNService.
-keep class de.blinkt.openvpn.core.OpenVPNThreadv3 { *; }
# SWIG-generated OpenVPN 3 bindings: method/class names must match libovpn3.so exactly.
-keep class net.openvpn.ovpn3.** { *; }
# JNI entry points (NativeUtils native methods bound by name).
-keepclasseswithmembernames class * { native <methods>; }
# VpnService + AIDL stubs referenced from the manifest / by Binder.
-keep class de.blinkt.openvpn.core.OpenVPNService { *; }
-keep class de.blinkt.openvpn.core.IOpenVPNServiceInternal$Stub { *; }
-keep class de.blinkt.openvpn.core.IServiceStatus$Stub { *; }
-keep class de.blinkt.openvpn.core.IStatusCallbacks$Stub { *; }
