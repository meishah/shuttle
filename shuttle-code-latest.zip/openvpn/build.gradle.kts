plugins { alias(libs.plugins.androidLibrary) }

android {
    // Vendored ics-openvpn (0.7.69) OpenVPN core, namespace kept as
    // de.blinkt.openvpn so the JNI bindings (Java_de_blinkt_openvpn_*)
    // and the AIDL-generated stubs resolve.
    namespace = "de.blinkt.openvpn"
    compileSdk {
        version =
            release(libs.versions.compileSdk.get().toInt()) {
                minorApiLevel = libs.versions.compileSdkMinor.get().toInt()
            }
    }

    compileOptions {
        // ics-openvpn 0.7.69 uses switch expressions/rules (Java 14+).
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { buildConfig = true }

    defaultConfig {
        minSdk = libs.versions.minSdk.get().toInt()
        // Fields ics-openvpn's main module defines via buildConfigField;
        // the vendored core code reads them.
        buildConfigField("boolean", "openvpn3", "true")
        buildConfigField("String", "FLAVOR", "\"\"")
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation("androidx.annotation:annotation:1.9.1")
    // VpnProfile uses org.spongycastle (PEM export of certificates)
    implementation("com.madgag.spongycastle:core:1.58.0.0")
    // ProfileEncryption uses EncryptedFile/MasterKey (AndroidKeyStore)
    implementation("androidx.security:security-crypto:1.1.0")
}
