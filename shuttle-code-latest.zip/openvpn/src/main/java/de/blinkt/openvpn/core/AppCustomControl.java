/*
 * Copyright (c) 2012-2026 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Converted from Kotlin to Java for the Shuttle build (the :openvpn
 * module has no Kotlin plugin; behaviour is identical).
 * AccMessage and DPC1Protocol live in their own top-level files,
 * as they did in the original .kt file.
 */

package de.blinkt.openvpn.core;

import java.util.Base64;

public class AppCustomControl {

    public static AccMessage parseAccMessage(String argument) {
        // dpc1,0,eyJkcGNfcmVxdW...
        String[] arguments = argument.split(",", 3);

        if (arguments.length < 3)
            throw new IllegalArgumentException("Malformed ACC management message");

        String protocol = arguments[0];
        String b64message = arguments[2];

        boolean fragment = arguments[1].equals("1");

        byte[] message = Base64.getDecoder().decode(b64message);

        return new AccMessage(protocol, fragment, message);
    }
}
