/*
 * Shuttle bridge to the vendored ics-openvpn core.
 *
 * Lives in de.blinkt.openvpn.core (same package as StatusListener) so it
 * can call StatusListener.init(), which is package-private. Shuttle's
 * Application calls init() once at startup; this is the equivalent of
 * ics-openvpn's ICSOpenVPNApplication.onCreate() minus the parts Shuttle
 * does not need (first-launch prefs, AppRestrictions, StrictMode).
 *
 * It also keeps the latest OpenVPN connection state (from VpnStatus
 * callbacks) so Shuttle's UI can observe it without binding to the
 * :openvpn process itself, and offers stop/setCachedPassword helpers
 * that bind to OpenVPNService/OpenVPNStatusService on demand.
 *
 * Connected-state rule: Shuttle's UI must treat the tunnel as connected
 * ONLY when level == LEVEL_CONNECTED. The bridge exposes the raw level;
 * it never synthesises a "connected" state.
 */

package de.blinkt.openvpn.core;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;

import androidx.annotation.NonNull;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import de.blinkt.openvpn.R;

public class ShuttleOpenVpn {

    /** Listener for OpenVPN state changes, called on VpnStatus's thread. */
    public interface StateListener {
        void onStateChanged(@NonNull State state);
    }

    /** Immutable snapshot of the OpenVPN tunnel state. */
    public static final class State {
        public final String state;
        public final ConnectionStatus level;
        public final String message;
        public final long bytesIn;
        public final long bytesOut;
        public final String connectedUuid;

        public State(String state, ConnectionStatus level, String message,
                     long bytesIn, long bytesOut, String connectedUuid) {
            this.state = state;
            this.level = level;
            this.message = message;
            this.bytesIn = bytesIn;
            this.bytesOut = bytesOut;
            this.connectedUuid = connectedUuid;
        }

        /** True only when the tunnel is genuinely up. */
        public boolean isConnected() {
            return level == ConnectionStatus.LEVEL_CONNECTED;
        }
    }

    private static final List<StateListener> listeners = new CopyOnWriteArrayList<>();
    private static volatile State currentState = new State(
            "NOPROCESS", ConnectionStatus.LEVEL_NOTCONNECTED, "", 0, 0, null);
    private static volatile long lastBytesIn = 0;
    private static volatile long lastBytesOut = 0;
    private static volatile boolean initialized = false;

    private static final VpnStatus.StateListener vpnStatusListener =
            new VpnStatus.StateListener() {
                @Override
                public void updateState(String state, String logmessage, int localizedResId,
                                        ConnectionStatus level, Intent intent) {
                    currentState = new State(state, level, logmessage,
                            lastBytesIn, lastBytesOut,
                            VpnStatus.getLastConnectedVPNProfile());
                    for (StateListener l : listeners) {
                        l.onStateChanged(currentState);
                    }
                }

                @Override
                public void setConnectedVPN(String uuid) {
                    currentState = new State(currentState.state, currentState.level,
                            currentState.message, lastBytesIn, lastBytesOut, uuid);
                    for (StateListener l : listeners) {
                        l.onStateChanged(currentState);
                    }
                }
            };

    private static final VpnStatus.ByteCountListener byteCountListener =
            (in, out, diffIn, diffOut) -> {
                lastBytesIn = in;
                lastBytesOut = out;
            };

    /** Call once from Shuttle's Application.onCreate(). Safe to call twice. */
    public static synchronized void init(Context appContext) {
        if (initialized) return;
        initialized = true;
        // Shuttle fix8: GlobalPreferences was never initialised in
        // either process (the vendored core lost upstream's
        // AppRestrictions init) — see the lazy default in
        // GlobalPreferences.getInstance(). Set the explicit defaults
        // here too, in both processes.
        GlobalPreferences.setInstance(false, false, false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannels(appContext);
        }
        VpnStatus.addStateListener(vpnStatusListener);
        VpnStatus.addByteCountListener(byteCountListener);
        new StatusListener().init(appContext);
    }

    public static void addStateListener(StateListener listener) {
        listeners.add(listener);
        listener.onStateChanged(currentState);
    }

    public static void removeStateListener(StateListener listener) {
        listeners.remove(listener);
    }

    public static State getCurrentState() {
        return currentState;
    }

    public static boolean isVpnActive() {
        return VpnStatus.isVPNActive();
    }

    /** Log lines buffered in the UI process (forwarded from :openvpn). */
    public static LogItem[] getLogBuffer() {
        return VpnStatus.getlogbuffer();
    }

    /** Disconnect the running OpenVPN tunnel, if any. No-op when idle. */
    public static void stopVpn(final Context context) {
        Intent intent = new Intent(context, OpenVPNService.class);
        intent.setAction(OpenVPNService.START_SERVICE);
        final ServiceConnection connection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                try {
                    IOpenVPNServiceInternal.Stub.asInterface(service).stopVPN(false);
                } catch (RemoteException ignored) {
                } finally {
                    try {
                        context.unbindService(this);
                    } catch (IllegalArgumentException ignored) {
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
            }
        };
        try {
            context.bindService(intent, connection, Context.BIND_AUTO_CREATE);
        } catch (Exception ignored) {
            // Service not running — nothing to stop.
        }
    }

    /**
     * Deliver a password to the :openvpn process (for the mid-connection
     * "user input" prompt). The management thread reads it via
     * PasswordCache once the user has supplied it.
     */
    public static void setCachedPassword(final Context context, final String uuid,
                                         final int type, final String password) {
        Intent intent = new Intent(context, OpenVPNStatusService.class);
        intent.setAction(OpenVPNService.START_SERVICE);
        final ServiceConnection connection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                try {
                    IServiceStatus.Stub.asInterface(service)
                            .setCachedPassword(uuid, type, password);
                } catch (RemoteException ignored) {
                } finally {
                    try {
                        context.unbindService(this);
                    } catch (IllegalArgumentException ignored) {
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
            }
        };
        try {
            context.bindService(intent, connection, Context.BIND_AUTO_CREATE);
        } catch (Exception ignored) {
        }
    }

    private static void createNotificationChannels(Context context) {
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        NotificationChannel bg = new NotificationChannel(
                OpenVPNService.NOTIFICATION_CHANNEL_BG_ID,
                context.getString(R.string.channel_name_background),
                NotificationManager.IMPORTANCE_MIN);
        bg.setDescription(context.getString(R.string.channel_description_background));
        bg.enableLights(false);
        bg.setLightColor(Color.DKGRAY);
        manager.createNotificationChannel(bg);

        NotificationChannel status = new NotificationChannel(
                OpenVPNService.NOTIFICATION_CHANNEL_NEWSTATUS_ID,
                context.getString(R.string.channel_name_status),
                NotificationManager.IMPORTANCE_LOW);
        status.setDescription(context.getString(R.string.channel_description_status));
        status.enableLights(true);
        status.setLightColor(Color.BLUE);
        manager.createNotificationChannel(status);

        NotificationChannel userReq = new NotificationChannel(
                OpenVPNService.NOTIFICATION_CHANNEL_USERREQ_ID,
                context.getString(R.string.channel_name_userreq),
                NotificationManager.IMPORTANCE_HIGH);
        userReq.setDescription(context.getString(R.string.channel_description_userreq));
        userReq.enableVibration(true);
        userReq.setLightColor(Color.CYAN);
        manager.createNotificationChannel(userReq);
    }
}
