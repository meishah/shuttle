# AIDL-generated stubs

AGP 9 removed AIDL compilation, so the Binder interfaces for the
vendored ics-openvpn core are pre-generated with the aidl compiler
from build-tools 37.0.0 and committed here as regular Java sources:

    aidl --lang=java -I src/main/aidl -I <framework stubs> -o <out> <file>.aidl

Framework parcelables (android.content.Intent, android.os.Bundle)
were resolved with minimal stub .aidl files (parcelable declarations).
The .aidl sources are kept in src/main/aidl for reference; the
generated .java files in this tree are what actually compiles.
Files: IOpenVPNServiceInternal, IServiceStatus, IStatusCallbacks,
ExternalCertificateProvider. (LogItem/ConnectionStatus/TrafficHistory
are parcelable declarations — implemented by the real Java classes.)
