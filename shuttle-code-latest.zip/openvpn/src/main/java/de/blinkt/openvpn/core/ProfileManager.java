/*
 * Copyright (c) 2012-2016 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 */

package de.blinkt.openvpn.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.security.GeneralSecurityException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.Vector;

import de.blinkt.openvpn.VpnProfile;

public class ProfileManager {
    private static final String PREFS_NAME = "VPNList";

    private static final String LAST_CONNECTED_PROFILE = "lastConnectedProfile";
    private static final String TEMPORARY_PROFILE_FILENAME = "temporary-vpn-profile";
    private static ProfileManager instance;

    private static VpnProfile mLastConnectedVpn = null;
    private static VpnProfile tmpprofile = null;
    private HashMap<String, VpnProfile> profiles = new HashMap<>();
    /* We got an error trying to save profiles, do not try encryption anymore */
    private static boolean encryptionBroken = false;

    /* UUIDs whose stored profile file proved permanently unreadable
     * (InvalidClassException / ClassNotFoundException /
     * StreamCorruptedException — e.g. the class name in the stream was
     * obfuscated differently by the build that wrote it). The file is
     * deleted on first sight and the UUID is never retried: re-reading
     * it on every load / every connect only spams the log and stalls
     * get() in its retry loop. The user's config itself is safe — the
     * app DB still holds the .ovpn text and rebuilds the profile from
     * it. Never mark a UUID corrupt for a transient failure
     * (GeneralSecurityException / plain IOException): the file is kept
     * and retried in that case. */
    private static final Set<String> corruptUuids =
            Collections.synchronizedSet(new HashSet<>());

    /** True when the stored profile for [uuid] proved permanently unreadable. */
    public static boolean isCorruptProfile(String uuid) {
        return uuid != null && corruptUuids.contains(uuid);
    }

    /**
     * Discard a profile whose stored file can never be read again:
     * remove it from the in-memory map, delete every stored variant
     * (.vp / .cp / .cpold), drop the UUID from the persisted vpnlist
     * and remember it as corrupt so get() stops retrying it. Only for
     * permanently-unreadable entries — never for a transient load
     * failure. This touches ONLY the internal ics-openvpn profile
     * files; the user's configs in the app DB are untouched.
     */
    public static void discardUnreadableProfile(Context context, String uuid) {
        if (uuid == null) return;
        pruneCorruptEntry(context, uuid);
    }

    private static void pruneCorruptEntry(Context context, String uuid) {
        corruptUuids.add(uuid);
        if (instance != null) {
            instance.profiles.remove(uuid);
        }
        if (uuid.equals(TEMPORARY_PROFILE_FILENAME)) {
            tmpprofile = null;
        }
        for (String ext : new String[]{".vp", ".cp", ".cpold"}) {
            context.deleteFile(uuid + ext);
        }
        // Drop the UUID from the persisted vpnlist so later loads do
        // not even try it. (Do NOT use saveProfileList() here: during
        // loadVPNList the in-memory map is still being rebuilt, and
        // persisting it mid-load would drop not-yet-loaded profiles.)
        // Never let a prefs failure escape: pruning runs inside the
        // load-failure handlers, and a throw here would turn a
        // handled corrupt entry into a crash.
        try {
            SharedPreferences listpref = Preferences.getSharedPreferencesMulti(PREFS_NAME, context);
            Set<String> vlist = listpref.getStringSet("vpnlist", null);
            if (vlist != null && vlist.contains(uuid)) {
                Set<String> pruned = new HashSet<>(vlist);
                pruned.remove(uuid);
                listpref.edit().putStringSet("vpnlist", pruned).commit();
            }
        } catch (RuntimeException e) {
            VpnStatus.logException("Dropping corrupt profile from vpnlist", e);
        }
    }

    private ProfileManager() {
    }

    private static VpnProfile get(String key) {
        if (tmpprofile != null && tmpprofile.getUUIDString().equals(key))
            return tmpprofile;

        if (instance == null)
            return null;
        return instance.profiles.get(key);
    }

    private synchronized static void checkInstance(Context context) {
        if (instance == null) {
            instance = new ProfileManager();
            ProfileEncryption.initMasterCryptAlias(context);
            instance.loadVPNList(context);
        }
    }

    synchronized public static ProfileManager getInstance(Context context) {
        checkInstance(context);
        return instance;
    }

    public static void setConnectedVpnProfileDisconnected(Context c) {
        SharedPreferences prefs = Preferences.getDefaultSharedPreferences(c);
        Editor prefsedit = prefs.edit();
        prefsedit.putString(LAST_CONNECTED_PROFILE, null);
        prefsedit.apply();
    }

    /**
     * Sets the profile that is connected (to connect if the service restarts)
     */
    public static void setConnectedVpnProfile(Context c, VpnProfile connectedProfile) {
        SharedPreferences prefs = Preferences.getDefaultSharedPreferences(c);
        Editor prefsedit = prefs.edit();

        prefsedit.putString(LAST_CONNECTED_PROFILE, connectedProfile.getUUIDString());
        prefsedit.apply();
        mLastConnectedVpn = connectedProfile;
    }

    /**
     * Returns the profile that was last connected (to connect if the service restarts)
     */
    public static VpnProfile getLastConnectedProfile(Context c) {
        SharedPreferences prefs = Preferences.getDefaultSharedPreferences(c);

        String lastConnectedProfile = prefs.getString(LAST_CONNECTED_PROFILE, null);
        if (lastConnectedProfile != null)
            return get(c, lastConnectedProfile);
        else
            return null;
    }

    public static void setTemporaryProfile(Context c, VpnProfile tmp) {
        tmp.mTemporaryProfile = true;
        ProfileManager.tmpprofile = tmp;
        tmp.addChangeLogEntry("temporary profile saved");
        saveProfile(c, tmp);
    }

    public static boolean isTempProfile() {
        return mLastConnectedVpn != null && mLastConnectedVpn == tmpprofile;
    }

    public static void saveProfile(Context context, VpnProfile profile) {
        SharedPreferences prefs = Preferences.getDefaultSharedPreferences(context);
        boolean preferEncryption = prefs.getBoolean("preferencryption", true);
        if (encryptionBroken)
            preferEncryption = false;

        profile.mVersion += 1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            profile.addChangeLogEntry("Saving from version " + profile.mVersion +
                    " from process " + Application.getProcessName());
        }
        ObjectOutputStream vpnFile;

        String filename = profile.getUUID().toString();

        if (profile.mTemporaryProfile)
            filename = TEMPORARY_PROFILE_FILENAME;

        File encryptedFileOld = context.getFileStreamPath(filename + ".cpold");

        if (encryptedFileOld.exists())
        {
            encryptedFileOld.delete();
        }

        String deleteIfExists;
        try {
            FileOutputStream vpnFileOut;
            if (preferEncryption && ProfileEncryption.encryptionEnabled()) {
                File encryptedFile = context.getFileStreamPath(filename + ".cp");

                if (encryptedFile.exists())
                {
                    if (!encryptedFile.renameTo(encryptedFileOld))
                    {
                        VpnStatus.logInfo("Cannot rename " + encryptedFile);
                    }
                }
                try {
                    vpnFileOut = ProfileEncryption.getEncryptedVpOutput(context, encryptedFile);
                    deleteIfExists = filename + ".vp";
                    if (encryptedFileOld.exists()) {
                        encryptedFileOld.delete();
                    }
                } catch (IOException | GeneralSecurityException ioe)
                {
                    VpnStatus.logException(VpnStatus.LogLevel.INFO, "Error trying to write an encrypted VPN profile, disabling " +
                            "encryption", ioe);
                    encryptionBroken = true;
                    saveProfile(context, profile);
                    return;
                }
            }
            else {
                vpnFileOut = context.openFileOutput(filename + ".vp", Activity.MODE_PRIVATE);
                deleteIfExists = filename + ".cp";
            }

            vpnFile = new ObjectOutputStream(vpnFileOut);

            vpnFile.writeObject(profile);
            vpnFile.flush();
            vpnFile.close();

            File delete = context.getFileStreamPath(deleteIfExists);
            if (delete.exists())
            {
                //noinspection ResultOfMethodCallIgnored
                delete.delete();
            }
            // Register the profile in the in-memory list and persist the
            // UUID list. Without this, ProfileManager.get() can never find
            // a profile that was only just saved: get() rebuilds the map
            // from the persisted "vpnlist" set, and this UUID was never
            // added to it. That was the cause of every OpenVPN connect
            // failing with "LaunchVPN: profile not found" even though the
            // profile file existed on disk.
            if (!profile.mTemporaryProfile) {
                checkInstance(context);
                instance.addProfile(profile);
                instance.saveProfileList(context);
            }
            VpnStatus.notifyProfileVersionChanged(profile.getUUIDString(), profile.mVersion, true);
        } catch (IOException e) {
            VpnStatus.logException("saving VPN profile", e);
            throw new RuntimeException(e);
        }
    }

    public static VpnProfile get(Context context, String profileUUID) {
        return get(context, profileUUID, 0, 10);
    }

    public static VpnProfile get(Context context, String profileUUID, int version, int tries) {
        checkInstance(context);
        // Permanently unreadable (pruned on an earlier load): fail
        // fast instead of burning `tries` full list reloads on an
        // entry that can never come back. The caller rebuilds the
        // profile from the stored .ovpn text.
        if (profileUUID != null && corruptUuids.contains(profileUUID)) {
            VpnStatus.logError("Profile " + profileUUID + " is unreadable (corrupt serialized data); not retrying");
            return null;
        }
        VpnProfile profile = get(profileUUID);
        int tried = 0;
        while ((profile == null || profile.mVersion < version) && (tried++ < tries)) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ignored) {
            }
            instance.loadVPNList(context);
            profile = get(profileUUID);
            // The reload may have just pruned this UUID as corrupt —
            // stop immediately instead of looping on a dead entry.
            if (profile == null && profileUUID != null && corruptUuids.contains(profileUUID)) {
                break;
            }
        }

        if (tried > 5) {
            int ver = profile == null ? -1 : profile.mVersion;
            VpnStatus.logError(String.format(Locale.US, "Used x %d tries to get current version (%d/%d) of the profile", tried, ver, version));
        }

        if (profile == null) {
            // Heal profiles whose file exists on disk but whose UUID never
            // made it into the persisted "vpnlist" set (e.g. saved before
            // saveProfile registered new profiles): load the file directly
            // and persist the UUID, so this and later lookups find it.
            // This heals already-imported configs without a re-import.
            if (context.getFileStreamPath(profileUUID + ".vp").exists() ||
                context.getFileStreamPath(profileUUID + ".cp").exists() ||
                context.getFileStreamPath(profileUUID + ".cpold").exists()) {
                instance.loadVpnEntry(context, profileUUID);
                profile = get(profileUUID);
                if (profile != null) {
                    instance.saveProfileList(context);
                }
            }
        }
        return profile;
    }

    public static VpnProfile getLastConnectedVpn() {
        return mLastConnectedVpn;
    }

    public static VpnProfile getAlwaysOnVPN(Context context) {
        checkInstance(context);
        SharedPreferences prefs = Preferences.getDefaultSharedPreferences(context);

        String uuid = prefs.getString("alwaysOnVpn", null);
        return get(uuid);

    }

    public static void updateLRU(Context c, VpnProfile profile) {
        profile.mLastUsed = System.currentTimeMillis();
        // LRU does not change the profile, no need for the service to refresh
        if (profile != tmpprofile) {
            profile.addChangeLogEntry("Saved last recently used");
            saveProfile(c, profile);
        }
    }


    public static void notifyProfileVersionChanged(Context c, String uuid, int version) {
        /* The profile has been saved/modified. Potentially on the other process. We might need
         * to reload the profile from storage */

        VpnProfile loadedProfile = get(c, uuid, version, 100);
        if (loadedProfile != null & loadedProfile.mVersion >= version) {
            VpnStatus.notifyProfileVersionChanged(uuid, version, false);
        }
    }

    public Collection<VpnProfile> getProfiles() {
        return profiles.values();
    }

    public VpnProfile getProfileByName(String name) {
        for (VpnProfile vpnp : profiles.values()) {
            if (vpnp.getName().equals(name)) {
                return vpnp;
            }
        }
        return null;
    }

    public void saveProfileList(Context context) {
        SharedPreferences sharedprefs = Preferences.getSharedPreferencesMulti(PREFS_NAME, context);
        Editor editor = sharedprefs.edit();
        /* preference saving might be asynchronous*/
        final HashSet<String> vpn_list = new HashSet<>(profiles.keySet());
        editor.putStringSet("vpnlist", vpn_list);

        // For reasons I do not understand at all
        // Android saves my prefs file only one time
        // if I remove the debug code below :(
        int counter = sharedprefs.getInt("counter", 0);
        editor.putInt("counter", counter + 1);
        // commit(), not apply(): the :openvpn process reads this list from
        // disk when the service starts, and an async apply() may not have
        // flushed yet when it does. The list is tiny; the synchronous
        // write is cheap and guarantees the other process sees the UUID.
        editor.commit();
    }

    public synchronized void addProfile(VpnProfile profile) {
        profiles.put(profile.getUUID().toString(), profile);
    }

    /**
     * Checks if a profile has been added deleted since last loading and will update its
     * profiles
     * @param context
     */
    public synchronized void refreshVPNList(Context context)
    {
        SharedPreferences listpref = Preferences.getSharedPreferencesMulti(PREFS_NAME, context);
        Set<String> vlist = listpref.getStringSet("vpnlist", null);
        if (vlist == null)
            return;

        for (String vpnentry : vlist) {
            if (!profiles.containsKey(vpnentry))
                loadVpnEntry(context, vpnentry);
        }

        Vector<String> removeUuids = new Vector<>();
        for (String profileuuid:profiles.keySet())
        {
            if (!vlist.contains(profileuuid))
                removeUuids.add(profileuuid);
        }
        for (String uuid: removeUuids)
        {
            profiles.remove(uuid);
        }
    }

    private synchronized void loadVPNList(Context context) {
        profiles = new HashMap<>();
        SharedPreferences listpref = Preferences.getSharedPreferencesMulti(PREFS_NAME, context);
        Set<String> vlist = listpref.getStringSet("vpnlist", null);
        if (vlist == null) {
            vlist = new HashSet<>();
        }
        // Always try to load the temporary profile
        vlist.add(TEMPORARY_PROFILE_FILENAME);

        for (String vpnentry : vlist) {
            loadVpnEntry(context, vpnentry);
        }

        if (!listpref.getBoolean("didrecover", false))
        {
            recoverProfiles(context);
            Editor listprefedit = listpref.edit();
            listprefedit.putBoolean("didrecover", true);
            listprefedit.apply();
        }
    }

    private void recoverProfiles(Context context) {
        /* Recover profiles that were removed from the list by the 0.7.66 update that removed all of them because
         * of a broken optimisation */
        for (String file: context.fileList())
        {
            if (file.endsWith(".cp") || file.endsWith(".vp"))
            {
                String profileName = file.split("\\.")[0];

                if (!profiles.containsKey(profileName)) {
                    loadVpnEntry(context, profileName);
                }
            }

        }

    }

    private synchronized void loadVpnEntry(Context context, String vpnentry) {
        ObjectInputStream vpnfile = null;
        try {
            FileInputStream vpInput;
            File encryptedPath = context.getFileStreamPath(vpnentry + ".cp");
            File encryptedPathOld = context.getFileStreamPath(vpnentry + ".cpold");

            if (encryptedPath.exists()) {
                vpInput = ProfileEncryption.getEncryptedVpInput(context, encryptedPath);
            } else if (encryptedPathOld.exists()) {
                vpInput = ProfileEncryption.getEncryptedVpInput(context, encryptedPathOld);
            } else {
                vpInput = context.openFileInput(vpnentry + ".vp");
            }
            vpnfile = new ObjectInputStream(vpInput);
            VpnProfile vp = ((VpnProfile) vpnfile.readObject());

            // Sanity check
            if (vp == null || vp.mName == null || vp.getUUID() == null)
                return;

            vp.upgradeProfile();
            if (vpnentry.equals(TEMPORARY_PROFILE_FILENAME)) {
                tmpprofile = vp;
            } else {
                profiles.put(vp.getUUID().toString(), vp);
            }
        } catch (InvalidClassException | ClassNotFoundException | StreamCorruptedException | EOFException | OptionalDataException e) {
            // Permanent: the bytes can never be read by this build
            // (the class name in the stream was obfuscated differently
            // by the build that wrote it — e.g. "oa7" vs "ra7" — or
            // the file is truncated/corrupt). Drop the entry now so
            // it is never retried: delete the unreadable file(s) and
            // forget the UUID. The user's config is safe — the app DB
            // still holds the .ovpn text and rebuilds the profile
            // from it on connect. (EOFException is an IOException but
            // belongs here, not in the keep-the-file branch below: a
            // truncated stream can never become readable later.)
            if (!vpnentry.equals(TEMPORARY_PROFILE_FILENAME)) {
                VpnStatus.logException("Loading VPN List:" + vpnentry, e);
                pruneCorruptEntry(context, vpnentry);
            }
        } catch (GeneralSecurityException e) {
            // Transient (Keystore locked, key unavailable, ...): keep
            // the file — it may read fine later. Never prune here.
            if (!vpnentry.equals(TEMPORARY_PROFILE_FILENAME))
                VpnStatus.logException("Loading VPN List:" + vpnentry, e);
        } catch (IOException e) {
            // Other I/O (file vanished mid-read, ...): keep the file.
            if (!vpnentry.equals(TEMPORARY_PROFILE_FILENAME))
                VpnStatus.logException("Loading VPN List:" + vpnentry, e);
        } catch (RuntimeException e) {
            // Fix8: anything else that escapes the load (e.g. a
            // ClassCastException when the stream holds a different
            // object, or an upgrade failure) must NEVER kill the
            // process — this file is only the internal serialized
            // cache; the app DB rebuilds the profile. Prune it like
            // any other permanently unreadable entry.
            if (!vpnentry.equals(TEMPORARY_PROFILE_FILENAME)) {
                VpnStatus.logException("Loading VPN List:" + vpnentry, e);
                pruneCorruptEntry(context, vpnentry);
            }
        } finally {
            if (vpnfile != null) {
                try {
                    vpnfile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public synchronized void removeProfile(Context context, VpnProfile profile) {
        String vpnentry = profile.getUUID().toString();
        profiles.remove(vpnentry);
        saveProfileList(context);


        // delete both unencrypted and encrypted variants
        String[] extensions = new String[]{".vp", ".cp", ".cpold"};
        for (String ext: extensions)
            context.deleteFile(vpnentry + ext);

        if (mLastConnectedVpn == profile)
            mLastConnectedVpn = null;

    }
}
