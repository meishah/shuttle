/*
 * Copyright (c) 2012-2016 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Minimal replacement for ics-openvpn's ConfirmDialog activity, for
 * the Shuttle build. The original asked the user to confirm granting
 * an external app access to control OpenVPN. Shuttle does not expose
 * the external OpenVPN API, so this path is never expected to run;
 * the stub simply denies (finishes without a result) if it ever is.
 */

package de.blinkt.openvpn.api;

import android.app.Activity;
import android.os.Bundle;

public class ConfirmDialog extends Activity {
    public static final String EXTRA_PACKAGE_NAME = "android.intent.extra.PACKAGE_NAME";
    public static final String ANONYMOUS_PACKAGE = "de.blinkt.openvpn.ANYPACKAGE";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        finish();
    }
}
