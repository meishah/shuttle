/*
 * Copyright (c) 2012-2016 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 */

package de.blinkt.openvpn.core;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.RequiresApi;

import de.blinkt.openvpn.BuildConfig;
import de.blinkt.openvpn.R;
import de.blinkt.openvpn.core.VpnStatus.LogLevel;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by arne on 09.11.16.
 */

public class StatusListener implements VpnStatus.LogListener, VpnStatus.ProfileNotifyListener {
    private final IStatusCallbacks mCallback = new IStatusCallbacks.Stub() {
        @Override
        public void newLogItem(LogItem item) throws RemoteException {
            VpnStatus.newLogItem(item);
        }

        @Override
        public void updateStateString(String state, String msg, int resid, ConnectionStatus
                level, Intent intent) throws RemoteException {
            Intent newIntent = reCreateIntent(intent);
            VpnStatus.updateStateString(state, msg, resid, level, newIntent);
        }

        private Intent reCreateIntent(Intent intent) {
            /* To avoid UnsafeIntentLaunchViolation we recreate the intent that we passed
             * to ourselves via the AIDL interface */
            if (intent == null)
                return null;
            Intent newIntent = new Intent(intent.getAction(), intent.getData());
            if (intent.getExtras() != null)
                newIntent.putExtras(intent.getExtras());
            return newIntent;
        }

        @Override
        public void updateByteCount(long inBytes, long outBytes) throws RemoteException {
            VpnStatus.updateByteCount(inBytes, outBytes);
        }

        @Override
        public void connectedVPN(String uuid) throws RemoteException {
            VpnStatus.setConnectedVPNProfile(uuid);
        }

        @Override
        public void notifyProfileVersionChanged(String uuid, int version) throws RemoteException {
            ProfileManager.notifyProfileVersionChanged(mContext, uuid, version);

        }
    };
    private File mCacheDir;
    private final StatusServiceConnection mConnection = new StatusServiceConnection();

    final class StatusServiceConnection implements ServiceConnection {
        public IServiceStatus serviceStatus = null;
        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            serviceStatus = IServiceStatus.Stub.asInterface(service);
            try {
                /* Check if this a local service ... */
                if (service.queryLocalInterface("de.blinkt.openvpn.core.IServiceStatus") == null) {
                    // Not a local service
                    VpnStatus.setConnectedVPNProfile(serviceStatus.getLastConnectedVPN());
                    VpnStatus.setTrafficHistory(serviceStatus.getTrafficHistory());
                    ParcelFileDescriptor pfd = serviceStatus.registerStatusCallback(mCallback);

                    /* notify the backend :openvpn process of changes in profiles */
                    VpnStatus.addProfileStateListener(StatusListener.this);

                    // Shuttle fix8: the log-cache drain below is
                    // BLOCKING pipe I/O (readShort/readFully wait for
                    // the :openvpn process to write). It used to run
                    // right here, on the MAIN thread — ServiceConnection
                    // callbacks run on the main thread — so while the
                    // service process was slow to start, dying, or
                    // restarting, the UI thread sat blocked for seconds
                    // and the app ANR'd ("Shuttle isn't responding").
                    // When the service died mid-drain the pipe broke
                    // with EOFException, which was logged as a scary
                    // "Unhandled exception: null" (EOFException has no
                    // message). Drain on a worker thread instead:
                    // VpnStatus.newLogItem is synchronized, so calling
                    // it from here is safe, and EOF just means the
                    // service went away — a clean end of stream, not
                    // an error.
                    new Thread(() -> drainLogCache(pfd), "OpenVPNLogDrain").start();

                } else {
                    VpnStatus.initLogCache(mCacheDir);
                    /* Set up logging to Logcat with a context) */

                    if (BuildConfig.DEBUG || BuildConfig.FLAVOR.equals("skeleton")) {
                        VpnStatus.addLogListener(StatusListener.this);
                    }
                }

            } catch (RemoteException e) {
                // Fix8: IOException used to be caught here too, but
                // nothing in this block throws it any more — the
                // blocking pipe drain moved to the worker thread
                // (drainLogCache), and Java rejects the unreachable
                // catch. Remote calls (getLastConnectedVPN,
                // getTrafficHistory, registerStatusCallback) are the
                // only throwing calls left.
                e.printStackTrace();
                VpnStatus.logException(e);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            serviceStatus = null;
            VpnStatus.removeLogListener(StatusListener.this);
            VpnStatus.removeProfileStateListener(StatusListener.this);
            // Fix7: the :openvpn process died (crash/kill). No state
            // update will ever arrive from the dead process, so the
            // UI would otherwise keep showing the last state
            // ("Establishing connection") until the 45s watchdog —
            // and "Close app" on the crash dialog only kills the
            // already-dead service process, so the app looks like it
            // never closed. Post NOTCONNECTED now so the UI resets
            // to Disconnected immediately. Harmless on a normal
            // stop: the tunnel is already disconnected then.
            VpnStatus.updateStateString("NOPROCESS", "OpenVPN service disconnected.", R.string.state_noprocess, ConnectionStatus.LEVEL_NOTCONNECTED);
        }

    };
    private Context mContext;
    private String pkgName = "(packageName not yet set)";

    /**
     * Drain the :openvpn process's cached log items from the status
     * pipe. Runs on a worker thread ("OpenVPNLogDrain") — NEVER on the
     * main thread: readShort()/readFully() block until the service
     * writes, and a slow or dying service would ANR the UI. EOF means
     * the service process went away before writing the 0x7fff end
     * marker — a clean end of stream, not an error (previously it was
     * logged as "Unhandled exception: null" because EOFException
     * carries no message). Any other failure is logged normally.
     */
    private static void drainLogCache(ParcelFileDescriptor pfd) {
        DataInputStream fd = null;
        try {
            fd = new DataInputStream(new ParcelFileDescriptor.AutoCloseInputStream(pfd));
            short len = fd.readShort();
            byte[] buf = new byte[65336];
            while (len != 0x7fff) {
                fd.readFully(buf, 0, len);
                LogItem logitem = new LogItem(buf, len);
                VpnStatus.newLogItem(logitem, false);
                len = fd.readShort();
            }
        } catch (java.io.EOFException e) {
            // Service went away mid-drain (crash/stop/restart).
            // Not an error: the live AIDL log forwarding continues
            // for everything the service logs from here on.
            Log.d("OpenVPN", "Log cache stream ended early (service gone)");
        } catch (IOException e) {
            VpnStatus.logException(e);
        } finally {
            if (fd != null) {
                try {
                    fd.close();
                } catch (IOException ignored) {
                }
            }
            try {
                pfd.close();
            } catch (IOException ignored) {
            }
        }
    }

    void init(Context c) {
        pkgName = c.getPackageName();
        Intent intent = new Intent(c, OpenVPNStatusService.class);
        intent.setAction(OpenVPNService.START_SERVICE);
        mCacheDir = c.getCacheDir();

        c.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        this.mContext = c;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            logLatestExitReasons(c);
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private void logLatestExitReasons(Context c) {
        ActivityManager activityManager = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ApplicationExitInfo> exitReasons = activityManager.getHistoricalProcessExitReasons(null, 0, 5);
        ApplicationExitInfo lastguiexit = null;
        ApplicationExitInfo lastserviceexit = null;
        for (ApplicationExitInfo aei : exitReasons) {
            if (aei.getProcessName().endsWith(":openvpn")) {
                if (lastserviceexit == null || aei.getTimestamp() > lastserviceexit.getTimestamp())
                    lastserviceexit = aei;
            } else {
                if (lastguiexit == null || aei.getTimestamp() > lastguiexit.getTimestamp())
                    lastguiexit = aei;
            }
        }
        logExitNotification(lastserviceexit, "Last exit reason reported by Android for Service Process: ");
        logExitNotification(lastguiexit, "Last exit reason reported by Android for UI Process: ");

    }

    private void logExitNotification(ApplicationExitInfo aei, String s) {
        if (aei != null) {
            LogItem li = new LogItem(LogLevel.DEBUG, s + aei, aei.getTimestamp());
            VpnStatus.newLogItemIfUnique(li);
            // Shuttle fix6: toString() above truncates the crash
            // (the Logs screen only showed "reason=4 (APP
            // CRASH(EXCEPTION..."), so the actual exception was
            // invisible. getDescription() carries the exception
            // type, message AND stack trace — log it too, split
            // into chunks so the log buffer keeps every line.
            String description = aei.getDescription();
            if (description != null && !description.isEmpty()) {
                int start = 0;
                while (start < description.length()) {
                    int end = Math.min(start + 900, description.length());
                    VpnStatus.logError("Crash description: " + description.substring(start, end));
                    start = end;
                }
            }
        }
    }

    @Override
    public void newLog(LogItem logItem) {
        String tag = pkgName + "(OpenVPN)";
        long logAge = System.currentTimeMillis() - logItem.getLogtime();
        if (logAge > 5000)
        {
            tag += String.format(Locale.US, "[%ds ago]", logAge/1000 );
        }

        switch (logItem.getLogLevel()) {
            case INFO -> Log.i(tag, logItem.getString(mContext));
            case DEBUG -> Log.d(tag, logItem.getString(mContext));
            case ERROR -> Log.e(tag, logItem.getString(mContext));
            case VERBOSE -> Log.v(tag, logItem.getString(mContext));
            default -> Log.w(tag, logItem.getString(mContext));
        }

    }

    @Override
    public void notifyProfileVersionChanged(String uuid, int version, boolean changedInThisProcess) {
        if(changedInThisProcess && mConnection.serviceStatus != null)
        {
            try {
                mConnection.serviceStatus.notifyProfileVersionChanged(uuid, version);
            } catch (RemoteException e) {
                VpnStatus.logException(e);
            }
        }
    }
}
