/*
 * Copyright (c) 2012-2022 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Converted from Kotlin (main/src/ui/java/.../ProfileEncryption.kt) to
 * Java for the Shuttle build (the :openvpn module has no Kotlin plugin).
 * Behaviour is identical: profile files are encrypted with an
 * AndroidKeyStore-backed AES256-GCM key (EncryptedFile).
 */

package de.blinkt.openvpn.core;

import android.content.Context;

import androidx.security.crypto.EncryptedFile;
import androidx.security.crypto.MasterKey;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;

class ProfileEncryption {

    private static MasterKey mMasterKey = null;

    static boolean encryptionEnabled() {
        return mMasterKey != null;
    }

    static void initMasterCryptAlias(Context context) {
        try {
            mMasterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
        } catch (GeneralSecurityException e) {
            VpnStatus.logException("Could not initialise file encryption key.", e);
        } catch (IOException e) {
            VpnStatus.logException("Could not initialise file encryption key.", e);
        }
    }

    static FileInputStream getEncryptedVpInput(Context context, File file)
            throws GeneralSecurityException, IOException {
        EncryptedFile encryptedFile = new EncryptedFile.Builder(
                context,
                file,
                mMasterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build();
        return encryptedFile.openFileInput();
    }

    static FileOutputStream getEncryptedVpOutput(Context context, File file)
            throws GeneralSecurityException, IOException {
        EncryptedFile encryptedFile = new EncryptedFile.Builder(
                context,
                file,
                mMasterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build();
        return encryptedFile.openFileOutput();
    }
}
