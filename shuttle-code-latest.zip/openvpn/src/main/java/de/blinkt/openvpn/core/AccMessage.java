/*
 * Copyright (c) 2012-2026 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Top-level AccMessage, split out of AppCustomControl.kt during the
 * Kotlin-to-Java conversion for the Shuttle build (the original file
 * declared it as a top-level Kotlin data class).
 */

package de.blinkt.openvpn.core;

public class AccMessage {
    private final String protocol;
    private final boolean fragment;
    private final byte[] message;

    public AccMessage(String protocol, boolean fragment, byte[] message) {
        this.protocol = protocol;
        this.fragment = fragment;
        this.message = message;
    }

    public String getProtocol() {
        return protocol;
    }

    public boolean isFragment() {
        return fragment;
    }

    public byte[] getMessage() {
        return message;
    }
}
