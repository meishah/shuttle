/*
 * Copyright (c) 2012-2026 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Top-level DPC1Protocol, split out of AppCustomControl.kt during the
 * Kotlin-to-Java conversion for the Shuttle build.
 */

package de.blinkt.openvpn.core;

import android.os.Build;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

public class DPC1Protocol {
    private String pendingMessage = "";

    /**
     * receives a dpc1 message and returns an appropriate response.
     * This currently is a synchronous process as the current iteration
     * of the protocol does not require anything more advanced.
     *
     * @return a response message to be sent back to the client
     */
    public AccMessage processMessage(AccMessage msg) {
        try {
            if (!msg.getProtocol().equals("dpc1"))
                throw new IllegalArgumentException();

            pendingMessage += new String(msg.getMessage(), StandardCharsets.UTF_8);

            if (msg.isFragment())
                return null;

            String data = pendingMessage;
            pendingMessage = "";

            /* Fragment should be complete now */
            JSONObject command = new JSONObject(data);
            JSONObject dpcRequest = command.getJSONObject("dpc_request");

            String version = dpcRequest.getString("ver");
            if (!version.matches("[0-9a-z.]*")) {
                throw new IllegalArgumentException("Invalid version number in dpc1 request");
            }

            boolean clientInfo = false;
            if (dpcRequest.has("client_info")) {
                clientInfo = dpcRequest.getBoolean("client_info");
            }

            boolean antivirus = dpcRequest.has("antivirus");
            boolean diskEncryption = dpcRequest.has("disk_encryption");

            VpnStatus.logDebug("Received dpc1 request " + version + ", clientinfo: " + clientInfo + ", antivirus: " + antivirus + ", disk_encryption: " + diskEncryption);

            return createDpcResponse(clientInfo);
        } catch (JSONException je) {
            VpnStatus.logError("Malformed dpc1 request: " + je);
            return null;
        }
    }

    public AccMessage createDpcResponse(boolean reportClientInfo) {
        JSONObject response = new JSONObject();
        try {
            response.put("dpc_response", new JSONObject());
            JSONObject dpcResponse = response.getJSONObject("dpc_response");

            if (reportClientInfo) {
                dpcResponse.put("client_info", new JSONObject());
                JSONObject clientInfo = dpcResponse.getJSONObject("client_info");

                clientInfo.put("os", new JSONObject());
                JSONObject os = clientInfo.getJSONObject("os");

                os.put("type", "Android");
                os.put("version", Build.VERSION.RELEASE);

                /* required by spec, Connexa gives internal server error if we actually send this */
                String arch = (Build.SUPPORTED_ABIS == null || Build.SUPPORTED_ABIS.length == 0)
                        ? "unknown" : Build.SUPPORTED_ABIS[0];

                os.put("extra", new JSONObject());
                JSONObject extra = os.getJSONObject("extra");

                extra.put("arch", arch);
                extra.put("core_ver", Build.VERSION.SDK_INT);
            }

            dpcResponse.put("ver", "1.0");
        } catch (JSONException e) {
            VpnStatus.logException("Building dpc response", e);
        }

        String json = response.toString();

        return new AccMessage("dpc1", false, json.getBytes(StandardCharsets.UTF_8));
    }
}
