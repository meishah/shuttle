/*
 * Copyright (c) 2012-2016 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 *
 * Minimal replacement for ics-openvpn's LaunchVPN activity, for the
 * Shuttle build. The original activity showed the profile log window
 * and credential prompts (UI classes we do not vendor). This version
 * does only the two jobs OpenVPNService needs from it:
 *
 * 1. Launched with EXTRA_KEY (profile UUID) when the VPN permission
 *    has not been granted yet: ask the system for VPN permission
 *    (VpnService.prepare) and, once granted, start the tunnel.
 * 2. Launched with a "need" extra when the tunnel needs user input
 *    mid-connection (password / challenge): forward to Shuttle's UI
 *    via an implicit intent (action com.shuttle.vpn.OPENVPN_USER_INPUT)
 *    and finish. Shuttle handles the prompt.
 */

package de.blinkt.openvpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;

import de.blinkt.openvpn.core.ProfileManager;
import de.blinkt.openvpn.core.VPNLaunchHelper;
import de.blinkt.openvpn.core.VpnStatus;

public class LaunchVPN extends Activity {
    public static final String EXTRA_KEY = "de.blinkt.openvpn.shortcutProfileUUID";
    public static final String EXTRA_HIDELOG = "de.blinkt.openvpn.showNoLogWindow";

    private static final int VPN_PERMISSION_REQUEST = 0;
    private static final String SHUTTLE_USER_INPUT_ACTION = "com.shuttle.vpn.OPENVPN_USER_INPUT";

    private VpnProfile mProfile;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String need = intent.getStringExtra("need");
        if (need != null) {
            // Tunnel needs user input (e.g. password/challenge):
            // hand it to Shuttle's UI.
            Intent forward = new Intent(SHUTTLE_USER_INPUT_ACTION);
            forward.putExtra("need", need);
            forward.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(forward);
            } catch (Exception e) {
                VpnStatus.logException("Could not forward OpenVPN user-input request to Shuttle UI", e);
            }
            finish();
            return;
        }

        String profileUUID = intent.getStringExtra(EXTRA_KEY);
        if (profileUUID == null) {
            finish();
            return;
        }
        mProfile = ProfileManager.get(this, profileUUID);
        if (mProfile == null) {
            VpnStatus.logError("LaunchVPN: profile not found: " + profileUUID);
            finish();
            return;
        }
        requestPermissionAndStart();
    }

    private void requestPermissionAndStart() {
        Intent prepare = VpnService.prepare(this);
        if (prepare == null) {
            startTunnel();
        } else {
            startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
        }
    }

    private void startTunnel() {
        VPNLaunchHelper.startOpenVpn(mProfile, this, "LaunchVPN", false);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) {
                startTunnel();
            } else {
                VpnStatus.logError("VPN permission denied by user");
                finish();
            }
        }
    }
}
