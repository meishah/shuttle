-dontwarn javax.lang.model.**

# Fix7 (2026-11-22): ics-openvpn profiles are Java-serialized to disk —
# the class NAME and the field names are part of the stored format.
# R8 renames classes differently on every build (VpnProfile was "oa7"
# in one build and "ra7" in the next, per the R8 mapping), so a profile
# saved by build N can never be deserialized by build N+1: every
# OpenVPN connect then fails with
#   java.io.InvalidClassException: oa7; class invalid for deserialization
# and the profile is unusable forever. Keep the serialized classes and
# all of their members unobfuscated, permanently. The serialized graph
# is VpnProfile + its nested ChangeLogEntry + Connection; everything
# else in VpnProfile is primitives, String, UUID or JDK collections.
-keep class de.blinkt.openvpn.VpnProfile { *; }
-keep class de.blinkt.openvpn.VpnProfile$* { *; }
-keep class de.blinkt.openvpn.core.Connection { *; }
