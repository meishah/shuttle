package com.zaneschepke.wireguardautotunnel

import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * Two-edge home top clearance (fix14, fix15): the hero must sit
 * exactly the approved 10dp below the top bar's VISIBLE content
 * on every phone. The old height-minus-status-bar formula made the
 * gap 18dp minus the status bar, so Honor's tall status bar
 * (~36-40dp) drove it to about -20dp and the chips covered the
 * hero, while Samsung's shorter bar left only +3-5dp. The
 * two-edge measurement cancels the status bar out, so the gap is
 * 10dp on both.
 *
 * fix15 correction: the reference edge is the CONTENT bottom (the
 * chips row in normal mode, the mode row in reorder/selection
 * mode) — NOT the bar's layout bottom. The layout extends 18dp
 * below the content (8dp Column spacedBy + 10dp fade Spacer), so
 * fix14's measurement of the layout bottom put the hero 28dp
 * below the chips in 50811 even though these tests passed: the
 * old model fed the layout bottom (166dp) into the formula and
 * asserted the gap from THAT edge, hiding the overshoot.
 */
class TopPaddingTest {

    private val density = Density(2.625f)

    // Height from the status bar to the chips bottom (the visible
    // content edge): 20 banner + 8 pad + 40 capsules + 8 + 40
    // search + 8 + 32 chips. The bar's LAYOUT bottom sits a further
    // 18dp down (8dp spacedBy + 10dp fade Spacer) — that trailing
    // fade zone is NOT part of the reference edge.
    private val contentHeight = 156.dp

    // The trailing fade zone below the visible content: 8dp Column
    // spacedBy between the chips and the fade Spacer, plus the
    // 10dp Spacer itself.
    private val fadeZone = 18.dp

    // The bar's visible-content bottom edge and the list's top edge,
    // in root pixels, for a phone whose status bar is [statusBar]
    // tall. The list starts below the status bar plus the Scaffold
    // content's 8dp top padding (see MainActivity).
    private fun edges(statusBar: androidx.compose.ui.unit.Dp): Pair<Float, Float> {
        val contentBottomPx = with(density) { (statusBar + contentHeight).toPx() }
        val listTopPx = with(density) { (statusBar + 8.dp).toPx() }
        return contentBottomPx to listTopPx
    }

    // The gap the hero ends up with, measured from the VISIBLE
    // content (chips) — the gap the user sees. It must be exactly
    // the approved 10dp.
    private fun gap(statusBar: androidx.compose.ui.unit.Dp): androidx.compose.ui.unit.Dp {
        val (contentBottomPx, listTopPx) = edges(statusBar)
        val padding = topPaddingFor(contentBottomPx, listTopPx, density)
        return padding - with(density) { (contentBottomPx - listTopPx).toDp() }
    }

    @Test
    fun samsungShortStatusBarGapIsExactly10dp() {
        // Samsung status bar ~24dp.
        assertEquals(10.dp, gap(24.dp))
    }

    @Test
    fun honorTallStatusBarGapIsExactly10dp() {
        // Honor MagicOS status bar ~38dp.
        assertEquals(10.dp, gap(38.dp))
    }

    @Test
    fun topPaddingIsIdenticalOnBothPhones() {
        // The status bar cancels out of the two-edge measurement:
        // the same clearance on both phones, not 18dp minus the
        // status bar the way the old formula gave.
        val (samContent, samList) = edges(24.dp)
        val (honContent, honList) = edges(38.dp)
        assertEquals(
            topPaddingFor(samContent, samList, density),
            topPaddingFor(honContent, honList, density),
        )
    }

    @Test
    fun degenerateMeasurementFloorsAt10dp() {
        // Bar bottom at or above the list top: never negative, never
        // less than the 10dp gap.
        assertEquals(10.dp, topPaddingFor(0f, 0f, density))
        assertEquals(10.dp, topPaddingFor(100f, 200f, density))
    }

    @Test
    fun layoutBottomInsteadOfContentBottomOvershootsTo28dp() {
        // Regression test for 50811: feeding the bar's LAYOUT bottom
        // (content bottom + the 18dp trailing fade zone) into the
        // formula puts the hero 18dp + 10dp = 28dp below the chips
        // instead of the approved 10dp. This is why the reference
        // edge must be the visible content bottom, not the layout
        // bottom. (Samsung status bar ~24dp.)
        val (contentBottomPx, listTopPx) = edges(24.dp)
        val layoutBottomPx = contentBottomPx + with(density) { fadeZone.toPx() }
        val padding = topPaddingFor(layoutBottomPx, listTopPx, density)
        val visibleGap = padding - with(density) { (contentBottomPx - listTopPx).toDp() }
        assertEquals(28.dp, visibleGap)
    }

    @Test
    fun barHeightClearanceGapIsExactly10dp() {
        // The second, independent clearance source (fix_3):
        // topPaddingFromBarHeight derives the clearance from the
        // bar's OWN layout height alone (status bar excluded), with
        // no root coordinates. The bar's layout height is the
        // visible content (156dp) plus the 18dp trailing fade
        // zone. It must yield the same approved 10dp visible gap
        // from the chips. (Samsung status bar ~24dp.)
        // Note: the bar height arrives as whole pixels, so
        // integer-px rounding can shift the result by <1px
        // (~0.4dp); assert the gap is 10dp within that rounding.
        val (contentBottomPx, listTopPx) = edges(24.dp)
        val barHeightPx = with(density) { (contentHeight + fadeZone).toPx() }
        val padding = topPaddingFromBarHeight(barHeightPx.toInt(), density)
        val visibleGap = padding - with(density) { (contentBottomPx - listTopPx).toDp() }
        assertTrue(abs(visibleGap.value - 10f) < 0.5f)
    }

    @Test
    fun barHeightClearanceMatchesTwoEdge() {
        // On the modeled geometry both clearance sources agree, so
        // taking the larger of the two (the fix's max) does not
        // inflate the gap: both give the same padding within
        // integer-px rounding (<0.5dp).
        val (contentBottomPx, listTopPx) = edges(24.dp)
        val barHeightPx = with(density) { (contentHeight + fadeZone).toPx() }
        val twoEdge = topPaddingFor(contentBottomPx, listTopPx, density)
        val fromBar = topPaddingFromBarHeight(barHeightPx.toInt(), density)
        assertTrue(abs(twoEdge.value - fromBar.value) < 0.5f)
    }
}
