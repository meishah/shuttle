package com.zaneschepke.wireguardautotunnel.ui.state

import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unreachable-last partition (user 18:48): after a ping, configs
 * that did not answer must sit below every reachable one in the
 * displayed list, whatever positions the database still holds.
 */
class TunnelListRowsTest {

    private fun row(id: Int, name: String, lastPingMs: Double? = null) =
        TunnelListRow.TunnelRow(TunnelConfig(id = id, name = name, lastPingMs = lastPingMs))

    @Test
    fun unreachableSinksLast() {
        val rows =
            listOf(
                row(1, "reachable-fast", 45.0),
                row(2, "unreachable", Double.MAX_VALUE),
                row(3, "reachable-slow", 250.0),
                row(4, "unpinged"),
            )
        val result = partitionUnreachableLast(rows, emptyMap())
        assertEquals(listOf(1, 3, 4, 2), result.map { it.tunnel.id })
    }

    @Test
    fun freshLatencyOverridesPersisted() {
        // In-memory ping says unreachable now, even though the DB
        // still holds an old 80ms value — the fresh value wins.
        val rows = listOf(row(1, "now-dead", 80.0), row(2, "alive", 60.0))
        val result = partitionUnreachableLast(rows, mapOf(1 to Double.MAX_VALUE))
        assertEquals(listOf(2, 1), result.map { it.tunnel.id })
    }

    @Test
    fun reachableOrderIsStable() {
        val rows = listOf(row(1, "b", 200.0), row(2, "a", 30.0), row(3, "c", 90.0))
        val result = partitionUnreachableLast(rows, emptyMap())
        // The partition does NOT re-sort by latency — it only moves
        // the unreachable bucket last. The ping-sorted order comes
        // from the ViewModel; this safety net must not disturb it.
        assertEquals(listOf(1, 2, 3), result.map { it.tunnel.id })
    }

    @Test
    fun allUnreachableKeepsOrder() {
        val rows =
            listOf(row(1, "a", Double.MAX_VALUE), row(2, "b", Double.MAX_VALUE))
        val result = partitionUnreachableLast(rows, emptyMap())
        assertEquals(listOf(1, 2), result.map { it.tunnel.id })
    }

    // Pinning (Shuttle 1.1): pinned configs sort to the top of their
    // scope, keeping their relative position order otherwise.

    private fun tunnel(
        id: Int,
        name: String,
        position: Int,
        groupId: Int? = null,
        isPinned: Boolean = false,
    ) =
        TunnelConfig(
            id = id,
            name = name,
            position = position,
            groupId = groupId,
            isPinned = isPinned,
        )

    private fun tunnelIds(rows: List<TunnelListRow>): List<Int> =
        rows.filterIsInstance<TunnelListRow.TunnelRow>().map { it.tunnel.id }

    @Test
    fun pinnedChildSortsFirstInGroup() {
        val group = TunnelGroup(id = 1, name = "g", position = 0)
        val tunnels =
            listOf(
                tunnel(1, "a", position = 0, groupId = 1),
                tunnel(2, "b", position = 1, groupId = 1),
                tunnel(3, "c", position = 2, groupId = 1, isPinned = true),
            )
        val rows =
            buildTunnelListRows(
                groups = listOf(group),
                tunnels = tunnels,
                activeTunnelIds = emptySet(),
                scopeGroupId = 1,
            )
        assertEquals(listOf(3, 1, 2), tunnelIds(rows))
    }

    @Test
    fun pinnedChildrenKeepPositionOrder() {
        val group = TunnelGroup(id = 1, name = "g", position = 0)
        val tunnels =
            listOf(
                tunnel(1, "a", position = 0, groupId = 1, isPinned = true),
                tunnel(2, "b", position = 1, groupId = 1),
                tunnel(3, "c", position = 2, groupId = 1, isPinned = true),
            )
        val rows =
            buildTunnelListRows(
                groups = listOf(group),
                tunnels = tunnels,
                activeTunnelIds = emptySet(),
                scopeGroupId = 1,
            )
        assertEquals(listOf(1, 3, 2), tunnelIds(rows))
    }

    @Test
    fun pinnedRootTunnelSortsFirstInAllView() {
        val group = TunnelGroup(id = 1, name = "g", position = 0)
        val tunnels =
            listOf(
                tunnel(1, "root-a", position = 1),
                tunnel(2, "root-b", position = 2, isPinned = true),
                tunnel(3, "child", position = 0, groupId = 1),
            )
        val rows =
            buildTunnelListRows(
                groups = listOf(group),
                tunnels = tunnels,
                activeTunnelIds = emptySet(),
            )
        // Group headers are rows too; the flat tunnel order is what
        // the All view shows — the pinned root config leads it, ahead
        // of the group block and the unpinned root config.
        assertEquals(listOf(2, 3, 1), tunnelIds(rows))
    }
}
