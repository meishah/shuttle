package com.zaneschepke.wireguardautotunnel.core.openvpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

/**
 * Regression tests for the OVPN password bug (2026-11-24): the password
 * used to live only on the serialized VpnProfile, keyed by the profile
 * UUID — but that UUID is regenerated on every reparse, so the password
 * was silently lost while the username survived (it is also in the DB).
 * The durable store keys by the stable tunnel (config) id instead.
 * These tests pin the key invariant: stable per config, distinct
 * across configs, derived from nothing but the id.
 */
class OvpnPasswordStoreTest {

    @Test
    fun keyFor_isStable_forSameConfigId() {
        assertEquals(
            OvpnPasswordStore.keyFor(42),
            OvpnPasswordStore.keyFor(42),
        )
    }

    @Test
    fun keyFor_isDistinct_acrossConfigIds() {
        assertNotEquals(OvpnPasswordStore.keyFor(1), OvpnPasswordStore.keyFor(2))
        assertNotEquals(OvpnPasswordStore.keyFor(0), OvpnPasswordStore.keyFor(1))
        assertNotEquals(OvpnPasswordStore.keyFor(231), OvpnPasswordStore.keyFor(232))
    }

    @Test
    fun keyFor_doesNotContainUuidLikeRandomness() {
        // Same id, called twice, must be byte-identical — a key that
        // changed between calls (like the profile UUID did on every
        // reparse) would orphan every password stored under it.
        val first = OvpnPasswordStore.keyFor(7)
        val second = OvpnPasswordStore.keyFor(7)
        assertEquals(first, second)
    }
}
