package com.zaneschepke.wireguardautotunnel.ui.navigation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.Locale
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleTopScrim
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.ShuttleMark
import com.zaneschepke.wireguardautotunnel.ui.state.NavbarState
import com.zaneschepke.wireguardautotunnel.ui.theme.LockedDownBannerHeight
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicTopAppBar(
    navBarState: NavbarState,
    modifier: Modifier = Modifier,
    // Frosted glass over the scrolling list (user 17:46): the bar
    // is a gradient scrim (see ShuttleHaze.kt) fading to clear at
    // its bottom edge. Haze was replaced in 1.5 — its progressive
    // blur never rendered on her phone.
) {
    TopAppBar(
        modifier =
            modifier
                .shuttleTopScrim()
                .padding(top = LockedDownBannerHeight),
        colors = TopAppBarDefaults.topAppBarColors().copy(Color.Transparent),
        navigationIcon = { navBarState.topLeading?.invoke() },
        title = {
            // The real Shuttle app icon + title inside one pill
            // capsule (user 15:12) — the same treatment as the
            // selected filter chip: lavender background with DARK
            // text in BOTH themes (user 17:52), never a dark pill
            // with light text.
            if (navBarState.showShuttleMark && navBarState.topTitle != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier =
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(OrionLavender)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    ShuttleMark(size = 28.dp, cornerRadius = 8.dp)
                    Text(
                        // Fix8 (user): "SHUTTLE" in ALL CAPS with a
                        // heavy (extra-bold) font in the top-bar
                        // capsule only. Uppercase with ROOT locale so
                        // the Persian UI locale can never change the
                        // Latin letters.
                        navBarState.topTitle.uppercase(Locale.ROOT),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = OnSelectedCapsule,
                        fontWeight = FontWeight.ExtraBold,
                    )
                }
            } else {
                navBarState.topTitle?.let {
                    Text(it, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        },
        actions = { navBarState.topTrailing?.invoke() },
    )
}
