package com.zaneschepke.wireguardautotunnel.ui.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnState
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.di.Scope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import org.koin.core.qualifier.named
import com.zaneschepke.wireguardautotunnel.core.orchestration.TunnelCoordinator
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * Shuttle 1x1 home-screen widget: one tap toggles connect/disconnect
 * (to the last-used tunnel, same as the hero button), and the power icon
 * shows the state — lime (#CAFA80) when connected, grey when disconnected.
 *
 * Why the old widget showed only a black square: its layout and
 * background used theme attributes (?attr/colorSurfaceContainer,
 * ?attr/colorOnSurface...) and an adaptive-icon mipmap as the icon —
 * neither renders in RemoteViews (inflated in the launcher process).
 * This widget uses only explicit colours and plain vector drawables.
 *
 * State updates: the widget refreshes when added, when tapped
 * (immediately, then again after the tunnel has had a moment to change
 * state), and whenever any tunnel state changes — the Application
 * collects the tunnel state and calls refreshAll (no polling).
 */
class ShuttleWidgetProvider : AppWidgetProvider(), KoinComponent {

    private val tunnelCoordinator: TunnelCoordinator by inject()
    private val tunnelRepository: TunnelRepository by inject()
    private val openVpnCoordinator: OpenVpnCoordinator by inject()
    private val applicationScope: CoroutineScope by inject(named(Scope.APPLICATION))

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        appWidgetIds.forEach { updateWidget(context, appWidgetManager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            // Visible feedback first: the tap must never look dead. Show
            // the amber "working" icon at once; the true state (lime /
            // grey) is drawn by the refresh below and the state collector.
            showBusy(context)
            // Handle the widget action inside this app process. Do not
            // route it through the exported automation receiver or rely
            // on a forgeable Intent extra to bypass its security checks.
            applicationScope.launch {
                val tunnel =
                    tunnelCoordinator.getLastUsedTunnel()
                        ?: tunnelRepository.getDefaultTunnel()
                        ?: return@launch
                tunnelCoordinator.toggleTunnel(tunnel)
            }
            // Refresh now (optimistic) and once more after the tunnel
            // has had time to change state.
            refreshAll(context)
            Handler(Looper.getMainLooper()).postDelayed({ refreshAll(context) }, 2000L)
        }
    }

    private fun updateWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_shuttle)
        // Never let a state-read failure blank the widget: fall back to
        // the disconnected look instead of throwing out of onUpdate.
        val connected =
            try {
                val wgActive =
                    tunnelCoordinator.backendStatus.value.activeTunnels.isNotEmpty()
                val ovpnConnected =
                    openVpnCoordinator.activeTunnelId.value != null &&
                        openVpnCoordinator.state.value is OpenVpnState.Connected
                wgActive || ovpnConnected
            } catch (e: Exception) {
                false
            }
        views.setImageViewResource(
            R.id.widget_icon,
            if (connected) R.drawable.ic_widget_power_on
            else R.drawable.ic_widget_power_off,
        )
        val toggleIntent = Intent(context, ShuttleWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE
        }
        // The whole 1x1 tile is the toggle.
        views.setOnClickPendingIntent(
            R.id.widget_root,
            PendingIntent.getBroadcast(
                context, 0, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            ),
        )
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    companion object {
        const val ACTION_TOGGLE = "com.shuttle.vpn.WIDGET_TOGGLE"

        /** Transient "tap registered, working" look (amber power icon). */
        fun showBusy(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, ShuttleWidgetProvider::class.java),
            )
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_shuttle)
                views.setImageViewResource(R.id.widget_icon, R.drawable.ic_widget_power_busy)
                views.setOnClickPendingIntent(
                    R.id.widget_root,
                    PendingIntent.getBroadcast(
                        context,
                        0,
                        Intent(context, ShuttleWidgetProvider::class.java).apply {
                            action = ACTION_TOGGLE
                        },
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                    ),
                )
                manager.updateAppWidget(id, views)
            }
        }

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, ShuttleWidgetProvider::class.java),
            )
            if (ids.isEmpty()) return
            val intent = Intent(context, ShuttleWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }
}
