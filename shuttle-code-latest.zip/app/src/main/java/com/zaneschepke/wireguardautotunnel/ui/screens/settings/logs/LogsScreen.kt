package com.zaneschepke.wireguardautotunnel.ui.screens.settings.logs

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.dokar.sonner.ToastType
import com.zaneschepke.logcatter.model.LogLevel
import com.zaneschepke.logcatter.model.LogMessage
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.ui.common.label.GroupLabel
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.logs.components.LogList
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.logs.components.LogsBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.EmptyStateLottie
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.state.IdentifiedLogMessage
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.viewmodel.LoggerViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import java.time.Instant
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.koinInject
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState
import org.orbitmvi.orbit.compose.collectSideEffect

@Composable
fun LogsScreen(
    viewModel: LoggerViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
    openVpnCoordinator: OpenVpnCoordinator = koinInject(),
) {
    val context = LocalContext.current
    val loggerState by viewModel.collectAsState()

    if (loggerState.isLoading) return

    // Shuttle: the logcat reader above only sees the main process
    // (logcat --pid=<main pid>), so the :openvpn process is invisible
    // here. Show the OpenVPN core's own log buffer (forwarded from the
    // :openvpn process) as a section on top, so a failed OpenVPN
    // connect can actually be diagnosed from this screen.
    val ovpnMessages = remember {
        openVpnCoordinator.getLogLines(context).mapIndexed { index, line ->
            IdentifiedLogMessage(
                id = index.toLong(),
                message = LogMessage(
                    time = Instant.now().toString(),
                    pid = "0",
                    tid = "0",
                    level = LogLevel.INFO,
                    tag = "OpenVPN",
                    message = line,
                ),
            )
        }
    }
    val ovpnListState = rememberLazyListState()

    LaunchedEffect(ovpnMessages.size) {
        if (ovpnMessages.isNotEmpty()) {
            ovpnListState.scrollToItem(ovpnMessages.size)
        }
    }

    val lazyColumnListState = rememberLazyListState()
    var isAutoScrolling by rememberSaveable { mutableStateOf(true) }
    var lastScrollPosition by rememberSaveable { mutableIntStateOf(0) }
    var showLogsSheet by rememberSaveable { mutableStateOf(false) }

    sharedViewModel.collectSideEffect { sideEffect ->
        if (sideEffect is LocalSideEffect.Sheet.LoggerActions) showLogsSheet = true
    }

    LaunchedEffect(isAutoScrolling) {
        if (isAutoScrolling) {
            lazyColumnListState.scrollToItem(loggerState.messages.size)
        }
    }

    LaunchedEffect(loggerState.messages.size) {
        if (isAutoScrolling) {
            lazyColumnListState.scrollToItem(loggerState.messages.size)
        }
    }

    LaunchedEffect(lazyColumnListState) {
        snapshotFlow { lazyColumnListState.firstVisibleItemIndex }
            .collect { currentScrollPosition ->
                if (currentScrollPosition < lastScrollPosition && isAutoScrolling) {
                    isAutoScrolling = false
                }
                val visible = lazyColumnListState.layoutInfo.visibleItemsInfo
                if (
                    visible.isNotEmpty() &&
                        visible.last().index ==
                            lazyColumnListState.layoutInfo.totalItemsCount - 1 &&
                        !isAutoScrolling
                ) {
                    isAutoScrolling = true
                }
                lastScrollPosition = currentScrollPosition
            }
    }

    if (showLogsSheet) {
        LogsBottomSheet(
            onExport = { uri ->
                viewModel.exportLogs(uri)
                showLogsSheet = false
            },
            onDelete = {
                viewModel.deleteLogs()
                showLogsSheet = false
            },
            onCanceled = {
                sharedViewModel.showSnackMessage(
                    StringValue.StringResource(R.string.export_canceled),
                    ToastType.Warning,
                )
                showLogsSheet = false
            },
            onDismiss = { showLogsSheet = false },
        )
    }

    AnimatedContent(
        targetState = loggerState.messages.isEmpty() && ovpnMessages.isEmpty(),
        transitionSpec = {
            fadeIn(animationSpec = tween(250)) togetherWith fadeOut(animationSpec = tween(200))
        },
        label = "LogsContentTransition",
    ) { isEmpty ->
        if (isEmpty) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyStateLottie(message = stringResource(R.string.no_tunnels_yet))
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().padding(top = 70.dp),
            ) {
                if (ovpnMessages.isNotEmpty()) {
                    GroupLabel(
                        stringResource(R.string.ovpn_log_title),
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    LogList(
                        logs = ovpnMessages,
                        lazyColumnListState = ovpnListState,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
                    )
                }
                LogList(
                    logs = loggerState.messages,
                    lazyColumnListState = lazyColumnListState,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}
