package com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.language

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.util.LocaleUtil
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import java.text.Collator
import org.koin.compose.viewmodel.koinActivityViewModel

@Composable
fun LanguageScreen(sharedViewModel: SharedAppViewModel = koinActivityViewModel()) {

    val collator = Collator.getInstance(Locale.current.platformLocale)
    // Shuttle offers English and Persian only.
    val locales =
        LocaleUtil.supportedLocales
            .filter { it == "en" || it == "fa" }
            .map {
                val tag = it.replace("_", "-")
                java.util.Locale.forLanguageTag(tag)
            }

    val sortedLocales =
        remember(locales) {
            locales.sortedWith(compareBy(collator) { it.getDisplayName(it) }).toList()
        }

    val currentLocale = AppCompatDelegate.getApplicationLocales().get(0)

    val selectedTag =
        remember(currentLocale, sortedLocales) {
            currentLocale?.let { current ->
                (sortedLocales.firstOrNull { it.toLanguageTag() == current.toLanguageTag() }
                        ?: sortedLocales.firstOrNull { it.language == current.language })
                    ?.toLanguageTag()
            }
        }

    // Only three rows (Automatic + English + Persian) — no scrolling
    // needed, so this is a plain Column like DisplayScreen; the old
    // scroll-to-selected logic went away with the LazyColumn.
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Top,
    ) {
        ShuttleSettingsCard {
            SurfaceRow(
                title = stringResource(R.string.automatic),
                trailing =
                    if (currentLocale == null) {
                        {
                            Icon(
                                Icons.Outlined.Check,
                                stringResource(id = R.string.selected),
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    } else null,
                onClick = { sharedViewModel.setLocale(LocaleUtil.OPTION_PHONE_LANGUAGE) },
                containerColor = Color.Transparent,
            )
            ShuttleSettingsDivider()
            sortedLocales.forEachIndexed { index, locale ->
                val buttonText =
                    locale.getDisplayName(locale).replaceFirstChar {
                        if (it.isLowerCase()) it.titlecase(locale) else it.toString()
                    }
                SurfaceRow(
                    title = buttonText,
                    trailing =
                        if (selectedTag == locale.toLanguageTag()) {
                            {
                                Icon(
                                    Icons.Outlined.Check,
                                    stringResource(id = R.string.selected),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        } else null,
                    onClick = { sharedViewModel.setLocale(locale.toLanguageTag()) },
                    containerColor = Color.Transparent,
                )
                if (index < sortedLocales.size - 1) {
                    ShuttleSettingsDivider()
                }
            }
        }
    }
}
