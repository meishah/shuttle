package com.zaneschepke.wireguardautotunnel.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tunnel_config",
    foreignKeys =
        [
            ForeignKey(
                entity = TunnelConfig::class,
                parentColumns = ["id"],
                childColumns = ["entry_tunnel_id"],
                onDelete = ForeignKey.SET_NULL,
            ),
        ],
    indices =
        [
            Index(value = ["name"], unique = true),
            Index(value = ["group_id"]),
            Index(value = ["entry_tunnel_id"]),
        ],
)
data class TunnelConfig(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "name") val name: String,
    @ColumnInfo(name = "tunnel_networks", defaultValue = "[]")
    val tunnelNetworks: List<String> = emptyList(),
    @ColumnInfo(name = "is_mobile_data_tunnel", defaultValue = "0")
    val isMobileDataTunnel: Boolean = false,
    @ColumnInfo(name = "is_primary_tunnel", defaultValue = "0")
    val isPrimaryTunnel: Boolean = false,
    @ColumnInfo(name = "quick_config", defaultValue = "") val quickConfig: String = "",
    @ColumnInfo(name = "is_ethernet_tunnel", defaultValue = "0")
    val isEthernetTunnel: Boolean = false,
    @ColumnInfo(name = "prefer_ipv6", defaultValue = "0") val isIpv6Preferred: Boolean = false,
    @ColumnInfo(name = "position", defaultValue = "0") val position: Int = 0,
    @ColumnInfo(name = "auto_tunnel_apps", defaultValue = "[]")
    val autoTunnelApps: List<String> = emptyList(),
    @ColumnInfo(name = "is_metered", defaultValue = "0") val isMetered: Boolean = false,
    @ColumnInfo(name = "ipv6_restore", defaultValue = "0") val ipv6RestoreEnabled: Boolean = false,
    @ColumnInfo(name = "tunnel_bssids", defaultValue = "[]")
    val tunnelBSSIDs: List<String> = emptyList(),
    @ColumnInfo(name = "is_ddns_tunnel", defaultValue = "0") val isDDNSTunnel: Boolean = false,
    @ColumnInfo(name = "group_id", defaultValue = "NULL") val groupId: Int? = null,
    @ColumnInfo(name = "entry_tunnel_id", defaultValue = "NULL") val entryTunnelId: Int? = null,
    // Shuttle: OpenVPN configs share this table with WireGuard/AmneziaWG ones.
    // isOpenVpn rows keep their .ovpn source in ovpnText and their
    // ics-openvpn profile UUID in ovpnUuid; quickConfig stays empty for them
    // (getConfig() must never be called on an OpenVPN row).
    @ColumnInfo(name = "is_openvpn", defaultValue = "0") val isOpenVpn: Boolean = false,
    @ColumnInfo(name = "ovpn_uuid", defaultValue = "NULL") val ovpnUuid: String? = null,
    @ColumnInfo(name = "ovpn_text", defaultValue = "") val ovpnText: String = "",
    @ColumnInfo(name = "ovpn_username", defaultValue = "") val ovpnUsername: String = "",
    // Auto-reconnect if the tunnel drops unexpectedly (OpenVPN only for now).
    @ColumnInfo(name = "auto_reconnect", defaultValue = "1") val autoReconnect: Boolean = true,
    // Last measured ping (ms) for this tunnel, persisted so the row keeps
    // showing it after connecting / restarting. Null = never measured.
    @ColumnInfo(name = "last_ping_ms", defaultValue = "NULL") val lastPingMs: Double? = null,
    // Pinned configs sort to the top of the list within their group
    // (and in the All view). Set from the selection ⋮ menu.
    @ColumnInfo(name = "is_pinned", defaultValue = "0") val isPinned: Boolean = false,
) {
    companion object {
        const val GLOBAL_CONFIG_NAME = "4675ab06-903a-438b-8485-6ea4187a9512"
    }
}
