package com.zaneschepke.wireguardautotunnel.ui.state

import com.wgtunnel.backend.state.BackendStatus
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnState
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup

data class TunnelsUiState(
    val tunnels: List<TunnelConfig> = emptyList(),
    val groups: List<TunnelGroup> = emptyList(),
    val backendStatus: BackendStatus = BackendStatus(),
    val selectedTunnels: List<TunnelConfig> = emptyList(),
    val selectedGroups: List<TunnelGroup> = emptyList(),
    val displayStates: Map<Int, DisplayTunnelState> = emptyMap(),
    val isLoading: Boolean = true,
    val isReorderMode: Boolean = false,
    val reorderScopeGroupId: Int? = null,
    val reorderLatencies: Map<Int, Double> = emptyMap(),
    val pingLatencies: Map<Int, Double> = emptyMap(),
    /** Real OpenVPN tunnel state, driven by the :openvpn core only. */
    val openVpnState: OpenVpnState = OpenVpnState.Disconnected,
    val openVpnActiveId: Int? = null,
) {
    val hasActiveTunnel: Boolean
        get() = backendStatus.activeTunnels.isNotEmpty() || openVpnActiveId != null

    val isSelectionMode: Boolean
        get() = selectedTunnels.isNotEmpty() || selectedGroups.isNotEmpty()

    val selectedCount: Int
        get() = selectedTunnels.size + selectedGroups.size

    val canUngroup: Boolean
        get() = selectedTunnels.isNotEmpty() && selectedTunnels.none { it.groupId == null }

    val canMoveToGroup: Boolean
        // Fix9: Move used to require selected TUNNELS and no selected
        // groups — long-pressing a group header and choosing Move did
        // nothing. A selected group can be moved too (its children
        // move with it — see selectedTunnelsForMove).
        get() = selectedTunnels.isNotEmpty() || selectedGroups.isNotEmpty()

    val canCopy: Boolean
        // Fix9: copy is no longer single-tunnel only — every
        // selected tunnel is copied (copySelectedTunnel).
        get() = selectedTunnels.isNotEmpty() && selectedGroups.isEmpty()

    val tunnelsForExport: List<TunnelConfig>
        get() =
            (selectedTunnels +
                    selectedGroups.flatMap { group -> tunnels.filter { it.groupId == group.id } })
                .distinctBy { it.id }

    val reorderScopeGroup: TunnelGroup?
        get() = reorderScopeGroupId?.let { id -> groups.firstOrNull { it.id == id } }

    val rows: List<TunnelListRow>
        get() =
            buildTunnelListRows(
                groups = groups,
                tunnels = tunnels,
                activeTunnelIds = backendStatus.activeTunnels.keys,
                collapseGroups = isReorderMode && reorderScopeGroupId == null,
                scopeGroupId = if (isReorderMode) reorderScopeGroupId else null,
            )
}
