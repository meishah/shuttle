package com.zaneschepke.wireguardautotunnel

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.core.app.ActivityCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import com.dokar.sonner.TextToastAction
import com.dokar.sonner.Toast
import com.dokar.sonner.ToastCloseButton
import com.dokar.sonner.ToastType
import com.dokar.sonner.Toaster
import com.dokar.sonner.rememberToasterState
import com.zaneschepke.networkmonitor.NetworkMonitor
import com.zaneschepke.wireguardautotunnel.core.lock.AppLockManager
import com.zaneschepke.wireguardautotunnel.core.orchestration.FileExportCoordinator
import com.zaneschepke.wireguardautotunnel.data.backup.BackupWriteResult
import com.zaneschepke.wireguardautotunnel.data.backup.DatabaseBackup
import com.zaneschepke.wireguardautotunnel.data.backup.RestoreResult
import com.zaneschepke.wireguardautotunnel.domain.enums.StrictSplitNotice
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.repository.AppStateRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.GlobalSideEffect
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.NotificationPendingAction
import com.zaneschepke.wireguardautotunnel.notification.NotificationService
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.EXTRA_AUTO_UPDATE
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.EXTRA_OPEN_SUPPORT
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.EXTRA_SHOW_UPDATE
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.UPDATE_AVAILABLE_NOTIFICATION_ID
import com.zaneschepke.wireguardautotunnel.service.tile.TunnelTileRefresher
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.banner.AppAlertBanner
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.InfoDialog
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.LocalNetworkPermissionDialog
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.VpnDeniedDialog
import com.zaneschepke.wireguardautotunnel.ui.common.sheet.StrictSplitNoticeSheet
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.navigation.Tab
import com.zaneschepke.wireguardautotunnel.ui.navigation.components.BottomNavbar
import com.zaneschepke.wireguardautotunnel.ui.navigation.components.DynamicTopAppBar
import com.zaneschepke.wireguardautotunnel.ui.navigation.components.ShuttleHomeTopBar
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.navigation.components.currentRouteAsNavbarState
import com.zaneschepke.wireguardautotunnel.ui.navigation.functions.rememberNavController
import com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.AutoTunnelScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.detection.WifiDetectionMethodScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.disclosure.LocationDisclosureScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.preferred.PreferredTunnelScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.wifi.WifiSettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.pin.LocalAppLocked
import com.zaneschepke.wireguardautotunnel.ui.screens.pin.PinLockOverlay
import com.zaneschepke.wireguardautotunnel.ui.screens.pin.PinLockScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.SettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.advanced.AdvancedScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.amnezia.GlobalAmneziaScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.AppearanceScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.display.DisplayScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.language.LanguageScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.notifications.NotificationsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.DnsSettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.integrations.AndroidIntegrationsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.lockdown.LockdownSettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.logs.LogsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.monitoring.MonitoringScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.proxy.ProxySettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.security.SecurityScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.support.SupportScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.support.license.LicenseScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.TunnelsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.TunnelSettingsScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.config.ConfigScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.config.edit.ConfigEditScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.entry.EntryTunnelScreen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.ipv6.IPv6Screen
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.SplitTunnelScreen
import com.zaneschepke.wireguardautotunnel.ui.theme.AlertRed
import com.zaneschepke.wireguardautotunnel.ui.theme.Heart
import com.zaneschepke.wireguardautotunnel.ui.theme.OffWhite
import com.zaneschepke.wireguardautotunnel.ui.theme.SilverTree
import com.zaneschepke.wireguardautotunnel.ui.theme.Straw
import com.zaneschepke.wireguardautotunnel.ui.theme.WireguardAutoTunnelTheme
import com.zaneschepke.wireguardautotunnel.util.FileUtils
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.installApk
import com.zaneschepke.wireguardautotunnel.util.extensions.isRunningOnTv
import com.zaneschepke.wireguardautotunnel.util.extensions.openWebUrl
import com.zaneschepke.wireguardautotunnel.util.permission.LocalNetworkPermissionHelper
import com.zaneschepke.wireguardautotunnel.ui.screens.openvpn.OpenVpnEditScreen
import com.zaneschepke.wireguardautotunnel.ui.widget.ShuttleWidgetProvider
import com.zaneschepke.wireguardautotunnel.viewmodel.ConfigEditViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.OpenVpnEditViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SplitTunnelViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.TunnelViewModel
import kotlin.system.exitProcess
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import org.koin.androidx.compose.koinViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf
import org.orbitmvi.orbit.compose.collectAsState
import timber.log.Timber

class MainActivity : AppCompatActivity() {

    private val appStateRepository: AppStateRepository by inject()
    private val tunnelRepository: TunnelRepository by inject()
    private val networkMonitor: NetworkMonitor by inject()
    private val fileExportCoordinator: FileExportCoordinator by inject()
    private val notificationService: NotificationService by inject()
    private val databaseBackup: DatabaseBackup by inject()
    private val appLockManager: AppLockManager by inject()

    val viewModel by viewModel<SharedAppViewModel>()
    private var pendingBackupPassword: String? = null

    private val createBackupLauncher =
        registerForActivityResult(
            ActivityResultContracts.CreateDocument(FileUtils.ZIP_FILE_MIME_TYPE),
        ) { uri ->
            val password = pendingBackupPassword
            pendingBackupPassword = null
            if (uri == null) {
                lifecycleScope.launch { showBackupResult(BackupWriteResult.Failed) }
                return@registerForActivityResult
            }
            lifecycleScope.launch { showBackupResult(databaseBackup.backupTo(uri, password)) }
        }

    private val openBackupLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val password = pendingBackupPassword
            pendingBackupPassword = null
            if (uri == null) {
                lifecycleScope.launch { showRestoreResult(RestoreResult.Failed) }
                return@registerForActivityResult
            }
            lifecycleScope.launch { finishRestore(databaseBackup.restore(uri, password)) }
        }

    private val snackbarChannel = Channel<GlobalSideEffect.Snackbar>(Channel.UNLIMITED)
    private val supportDeepLinkChannel = Channel<Boolean>(Channel.BUFFERED)
    private val showUpdateChannel = Channel<Unit>(Channel.BUFFERED)
    private val pendingConfigImport = MutableStateFlow<Uri?>(null)

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        super.onCreate(savedInstanceState)

        handleConfigFileIntent(intent)
        handleWgDeepLinkIntent(intent)

        installSplashScreen().apply {
            setKeepOnScreenCondition { !viewModel.container.stateFlow.value.isAppLoaded }
        }

        setContent {
            val context = LocalContext.current
            val isTv = isRunningOnTv()
            val uiState by viewModel.collectAsState()
            val scope = rememberCoroutineScope()

            LaunchedEffect(uiState.isAppLoaded) {
                if (uiState.isAppLoaded) {
                    viewModel.syncLocale()
                }
            }

            val toaster = rememberToasterState()
            var showVpnPermissionDialog by remember { mutableStateOf(false) }
            var coldStartAutoUpdate by remember {
                mutableStateOf(intent?.getBooleanExtra(EXTRA_AUTO_UPDATE, false) == true)
            }
            var coldStartShowUpdate by remember {
                mutableStateOf(intent?.getBooleanExtra(EXTRA_SHOW_UPDATE, false) == true)
            }
            var vpnPermissionDenied by remember { mutableStateOf(false) }
            var requestingTunnelMode by remember {
                mutableStateOf<Pair<TunnelMode?, TunnelConfig?>>(Pair(null, null))
            }
            var pendingNotificationAction by remember {
                mutableStateOf<NotificationPendingAction?>(null)
            }
            var showLocalNetworkRationale by remember { mutableStateOf(false) }
            var hasPromptedLocalNetwork by rememberSaveable { mutableStateOf(false) }

            var pendingExport by remember { mutableStateOf<GlobalSideEffect.ExportFile?>(null) }
            val requestPermissionLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
                    isGranted ->
                    val export = pendingExport
                    pendingExport = null
                    if (isGranted && export != null) {
                        lifecycleScope.launch { fileExportCoordinator.execute(export) }
                    }
                }

            fun startExport(export: GlobalSideEffect.ExportFile) {
                if (fileExportCoordinator.needsWritePermission(export.uri)) {
                    pendingExport = export
                    requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                } else {
                    lifecycleScope.launch { fileExportCoordinator.execute(export) }
                }
            }

            val localNetworkPermissionLauncher =
                rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission(),
                ) { isGranted ->
                    if (!isGranted) {
                        val canAskAgain =
                            ActivityCompat.shouldShowRequestPermissionRationale(
                                this,
                                Manifest.permission.ACCESS_LOCAL_NETWORK,
                            )

                        if (!canAskAgain) {
                            val intent =
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", packageName, null)
                                }
                            startActivity(intent)
                        } else {
                            toaster.show(
                                message =
                                    context.getString(R.string.local_network_permission_denied),
                                type = ToastType.Warning,
                                duration = 6000.milliseconds,
                            )
                        }
                    }
                }

            LaunchedEffect(uiState.isAppLoaded) {
                if (
                    uiState.isAppLoaded &&
                        !hasPromptedLocalNetwork &&
                        LocalNetworkPermissionHelper.shouldRequestPermission() &&
                        !LocalNetworkPermissionHelper.isPermissionGranted(context)
                ) {
                    hasPromptedLocalNetwork = true
                    showLocalNetworkRationale = true
                }
            }

            val startingStack = buildList {
                add(Route.Tunnels)
                if (intent?.action == Intent.ACTION_APPLICATION_PREFERENCES) add(Route.Settings)
                if (
                    intent?.getBooleanExtra(EXTRA_OPEN_SUPPORT, false) == true ||
                        intent?.getBooleanExtra(EXTRA_SHOW_UPDATE, false) == true
                ) {
                    add(Route.Support)
                }
            }

            val backStack = rememberNavBackStack(*startingStack.toTypedArray())
            var previousRoute by remember { mutableStateOf<Route?>(null) }

            val navController =
                rememberNavController(
                    backStack,
                    uiState.isLocationDisclosureShown,
                    onChange = { previousKey -> previousRoute = previousKey as? Route },
                    onExitApp = { finish() },
                )

            val vpnActivity =
                rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult(),
                    onResult = {
                        if (it.resultCode != RESULT_OK) {
                            showVpnPermissionDialog = true
                            vpnPermissionDenied = true
                        } else {
                            vpnPermissionDenied = false
                            showVpnPermissionDialog = false
                            val (appMode, config) = requestingTunnelMode
                            when (appMode) {
                                TunnelMode.VPN -> if (config != null) viewModel.startTunnel(config)
                                TunnelMode.LOCK_DOWN -> viewModel.setAppMode(TunnelMode.LOCK_DOWN)
                                else -> Unit
                            }
                        }
                        requestingTunnelMode = Pair(null, null)
                    },
                )

            val notificationPermissionLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
                    when (val action = pendingNotificationAction) {
                        is NotificationPendingAction.StartTunnel ->
                            viewModel.startTunnel(action.config)
                        NotificationPendingAction.ToggleAutoTunnel -> viewModel.toggleAutoTunnel()
                        null -> Unit
                    }
                    pendingNotificationAction = null
                }

            LaunchedEffect(uiState.isAppLoaded, coldStartAutoUpdate) {
                if (!uiState.isAppLoaded || !coldStartAutoUpdate) return@LaunchedEffect
                coldStartAutoUpdate = false
                notificationService.remove(UPDATE_AVAILABLE_NOTIFICATION_ID)
                viewModel.requestSupportAutoUpdate(startDownload = true)
            }

            LaunchedEffect(uiState.isAppLoaded, coldStartShowUpdate) {
                if (!uiState.isAppLoaded || !coldStartShowUpdate) return@LaunchedEffect
                coldStartShowUpdate = false
                // Kept across recreation otherwise, which would scroll again on rotation
                intent?.removeExtra(EXTRA_SHOW_UPDATE)
                viewModel.requestShowUpdateStatus()
            }

            LaunchedEffect(Unit) {
                for (unit in showUpdateChannel) {
                    if (previousRoute !is Route.Support) {
                        navController.push(Route.Support)
                    }
                    viewModel.requestShowUpdateStatus()
                }
            }

            LaunchedEffect(Unit) {
                for (autoUpdate in supportDeepLinkChannel) {
                    notificationService.remove(UPDATE_AVAILABLE_NOTIFICATION_ID)
                    if (previousRoute !is Route.Support) {
                        navController.push(Route.Support)
                    }
                    viewModel.requestSupportAutoUpdate(startDownload = autoUpdate)
                }
            }

            LaunchedEffect(Unit) {
                viewModel.globalSideEffect.collectLatest { sideEffect ->
                    when (sideEffect) {
                        GlobalSideEffect.PopBackStack -> navController.pop()
                        is GlobalSideEffect.RequestVpnPermission -> {
                            requestingTunnelMode =
                                Pair(sideEffect.requestingMode, sideEffect.config)
                            // VpnService.prepare() returns null when the
                            // permission is already granted; launching the
                            // activity-result launcher with null input
                            // throws IllegalArgumentException and crashes
                            // the app. Treat null as "already granted"
                            // and retry the start directly.
                            val prepareIntent = VpnService.prepare(this@MainActivity)
                            if (prepareIntent == null) {
                                val (appMode, config) = requestingTunnelMode
                                when (appMode) {
                                    TunnelMode.VPN ->
                                        if (config != null) viewModel.startTunnel(config)

                                    TunnelMode.LOCK_DOWN ->
                                        viewModel.setAppMode(TunnelMode.LOCK_DOWN)

                                    else -> Unit
                                }
                                requestingTunnelMode = Pair(null, null)
                            } else {
                                vpnActivity.launch(prepareIntent)
                            }
                        }
                        is GlobalSideEffect.RequestNotificationPermission -> {
                            pendingNotificationAction = sideEffect.pendingAction
                            notificationPermissionLauncher.launch(
                                Manifest.permission.POST_NOTIFICATIONS,
                            )
                        }
                        is GlobalSideEffect.Snackbar -> snackbarChannel.send(sideEffect)
                        is GlobalSideEffect.LaunchUrl -> context.openWebUrl(sideEffect.url)
                        is GlobalSideEffect.InstallApk -> context.installApk(sideEffect.apk)
                        is GlobalSideEffect.ExportFile -> startExport(sideEffect)
                    }
                }
            }

            if (!uiState.isAppLoaded) return@setContent

            // Refresh tiles on tunnel size changes to catch deletes and adds
            LaunchedEffect(uiState.tunnelNames.size) { TunnelTileRefresher.refresh(context) }

            LaunchedEffect(Unit) {
                var currentToast: Toast? = null
                var lastShownTime = 0L

                for (sideEffect in snackbarChannel) {
                    val now = System.currentTimeMillis()
                    val timeSinceLastToast = now - lastShownTime

                    // If we have an active toast and hasn't shown for 2 seconds
                    if (currentToast != null && timeSinceLastToast < 2_000L) {
                        delay(2_000L - timeSinceLastToast)
                    }

                    // Dismiss current
                    currentToast?.let { toaster.dismiss(it) }

                    // Show new toast
                    currentToast =
                        toaster.show(
                            message = sideEffect.message.asString(context),
                            type = sideEffect.type,
                            duration = (sideEffect.durationMs ?: 4_000L).milliseconds,
                        )
                    lastShownTime = System.currentTimeMillis()
                }
            }

            val unlocked by appLockManager.unlocked.collectAsStateWithLifecycle()
            val showLock = uiState.pinLockEnabled && !unlocked

            // Keeps tunnels out of the recents screenshot and the app's reopen animation
            LaunchedEffect(uiState.pinLockEnabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    setRecentsScreenshotEnabled(!uiState.pinLockEnabled)
                }
            }

            // Imports opened from outside the app wait until the PIN has been entered
            val pendingImportUri by pendingConfigImport.collectAsStateWithLifecycle()
            LaunchedEffect(pendingImportUri, showLock) {
                val uri = pendingImportUri ?: return@LaunchedEffect
                if (showLock) return@LaunchedEffect
                pendingConfigImport.value = null
                viewModel.importFromUri(uri)
            }

            // Same look on every phone: the UI is designed for a
            // 411dp-wide phone (the reference layout). Phones with a
            // smaller "Display size" / "Font size" setting get more dp
            // and smaller text, so tiles, chips and text drift apart.
            // Normalise the app's density so the SHORT side is always
            // 411dp and the font scale is 1.0 (phones only; tablets and
            // TV keep the system values).
            // Compact UI (user 2026-11-25, approved 85% preview
            // «آره خوبه» — previews preview-compact-85-home.png /
            // preview-compact-85-settings.png): the whole app renders
            // 15% smaller on phones — every screen, same layout, just
            // smaller. The density is scaled by 0.85, so the short
            // side becomes 411/0.85 ≈ 484dp: more rows fit, and text,
            // tiles and bars all shrink together. This supersedes the
            // 2026-11-24 compact-UI cancellation — she changed her
            // mind after seeing the 85% preview.
            val systemDensity = LocalDensity.current
            val screenConfig = LocalConfiguration.current
            val appDensity =
                remember(systemDensity, screenConfig, isTv) {
                    val shortDp = minOf(screenConfig.screenWidthDp, screenConfig.screenHeightDp)
                    if (isTv || shortDp <= 0 || shortDp >= 600) {
                        systemDensity
                    } else {
                        val shortPx = shortDp * systemDensity.density
                        Density(density = shortPx / 411f * 0.85f, fontScale = 1f)
                    }
                }
            CompositionLocalProvider(
                LocalDensity provides appDensity,
                LocalIsAndroidTV provides isTv,
                LocalNavController provides navController,
                LocalAppLocked provides showLock,
            ) {
                WireguardAutoTunnelTheme(theme = uiState.theme) {
                    VpnDeniedDialog(
                        showVpnPermissionDialog,
                        onDismiss = {
                            showVpnPermissionDialog = false
                            vpnPermissionDenied = false
                        },
                    )

                    if (showLocalNetworkRationale) {
                        LocalNetworkPermissionDialog(
                            onDismiss = {
                                showLocalNetworkRationale = false
                                toaster.show(
                                    message =
                                        context.getString(R.string.local_network_permission_denied),
                                    type = ToastType.Warning,
                                    duration = 6000.milliseconds,
                                )
                            },
                            onAttest = {
                                showLocalNetworkRationale = false

                                localNetworkPermissionLauncher.launch(
                                    Manifest.permission.ACCESS_LOCAL_NETWORK,
                                )
                            },
                        )
                    }

                    val strictSplitNotice by
                        viewModel.strictSplitNotice.collectAsStateWithLifecycle()
                    strictSplitNotice
                        ?.takeUnless { showLock }
                        ?.let { notice ->
                            val openAdvanced = {
                                // Back from Advanced lands on Settings, as if opened from there
                                navController.popUpTo(Route.Settings)
                                navController.push(Route.Advanced)
                            }
                            when (notice) {
                                StrictSplitNotice.ENABLED ->
                                    StrictSplitNoticeSheet(
                                        notice = notice,
                                        onConfirm = viewModel::acknowledgeStrictSplitNotice,
                                        onSecondary = {
                                            viewModel.acknowledgeStrictSplitNotice()
                                            openAdvanced()
                                        },
                                        onDismiss = viewModel::acknowledgeStrictSplitNotice,
                                    )
                                StrictSplitNotice.SUGGESTED ->
                                    StrictSplitNoticeSheet(
                                        notice = notice,
                                        onConfirm = { viewModel.answerStrictSplitSuggestion(true) },
                                        onSecondary = {
                                            viewModel.answerStrictSplitSuggestion(false)
                                        },
                                        onDismiss = {
                                            viewModel.answerStrictSplitSuggestion(false)
                                        },
                                    )
                            }
                        }

                    uiState.pendingWgImportUrl
                        ?.takeUnless { showLock }
                        ?.let { url ->
                            val host = Uri.parse(url).host ?: url
                            InfoDialog(
                                onDismiss = { viewModel.dismissWgImport() },
                                onAttest = { viewModel.importFromUrl(url) },
                                title = stringResource(R.string.add_from_url),
                                body = {
                                    Text(stringResource(R.string.wg_url_confirm_message, host))
                                },
                                confirmText = stringResource(R.string.okay),
                            )
                        }

                    val isPinVisible by remember { derivedStateOf { showLock } }

                    val currentRoute by remember {
                        derivedStateOf { backStack.lastOrNull() as? Route }
                    }

                    // Shuttle: screenshots must work on the main screens
                    // (home, tunnel list, logs, settings). FLAG_SECURE is
                    // only applied while the PIN lock screen is visible —
                    // and only if the user enabled screen-recording
                    // protection — never for the app's normal screens.
                    // (The stored setting defaults to true in the DB, so
                    // gating on the route alone would keep blocking
                    // screenshots on existing installs.)
                    LaunchedEffect(
                        uiState.isScreenRecordingProtectionEnabled,
                        isPinVisible,
                    ) {
                        val shouldProtect =
                            uiState.isScreenRecordingProtectionEnabled && isPinVisible

                        if (shouldProtect) {
                            window.setFlags(
                                WindowManager.LayoutParams.FLAG_SECURE,
                                WindowManager.LayoutParams.FLAG_SECURE,
                            )
                        } else {
                            delay(500L)
                            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            awaitCancellation()
                        }
                    }

                    Box(modifier = Modifier.fillMaxSize()) {
                        // Composed behind the lock so unlocking reveals a screen that is already
                        // laid
                        // out. While locked it is hidden from accessibility and cannot take focus.
                        Box(modifier = Modifier.fillMaxSize().lockedContent(showLock)) {
                            val currentTab by remember {
                                derivedStateOf { Tab.fromRoute(currentRoute ?: Route.Tunnels) }
                            }
                            val navState by
                                currentRouteAsNavbarState(
                                    uiState,
                                    viewModel,
                                    currentRoute,
                                    navController,
                                )

                            Box(modifier = Modifier.fillMaxSize()) {
                                if (uiState.tunnelMode == TunnelMode.LOCK_DOWN) {
                                    AppAlertBanner(
                                        stringResource(R.string.locked_down)
                                            .uppercase(Locale.current.platformLocale),
                                        OffWhite,
                                        AlertRed,
                                        modifier = Modifier.fillMaxWidth().zIndex(2f),
                                    )
                                }
                                // Telegram-style frosted bars (user
                                // 17:46–17:49): the floating bars are
                                // gradient scrims (see ShuttleHaze.kt)
                                // — Haze was removed in 1.5 because its
                                // progressive blur never rendered on
                                // her phone. No HazeState, no source:
                                // the scrim is drawn by the bars
                                // themselves.
                                // The home top bar's clearance,
                                // from TWO measured edges in the same
                                // frame (fix14): the bar's CONTENT
                                // bottom edge and the list's top edge,
                                // both in root coordinates. The old
                                // fix13 formula subtracted the status
                                // bar from a measurement that never
                                // contained it (statusBarsPadding()
                                // sits OUTSIDE onGloballyPositioned,
                                // so coords.size.height EXCLUDES the
                                // status bar) — the chips→hero gap
                                // came out as 18dp minus the status
                                // bar, so a tall status bar (Honor,
                                // ~36-40dp) pushed the gap to about
                                // -20dp and the chips covered the hero.
                                // Measuring both edges makes the gap
                                // exactly the approved 10dp on every
                                // phone, whatever its status bar.
                                // The "content" edge is the bottom of
                                // the bar's last VISIBLE row (the
                                // chips in normal mode, the mode row
                                // in reorder/selection mode), reported
                                // by ShuttleHomeTopBar — NOT the bar's
                                // layout bottom. The layout extends
                                // 18dp below the content (8dp Column
                                // spacedBy + 10dp fade Spacer), so
                                // measuring the layout bottom put the
                                // hero 28dp below the chips in 50811
                                // (fix15). 158dp is the first-frame
                                // default (156dp content to the chips
                                // + 10dp gap, minus the list's 8dp
                                // top inset), used before the first
                                // measurement lands.
                                var homeTopBarHeight by remember { mutableStateOf(158.dp) }
                                val density = LocalDensity.current
                                // The two measured edges, in pixels,
                                // root coordinates (null until the
                                // first layout pass reports them).
                                var homeContentBottomPx by remember { mutableStateOf<Float?>(null) }
                                var homeListTopPx by remember { mutableStateOf<Float?>(null) }
                                // Recompute the clearance once both
                                // edges are known; until then the
                                // 158dp default stands.
                                // The bar's own layout height (px). A second,
                                // independent source for the clearance: the
                                // two-edge measurement above compares root
                                // coordinates of two different composables and
                                // can lag or disagree on some phones (the hero
                                // then sits flush against / under the chips).
                                var homeBarHeightPx by remember { mutableStateOf<Int?>(null) }
                                fun refreshHomeTopBarHeight() {
                                    val contentBottom = homeContentBottomPx
                                    val listTop = homeListTopPx
                                    val twoEdge =
                                        if (contentBottom != null && listTop != null)
                                            topPaddingFor(contentBottom, listTop, density)
                                        else null
                                    val fromBar =
                                        homeBarHeightPx?.let {
                                            topPaddingFromBarHeight(it, density)
                                        }
                                    // Take the LARGER of the two: if either source
                                    // is right the hero clears the chips; a rare
                                    // slightly-bigger gap is far better than an
                                    // overlap.
                                    homeTopBarHeight =
                                        listOfNotNull(twoEdge, fromBar).maxOrNull() ?: return
                                }
                                // On the home route the top/bottom bars
                                // are FLOATING overlays over the
                                // scrolling list (user 17:41), not
                                // Scaffold slots — so the list scrolls
                                // beneath the frosted bars and the
                                // LazyColumn's contentPadding keeps
                                // every row clear of them. ALL sub-screens
                                // float the same way (user 2026-11-25:
                                // their Scaffold-slot bars showed no fade
                                // at all, because content never scrolled
                                // under them) — except the lock screen,
                                // which keeps the Scaffold slots. Settings
                                // floats like home since 2026-11-24
                                // (top/bottom fade exactly like the home
                                // page).
                                val isHome = currentRoute == Route.Tunnels
                                val isSettings = currentRoute == Route.Settings
                                // Every sub-screen except the lock screen
                                // floats its bars (fade fix, user
                                // 2026-11-25): its content clears the
                                // bars itself (status bar + 70dp top,
                                // 140dp bottom, like SettingsScreen).
                                val isFloatingSubScreen =
                                    currentRoute !is Route.Tunnels &&
                                        currentRoute !is Route.Settings &&
                                        currentRoute !is Route.Lock
                                Scaffold(
                                    // One consistent surface colour for
                                    // the whole top area (user 17:43):
                                    // the old background-coloured band
                                    // under the search capsule is gone.
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    topBar = {
                                        if (!isHome && !isSettings && !isFloatingSubScreen) {
                                            DynamicTopAppBar(navState)
                                        }
                                    },
                                    bottomBar = {
                                        if (!isHome && !isSettings && !isFloatingSubScreen &&
                                            navState.showBottomItems
                                        ) {
                                            BottomNavbar(
                                                uiState.isAutoTunnelActive,
                                                currentTab,
                                                onTabSelected = { tab ->
                                                    navController.popUpTo(tab.startRoute)
                                                },
                                            )
                                        }
                                    },
                                ) { padding ->
                                    Column(
                                        modifier =
                                            Modifier.fillMaxSize()
                                                .background(MaterialTheme.colorScheme.surface)
                                                .padding(
                                                    // Floating routes (home, Settings,
                                                    // restyled sub-screens): no Scaffold
                                                    // slot padding — the screen clears
                                                    // the floating bars itself (status
                                                    // bar + 70dp top, 140dp bottom, like
                                                    // home's list). The Scaffold insets
                                                    // must NOT be consumed either, or the
                                                    // screen's own statusBarsPadding()
                                                    // would read zero.
                                                    top =
                                                        if (isSettings || isFloatingSubScreen) 0.dp
                                                        else
                                                            padding.calculateTopPadding()
                                                                .plus(8.dp),
                                                    bottom =
                                                        if (isSettings || isFloatingSubScreen) 0.dp
                                                        else padding.calculateBottomPadding(),
                                                )
                                                .then(
                                                    if (isSettings || isFloatingSubScreen) Modifier
                                                    else Modifier.consumeWindowInsets(padding),
                                                ),
                                    ) {
                                        BackHandler(enabled = uiState.selectedTunnelCount > 0) {
                                            viewModel.clearSelectedTunnels()
                                        }
                                        NavDisplay(
                                            backStack = backStack,
                                            modifier = Modifier.fillMaxSize(),
                                            onBack = { navController.pop() },
                                            transitionSpec = {
                                                val initialIndex =
                                                    previousRoute?.let(Tab::fromRoute)?.index ?: 0
                                                val targetIndex =
                                                    currentRoute?.let(Tab::fromRoute)?.index ?: 0
                                                if (initialIndex != targetIndex) {
                                                    val dir =
                                                        if (targetIndex > initialIndex) 1 else -1
                                                    (slideInHorizontally { dir * it } +
                                                        fadeIn()) togetherWith
                                                        (slideOutHorizontally { dir * -it } +
                                                            fadeOut())
                                                } else {
                                                    (slideInHorizontally { it } +
                                                        fadeIn()) togetherWith
                                                        (slideOutHorizontally { -it } + fadeOut())
                                                }
                                            },
                                            popTransitionSpec = {
                                                (slideInHorizontally { -it } +
                                                    fadeIn()) togetherWith
                                                    (slideOutHorizontally { it } + fadeOut())
                                            },
                                            predictivePopTransitionSpec = {
                                                (slideInHorizontally { -it } +
                                                    fadeIn()) togetherWith
                                                    (slideOutHorizontally { it } + fadeOut())
                                            },
                                            entryDecorators =
                                                listOf(
                                                    rememberSaveableStateHolderNavEntryDecorator(),
                                                    rememberViewModelStoreNavEntryDecorator(),
                                                ),
                                            entryProvider =
                                                entryProvider {
                                                    entry<Route.Lock> { PinLockScreen() }
                                                    entry<Route.Tunnels> {
                                                        TunnelsScreen(
                                                            homeTopBarHeight = homeTopBarHeight,
                                                            onListTopPx = { top ->
                                                                if (homeListTopPx != top) {
                                                                    homeListTopPx = top
                                                                    refreshHomeTopBarHeight()
                                                                }
                                                            },
                                                        )
                                                    }
                                                    entry<Route.TunnelSettings> { key ->
                                                        val viewModel: TunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        TunnelSettingsScreen(viewModel)
                                                    }
                                                    entry<Route.Config> { key ->
                                                        val viewModel: TunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        ConfigScreen(viewModel, key.live)
                                                    }
                                                    entry<Route.SplitTunnel> { key ->
                                                        val viewModel: SplitTunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        SplitTunnelScreen(viewModel)
                                                    }
                                                    entry<Route.ConfigEdit> { key ->
                                                        val viewModel: ConfigEditViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        ConfigEditScreen(viewModel)
                                                    }
                                                    entry<Route.OpenVpnEdit> { key ->
                                                        val viewModel: OpenVpnEditViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        OpenVpnEditScreen(viewModel)
                                                    }
                                                    entry<Route.LocationDisclosure> {
                                                        LocationDisclosureScreen()
                                                    }
                                                    entry<Route.AutoTunnel> { AutoTunnelScreen() }
                                                    entry<Route.WifiPreferences> {
                                                        WifiSettingsScreen()
                                                    }
                                                    entry<Route.WifiDetectionMethod> {
                                                        WifiDetectionMethodScreen()
                                                    }
                                                    entry<Route.Settings> { SettingsScreen() }
                                                    entry<Route.AndroidIntegrations> {
                                                        AndroidIntegrationsScreen()
                                                    }
                                                    entry<Route.Dns> { DnsSettingsScreen() }
                                                    entry<Route.ConfigGlobal> {
                                                        GlobalAmneziaScreen()
                                                    }
                                                    entry<Route.GlobalAmnezia> {
                                                        GlobalAmneziaScreen()
                                                    }
                                                    entry<Route.SplitTunnelGlobal> { key ->
                                                        val viewModel: SplitTunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        SplitTunnelScreen(viewModel)
                                                    }
                                                    entry<Route.IPv6> { key ->
                                                        val viewModel: TunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        IPv6Screen(viewModel)
                                                    }
                                                    entry<Route.EntryTunnel> { key ->
                                                        val viewModel: TunnelViewModel =
                                                            koinViewModel(
                                                                parameters = {
                                                                    parametersOf(key.id)
                                                                },
                                                            )
                                                        EntryTunnelScreen(viewModel)
                                                    }
                                                    entry<Route.LockdownSettings> {
                                                        LockdownSettingsScreen()
                                                    }
                                                    entry<Route.ProxySettings> {
                                                        ProxySettingsScreen()
                                                    }
                                                    entry<Route.Appearance> { AppearanceScreen() }
                                                    entry<Route.Language> { LanguageScreen() }
                                                    entry<Route.Display> { DisplayScreen() }
                                                    entry<Route.Notifications> {
                                                        NotificationsScreen()
                                                    }
                                                    entry<Route.Logs> { LogsScreen() }
                                                    entry<Route.Support> { SupportScreen() }
                                                    entry<Route.License> { LicenseScreen() }
                                                    entry<Route.PreferredTunnel> { key ->
                                                        PreferredTunnelScreen(key.tunnelNetwork)
                                                    }
                                                    entry<Route.TunnelGlobals> { AdvancedScreen() }
                                                    entry<Route.Advanced> { AdvancedScreen() }
                                                    entry<Route.Security> { SecurityScreen() }
                                                    entry<Route.Monitoring> { MonitoringScreen() }
                                                    entry<Route.TunnelRecovery> {
                                                        MonitoringScreen()
                                                    }
                                                    entry<Route.MonitoringAndRecovery> {
                                                        MonitoringScreen()
                                                    }
                                                },
                                        )
                                    }
                                }
                                // Home overlays (user 17:41): on the
                                // home route the bars float OVER the
                                // list, composed after the Scaffold so
                                // they draw above it. The top bar sits
                                // below the status bar; the bottom nav
                                // at the very bottom. The lockdown
                                // banner (zIndex 2f) stays above both.
                                if (isHome) {
                                    // The home top bar is a plain Box,
                                    // NOT a Material3 TopAppBar (user
                                    // 18:48): the TopAppBar never
                                    // blurred on her phone — the
                                    // capsules floated over the hero
                                    // with no frosted backdrop. The
                                    // bar holds the capsules, the
                                    // search and the chips in one
                                    // frosted unit (see
                                    // ShuttleHomeTopBar). Its height
                                    // is measured and passed to the
                                    // list so the hero never slides
                                    // under it (fix11: chips covered
                                    // the hero title in 1.4).
                                    val homeSearchQuery by
                                        viewModel.searchQuery.collectAsStateWithLifecycle()
                                    val homeSelectedGroupId by
                                        viewModel.selectedGroupId.collectAsStateWithLifecycle()
                                    val homeTunnelsUiState by
                                        viewModel.tunnelsUiState.collectAsStateWithLifecycle()
                                    val homeGroupCounts =
                                        remember(homeTunnelsUiState.tunnels) {
                                            homeTunnelsUiState.tunnels
                                                .filter { it.groupId != null }
                                                .groupingBy { it.groupId!! }.eachCount()
                                        }
                                    ShuttleHomeTopBar(
                                        navState,
                                        searchQuery = homeSearchQuery,
                                        onSearchQueryChange = viewModel::setSearchQuery,
                                        selectedGroupId = homeSelectedGroupId,
                                        allCount = homeTunnelsUiState.tunnels.size,
                                        groups = homeTunnelsUiState.groups,
                                        groupCounts = homeGroupCounts,
                                        onSelectGroup = viewModel::setSelectedGroupFilter,
                                        onAddGroupClick = {
                                            viewModel.postSideEffect(
                                                LocalSideEffect.Sheet.CreateGroup,
                                            )
                                        },
                                        onGroupLongPress = { group ->
                                            viewModel.postSideEffect(
                                                LocalSideEffect.Sheet.GroupActions(group),
                                            )
                                        },
                                        // The bar's VISIBLE content bottom
                                        // (chips / mode row), reported by
                                        // ShuttleHomeTopBar (fix15) — NOT
                                        // the bar's layout bottom, which
                                        // sits 18dp lower (fade zone).
                                        onBarHeightPx = { h ->
                                            if (homeBarHeightPx != h) {
                                                homeBarHeightPx = h
                                                refreshHomeTopBarHeight()
                                            }
                                        },
                                        onContentBottomPx = { bottom ->
                                            if (homeContentBottomPx != bottom) {
                                                homeContentBottomPx = bottom
                                                refreshHomeTopBarHeight()
                                            }
                                        },
                                        modifier =
                                            Modifier.align(Alignment.TopCenter)
                                                .statusBarsPadding(),
                                    )
                                    if (navState.showBottomItems) {
                                        BottomNavbar(
                                            uiState.isAutoTunnelActive,
                                            currentTab,
                                            onTabSelected = { tab ->
                                                navController.popUpTo(tab.startRoute)
                                            },
                                            modifier = Modifier.align(Alignment.BottomCenter),
                                        )
                                    }
                                }
                                // Floating overlays (user 2026-11-24 22:13, extended
                                // 2026-11-25 to all sub-screens): the same
                                // floating bars as home, so the list scrolls beneath
                                // the frosted top bar and bottom nav and fades
                                // gradually at both edges. The top bar is the same
                                // DynamicTopAppBar (same shuttleTopScrim) and the
                                // bottom nav is the same BottomNavbar, so the fade
                                // is exactly home's. The list's own padding
                                // (status bar + 70dp top, 140dp bottom — see
                                // SettingsScreen) keeps every row clear of the bars.
                                if (isSettings || isFloatingSubScreen) {
                                    // No statusBarsPadding here: the bar
                                    // starts at y=0 so its scrim covers the
                                    // status-bar strip too — otherwise
                                    // scrolled content shows sharp under
                                    // the clock/battery (user 2026-11-24
                                    // 23:56). The list's top padding
                                    // (SettingsScreen) keeps the 10dp gap.
                                    DynamicTopAppBar(
                                        navState,
                                        modifier = Modifier.align(Alignment.TopCenter),
                                    )
                                    if (navState.showBottomItems) {
                                        BottomNavbar(
                                            uiState.isAutoTunnelActive,
                                            currentTab,
                                            onTabSelected = { tab ->
                                                navController.popUpTo(tab.startRoute)
                                            },
                                            modifier = Modifier.align(Alignment.BottomCenter),
                                        )
                                    }
                                }
                                // Toasts draw in their own window above the lock, so they wait for
                                // unlock
                                if (!showLock) {
                                    Toaster(
                                        state = toaster,
                                        maxVisibleToasts = 1,
                                        alignment = Alignment.BottomCenter,
                                        // Toasts float above the bottom nav. User
                                        // 2026-11-24 22:41: the "Checking for
                                        // updates" popup sat too close to the nav —
                                        // raised from -220 to -280 (60px higher).
                                        offset = IntOffset(0, -280),
                                        richColors = true,
                                        background = {
                                            Brush.linearGradient(
                                                listOf(
                                                    MaterialTheme.colorScheme
                                                        .surfaceColorAtElevation(
                                                            2.dp,
                                                        ),
                                                    MaterialTheme.colorScheme
                                                        .surfaceColorAtElevation(
                                                            2.dp,
                                                        ),
                                                ),
                                            )
                                        },
                                        elevation = 1.dp,
                                        shadowAmbientColor =
                                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                        shadowSpotColor =
                                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
                                        border = {
                                            BorderStroke(
                                                0.dp,
                                                androidx.compose.ui.graphics.Color.Transparent,
                                            )
                                        },
                                        actionSlot = { toast ->
                                            (toast.action as? TextToastAction)?.let { action ->
                                                TextButton(
                                                    onClick = { action.onClick(toast) },
                                                    colors =
                                                        ButtonDefaults.textButtonColors(
                                                            contentColor =
                                                                MaterialTheme.colorScheme.primary,
                                                        ),
                                                    modifier = Modifier.fillMaxWidth(.25f),
                                                    contentPadding =
                                                        PaddingValues(horizontal = 12.dp),
                                                ) {
                                                    Text(
                                                        text = action.text,
                                                        fontWeight = FontWeight.Medium,
                                                        softWrap = true,
                                                        maxLines = 5,
                                                    )
                                                }
                                            }
                                        },
                                        iconSlot = { toast ->
                                            val (icon, color) =
                                                (toast.icon as? ImageVector)?.let {
                                                    it to MaterialTheme.colorScheme.primary
                                                }
                                                    ?: when (toast.type) {
                                                        ToastType.Success ->
                                                            Icons.Outlined.CheckCircleOutline to
                                                                SilverTree
                                                        ToastType.Error ->
                                                            Icons.Outlined.ErrorOutline to AlertRed
                                                        ToastType.Warning ->
                                                            Icons.Outlined.WarningAmber to Straw
                                                        ToastType.Info ->
                                                            Icons.Outlined.Info to
                                                                MaterialTheme.colorScheme.onSurface
                                                        ToastType.Normal ->
                                                            Icons.Outlined.FavoriteBorder to Heart
                                                    }
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = null,
                                                tint = color,
                                                modifier = Modifier.padding(end = 12.dp),
                                            )
                                        },
                                        contentColor = { MaterialTheme.colorScheme.onSurface },
                                        shape = { RoundedCornerShape(16.dp) },
                                        closeButton = { toast ->
                                            ToastCloseButton(
                                                onClick = { toaster.dismiss(toast) },
                                                modifier = Modifier.align(Alignment.TopEnd),
                                                offset = DpOffset(8.dp, (-8).dp),
                                            )
                                        },
                                    )
                                }
                            }
                        }

                        val lockAlpha = remember { Animatable(if (showLock) 1f else 0f) }
                        LaunchedEffect(showLock) {
                            if (showLock) lockAlpha.snapTo(1f)
                            else lockAlpha.animateTo(0f, tween(durationMillis = LOCK_FADE_OUT_MS))
                        }
                        if (showLock || lockAlpha.value > 0f) {
                            Box(
                                modifier =
                                    Modifier.fillMaxSize().graphicsLayer {
                                        alpha = if (showLock) 1f else lockAlpha.value
                                    },
                            ) {
                                PinLockOverlay(active = showLock, backKey = backStack.size) {
                                    finish()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handleWgDeepLinkIntent(intent: Intent) {
        if (intent.action == Intent.ACTION_VIEW) {
            val uri = intent.data ?: return
            if (uri.scheme == "wg") {
                val httpsUrl = uri.toString().replaceFirst("wg://", "https://")
                viewModel.promptWgImport(httpsUrl)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Before the first frame back, rather than after the foreground event reaches the lock
        appLockManager.relockIfExpired()
    }

    override fun onResume() {
        super.onResume()
        networkMonitor.checkPermissionsAndUpdateState()
        ShuttleWidgetProvider.refreshAll(this)
    }

    fun beginBackup(password: String?) {
        pendingBackupPassword = password
        if (isRunningOnTv()) {
            lifecycleScope.launch {
                showBackupResult(databaseBackup.backupTo(uri = null, password))
            }
        } else {
            createBackupLauncher.launch(databaseBackup.newBackupFileName())
        }
    }

    fun beginRestore(password: String?) {
        pendingBackupPassword = password
        openBackupLauncher.launch(
            arrayOf(
                FileUtils.ZIP_FILE_MIME_TYPE,
                FileUtils.OCTET_STREAM_MIME_TYPE,
                "application/vnd.sqlite3",
                FileUtils.ALL_FILE_TYPES,
            ),
        )
    }

    fun restoreFromUri(uri: Uri, password: String?) {
        lifecycleScope.launch { finishRestore(databaseBackup.restore(uri, password)) }
    }

    private suspend fun finishRestore(result: RestoreResult) {
        if (result == RestoreResult.Success) {
            restartProcess()
        } else {
            showRestoreResult(result)
        }
    }

    private suspend fun showBackupResult(result: BackupWriteResult) {
        val message =
            when (result) {
                BackupWriteResult.Success ->
                    StringValue.StringResource(R.string.backup_success) to ToastType.Success
                is BackupWriteResult.SavedToDownloads ->
                    StringValue.StringResource(R.string.backup_saved_downloads, result.fileName) to
                        ToastType.Success
                BackupWriteResult.Failed ->
                    StringValue.StringResource(R.string.backup_failed) to ToastType.Error
            }
        viewModel.postSideEffect(GlobalSideEffect.Snackbar(message.first, message.second))
    }

    private suspend fun showRestoreResult(result: RestoreResult) {
        val message =
            when (result) {
                RestoreResult.WrongPassword -> R.string.restore_failed_wrong_password
                RestoreResult.InvalidFile -> R.string.restore_failed_invalid_file
                RestoreResult.NewerVersion -> R.string.restore_failed_newer_version
                RestoreResult.Failed,
                RestoreResult.Success -> R.string.restore_failed
            }
        viewModel.postSideEffect(
            GlobalSideEffect.Snackbar(
                StringValue.StringResource(message),
                ToastType.Error,
            ),
        )
    }

    private fun restartProcess() {
        val intent =
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
        startActivity(intent)
        finishAffinity()
        exitProcess(0)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleConfigFileIntent(intent)
        handleWgDeepLinkIntent(intent)
        enqueueSupportDeepLink(intent)
    }

    private fun enqueueSupportDeepLink(intent: Intent?) {
        if (intent?.getBooleanExtra(EXTRA_SHOW_UPDATE, false) == true) {
            intent.removeExtra(EXTRA_SHOW_UPDATE)
            showUpdateChannel.trySend(Unit)
        }
        if (intent?.getBooleanExtra(EXTRA_OPEN_SUPPORT, false) != true) return
        val autoUpdate = intent.getBooleanExtra(EXTRA_AUTO_UPDATE, false)
        intent.removeExtra(EXTRA_OPEN_SUPPORT)
        intent.removeExtra(EXTRA_AUTO_UPDATE)
        supportDeepLinkChannel.trySend(autoUpdate)
    }

    private fun handleConfigFileIntent(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Intent.ACTION_VIEW,
            Intent.ACTION_EDIT,
            Intent.ACTION_SEND -> {
                val uri: Uri? = intent.data ?: return
                val name = uri?.lastPathSegment?.lowercase() ?: return
                if (
                    !name.endsWith(FileUtils.CONF_FILE_EXTENSION) &&
                        !name.endsWith(FileUtils.ZIP_FILE_EXTENSION)
                ) {
                    Timber.d("Ignoring non-config URI in handleIncomingIntent: $uri")
                    return
                }
                pendingConfigImport.value = uri
            }
        }
    }
}

private const val LOCK_FADE_OUT_MS = 220

private fun Modifier.lockedContent(locked: Boolean): Modifier =
    this.then(if (locked) Modifier.clearAndSetSemantics {} else Modifier)
        .focusProperties { onEnter = { if (locked) cancelFocusChange() } }
        .focusGroup()

/**
 * Home top clearance from two measured edges (fix14, fix15): the
 * top bar's VISIBLE content bottom edge (the chips row in normal
 * mode, the mode row in reorder/selection mode — reported by
 * ShuttleHomeTopBar) and the list's top edge, both in root pixels.
 * The hero sits exactly the approved 10dp below the CONTENT on
 * every phone — the status bar height cancels out, so a tall
 * status bar (Honor) cannot push the gap negative the way the old
 * height-minus-status-bar formula did. Floored at 10dp, so a
 * degenerate measurement never hides the hero under the bar.
 * NOTE (fix15): the first argument must be the CONTENT bottom,
 * NOT the bar's layout bottom. The layout extends 18dp below the
 * content (8dp Column spacedBy + 10dp fade Spacer); feeding the
 * layout bottom put the hero 28dp below the chips in 50811.
 */
internal fun topPaddingFor(contentBottomPx: Float, listTopPx: Float, density: Density): Dp =
    with(density) { (contentBottomPx - listTopPx).toDp() + 10.dp }.coerceAtLeast(10.dp)

/**
 * Clearance from the top bar's OWN layout height alone (px, status bar
 * excluded). The bar's layout extends 18dp below its visible content
 * (8dp Column spacing + 10dp fade spacer); the list starts 8dp below
 * the bar's top; the hero sits 10dp below the content. So
 * clearance = (barHeight - 18) - 8 + 10 = barHeight - 16dp.
 * Needs no root coordinates, so it cannot be stale or clipped.
 */
internal fun topPaddingFromBarHeight(barHeightPx: Int, density: Density): Dp =
    with(density) { barHeightPx.toDp() - 16.dp }.coerceAtLeast(10.dp)
