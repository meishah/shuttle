package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.CallMerge
import androidx.compose.material.icons.automirrored.outlined.CallSplit
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.DataUsage
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.components.SplitAppsDescription
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.TunnelViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState

/**
 * Restyled like Settings (user 2026-11-25, approved preview): every
 * section sits in a big rounded card with tinted-squircle icons,
 * chevrons on navigation rows and lime switches. Rows and actions
 * unchanged.
 */
@Composable
fun TunnelSettingsScreen(
    viewModel: TunnelViewModel,
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val navController = LocalNavController.current

    val sharedUiState by sharedViewModel.collectAsState()

    val uiState by viewModel.collectAsState()

    if (uiState.isLoading) return
    val tunnel = uiState.tunnel ?: return

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding()
                .padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.configuration))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Description) },
                    title = stringResource(R.string.view_configuration),
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    onClick = { navController.push(Route.Config(tunnel.id)) },
                    containerColor = Color.Transparent,
                )
                if (uiState.activeConfig != null) {
                    ShuttleSettingsDivider()
                    SurfaceRow(
                        leading = { ShuttleSettingIcon(Icons.Outlined.Bolt) },
                        title = stringResource(R.string.view_live_tunnel),
                        trailing = { modifier ->
                            Icon(
                                Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                                contentDescription = null,
                                modifier = modifier,
                            )
                        },
                        onClick = { navController.push(Route.Config(tunnel.id, true)) },
                        containerColor = Color.Transparent,
                    )
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.general))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Star) },
                    title = stringResource(R.string.primary_tunnel),
                    description = {
                        Text(
                            text = stringResource(R.string.set_primary_tunnel),
                            style =
                                MaterialTheme.typography.bodySmall.copy(
                                    MaterialTheme.colorScheme.outline,
                                ),
                        )
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = tunnel.isPrimaryTunnel,
                            onClick = { viewModel.togglePrimaryTunnel() },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    onClick = { viewModel.togglePrimaryTunnel() },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.multihop))
            ShuttleSettingsCard {
                val selectedEntry =
                    uiState.userTunnels.firstOrNull { it.id == tunnel.entryTunnelId }
                val entryLabel = selectedEntry?.name ?: stringResource(R.string.entry_tunnel_none)
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(Icons.AutoMirrored.Outlined.CallMerge)
                    },
                    title = stringResource(R.string.entry_tunnel),
                    description = { DescriptionText(entryLabel) },
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    onClick = { navController.push(Route.EntryTunnel(tunnel.id)) },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.network))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(Icons.AutoMirrored.Outlined.CallSplit)
                    },
                    enabled = sharedUiState.tunnelMode != TunnelMode.PROXY,
                    title = stringResource(R.string.splt_tunneling),
                    description = {
                        if (sharedUiState.tunnelMode == TunnelMode.PROXY) {
                            DescriptionText(
                                stringResource(R.string.unavailable_in_mode),
                                disabled = true,
                            )
                        } else {
                            uiState.appliedSplit?.let { SplitAppsDescription(it) }
                        }
                    },
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    onClick = { navController.push(Route.SplitTunnel(id = tunnel.id)) },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Public) },
                    title = stringResource(R.string.ipv6_settings),
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    onClick = { navController.push(Route.IPv6(tunnel.id)) },
                    containerColor = Color.Transparent,
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val meteredDisabled = sharedUiState.tunnelMode == TunnelMode.PROXY
                    val meteredTunnelDesc =
                        if (meteredDisabled) stringResource(R.string.unavailable_in_mode)
                        else stringResource(R.string.metered_tunnel_desc)
                    ShuttleSettingsDivider()
                    SurfaceRow(
                        leading = { ShuttleSettingIcon(Icons.Outlined.DataUsage) },
                        title = stringResource(R.string.metered_tunnel),
                        enabled = sharedUiState.tunnelMode != TunnelMode.PROXY,
                        description = {
                            DescriptionText(meteredTunnelDesc, disabled = meteredDisabled)
                        },
                        trailing = { modifier ->
                            SwitchWithDivider(
                                checked = tunnel.isMetered,
                                onClick = { viewModel.onMetered(it) },
                                enabled = sharedUiState.tunnelMode != TunnelMode.PROXY,
                                modifier = modifier,
                                checkedTrackColor = LimeConnect,
                                // No page behind this row — it only flips
                                // the switch (user 2026-11-25).
                                showChevron = false,
                            )
                        },
                        onClick = { viewModel.onMetered(!tunnel.isMetered) },
                        containerColor = Color.Transparent,
                    )
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.automation))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Dns) },
                    title = stringResource(R.string.ddns_auto_update),
                    description = {
                        DescriptionText(text = stringResource(R.string.ddns_auto_update_description))
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = tunnel.isDDNSTunnel,
                            onClick = { viewModel.onDDNSTunnel(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    onClick = { viewModel.onDDNSTunnel(!tunnel.isDDNSTunnel) },
                    containerColor = Color.Transparent,
                )
            }
        }
    }
}
