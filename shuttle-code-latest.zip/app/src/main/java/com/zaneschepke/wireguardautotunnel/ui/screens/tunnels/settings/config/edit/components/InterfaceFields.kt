package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.config.edit.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsFieldCard
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.common.textbox.ConfigurationTextBox
import com.zaneschepke.wireguardautotunnel.ui.state.ConfigUiState
import com.zaneschepke.wireguardautotunnel.ui.state.EditableInterface

/**
 * Interface fields grouped into big rounded cards (user 2026-11-25,
 * same design as Settings): Interface (name + keys), DNS & MTU,
 * Scripts, then the Amnezia groups. Fields and actions unchanged.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterfaceFields(
    uiState: ConfigUiState,
    onInterfaceChange: (EditableInterface) -> Unit,
    onTunnelNameChange: (String) -> Unit,
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() })
    val keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ShuttleSettingsFieldCard {
            ConfigurationTextBox(
                value = uiState.draft.tunnelName,
                enabled = !uiState.isRunning,
                onValueChange = onTunnelNameChange,
                label = stringResource(R.string.name),
                isError = uiState.isTunnelNameTaken,
                supportingText =
                    if (uiState.isRunning) {
                        {
                            DescriptionText(
                                stringResource(R.string.tunnel_running_name_message),
                            )
                        }
                    } else null,
                hint =
                    stringResource(
                            R.string.hint_template,
                            stringResource(R.string.tunnel_name),
                        )
                        .lowercase(locale = Locale.current.platformLocale),
                modifier = Modifier.fillMaxWidth(),
            )
            BasicInterfaceFields(
                interfaceState = uiState.draft.config.`interface`,
                onInterfaceChange = onInterfaceChange,
                showPrivateKey = uiState.ui.showSensitiveData,
                keyboardOptions = keyboardOptions,
                keyboardActions = keyboardActions,
            )
        }

        val managedDns =
            if (uiState.globalSettings.dnsEnabled) uiState.globalInterface?.dnsServers else null
        val managedAmnezia =
            if (uiState.globalSettings.amneziaEnabled) uiState.globalInterface else null

        ShuttleSettingsFieldCard {
            DnsMtuSection(
                interfaceState = uiState.draft.config.`interface`,
                onInterfaceChange = onInterfaceChange,
                globalDnsServers = managedDns,
            )
        }

        if (uiState.ui.showScripts) {
            ShuttleSettingsFieldCard {
                ScriptsSection(uiState.draft.config.`interface`, onInterfaceChange)
            }
        }

        if (uiState.ui.showAmneziaValues || managedAmnezia != null) {
            AmneziaSection(
                uiState.draft.config.`interface`,
                onInterfaceChange,
                globalValues = managedAmnezia,
            )
        }
    }
}
