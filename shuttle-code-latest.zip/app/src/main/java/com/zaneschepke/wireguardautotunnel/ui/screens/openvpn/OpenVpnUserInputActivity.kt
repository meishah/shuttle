package com.zaneschepke.wireguardautotunnel.ui.screens.openvpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.ui.theme.WireguardAutoTunnelTheme
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

/**
 * Prompt shown when the OpenVPN core needs credentials mid-connection
 * (username/password, private-key password, or a challenge response).
 *
 * Reached via the implicit intent `com.shuttle.vpn.OPENVPN_USER_INPUT`
 * forwarded by the :openvpn module's LaunchVPN stub. The intent carries
 * only the "need" string — the profile is resolved from the currently
 * active OpenVPN tunnel, since only one tunnel runs at a time.
 */
class OpenVpnUserInputActivity : ComponentActivity() {

    private val openVpnCoordinator: OpenVpnCoordinator by inject()
    private val tunnelRepository: TunnelRepository by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val need = intent.getStringExtra("need") ?: NEED_AUTH
        val activeId = openVpnCoordinator.activeTunnelId.value
        if (activeId == null) {
            finish()
            return
        }
        lifecycleScope.launch {
            val config = tunnelRepository.getById(activeId)
            if (config == null || !config.isOpenVpn) {
                finish()
                return@launch
            }
            setContent {
                WireguardAutoTunnelTheme {
                    OpenVpnUserInputScreen(
                        tunnelName = config.name,
                        need = need,
                        savedUsername = config.ovpnUsername,
                        onSubmit = { username, password, rememberPassword ->
                            lifecycleScope.launch {
                                openVpnCoordinator.provideCredentials(
                                    config = config,
                                    username = username,
                                    password = password,
                                    rememberPassword = rememberPassword,
                                )
                                finish()
                            }
                        },
                        onCancel = {
                            openVpnCoordinator.stop()
                            finish()
                        },
                    )
                }
            }
        }
    }

    companion object {
        const val NEED_AUTH = "Auth"
        const val NEED_PRIVATE_KEY = "Private Key"
    }
}

@Composable
private fun OpenVpnUserInputScreen(
    tunnelName: String,
    need: String,
    savedUsername: String,
    onSubmit: (username: String, password: String, rememberPassword: Boolean) -> Unit,
    onCancel: () -> Unit,
) {
    val isAuth = need == OpenVpnUserInputActivity.NEED_AUTH
    val isPrivateKey = need == OpenVpnUserInputActivity.NEED_PRIVATE_KEY
    var username by remember { mutableStateOf(savedUsername) }
    var password by remember { mutableStateOf("") }
    var rememberPassword by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier.padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = tunnelName,
            style = MaterialTheme.typography.titleLarge,
        )
        Text(
            text =
                stringResource(
                    when {
                        isPrivateKey -> R.string.ovpn_need_private_key
                        isAuth -> R.string.ovpn_need_auth
                        else -> R.string.ovpn_need_challenge
                    },
                ),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (isAuth) {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = {
                    Text(
                        stringResource(R.string.username),
                        // Explicit colour on the label Text itself
                        // (user 2026-11-27): the 1.4.2 focusedLabelColor
                        // had no effect on-device — the label stayed
                        // near-white. An explicit color here always wins.
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                },
                singleLine = true,
                // Explicit label colours (user 2026-11-27): the
                // default focused label rendered near-white on the
                // light background and was unreadable.
                colors =
                    OutlinedTextFieldDefaults.colors(
                        focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = {
                Text(
                    stringResource(
                        when {
                            isPrivateKey -> R.string.ovpn_private_key_password
                            isAuth -> R.string.password
                            else -> R.string.ovpn_challenge_response
                        },
                    ),
                    // Same explicit label colour as the username field
                    // above (user 2026-11-27).
                    color = MaterialTheme.colorScheme.onSurface,
                )
            },
            singleLine = true,
            colors =
                OutlinedTextFieldDefaults.colors(
                    focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        if (isAuth) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = rememberPassword,
                    onCheckedChange = { rememberPassword = it },
                )
                Text(stringResource(R.string.ovpn_remember_password))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            TextButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.cancel))
            }
            Button(
                onClick = { onSubmit(username, password, rememberPassword) },
                enabled = password.isNotEmpty() && (!isAuth || username.isNotEmpty()),
                modifier = Modifier.weight(1f),
            ) {
                Text(stringResource(R.string.ovpn_connect))
            }
        }
    }
}
