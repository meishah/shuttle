package com.zaneschepke.wireguardautotunnel.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import timber.log.Timber

class DataStoreManager(
    private val context: Context,
    private val ioDispatcher: CoroutineDispatcher,
) {
    private val preferencesKey = "preferences"
    val Context.dataStore by preferencesDataStore(name = preferencesKey)
    val dataStore = context.dataStore

    companion object {
        val locationDisclosureShown = booleanPreferencesKey("LOCATION_DISCLOSURE_SHOWN")
        val batteryDisableShown = booleanPreferencesKey("BATTERY_OPTIMIZE_DISABLE_SHOWN")
        val notificationPermissionRequested =
            booleanPreferencesKey("NOTIFICATION_PERMISSION_REQUESTED")
        val shouldShowDonationSnackbar = booleanPreferencesKey("SHOW_DONATION_SNACK")
        val desktopPromptShown = booleanPreferencesKey("DESKTOP_PROMPT_SHOWN")
        val strictSplitDecided = booleanPreferencesKey("STRICT_SPLIT_DECIDED")
        val strictSplitNotice = stringPreferencesKey("STRICT_SPLIT_NOTICE")
        val lastActiveTunnelIds = stringPreferencesKey("LAST_ACTIVE_TUNNEL_IDS")
        // The tunnel the user last connected to. Unlike
        // LAST_ACTIVE_TUNNEL_IDS (cleared on a clean disconnect so a
        // process restart does not resurrect tunnels), this is kept
        // across disconnects and restarts so the hero Connect button,
        // the Quick Settings tile and the widget reconnect to the same
        // tunnel instead of the first one in the list.
        val lastUsedTunnelId = intPreferencesKey("LAST_USED_TUNNEL_ID")
        // The group filter the user last left the app on (All = null),
        // restored on start so reopening the app shows the same
        // group instead of resetting to All (user 19:56: "هر وقت
        // اپو باز میکنم میره روی پوشه all, میخوام رو همون پوشه ای
        // که قبلا بودم بمونه").
        val selectedGroupId = intPreferencesKey("SELECTED_GROUP_ID")
        // The update version the "update available" dialog was last
        // shown for (user 2026-11-27): the dialog on app open shows
        // once per version — it must not reappear on the next open for
        // the same version, only for a newer one.
        val lastShownUpdateVersion = stringPreferencesKey("LAST_SHOWN_UPDATE_VERSION")
    }

    suspend fun init() {
        withContext(ioDispatcher) {
            try {
                dataStore.data.first()
            } catch (e: IOException) {
                Timber.e(e)
            }
        }
    }

    suspend fun <T> saveToDataStore(key: Preferences.Key<T>, value: T) {
        withContext(ioDispatcher) {
            try {
                dataStore.edit { it[key] = value }
            } catch (e: IOException) {
                Timber.e(e)
            } catch (e: Exception) {
                Timber.e(e)
            }
        }
    }

    suspend fun <T> removeFromDataStore(key: Preferences.Key<T>) {
        withContext(ioDispatcher) {
            try {
                dataStore.edit { it.remove(key) }
            } catch (e: IOException) {
                Timber.e(e)
            } catch (e: Exception) {
                Timber.e(e)
            }
        }
    }

    fun <T> getFromStoreFlow(key: Preferences.Key<T>) = context.dataStore.data.map { it[key] }

    suspend fun <T> getFromStore(key: Preferences.Key<T>): T? {
        return withContext(ioDispatcher) {
            try {
                dataStore.data.map { it[key] }.first()
            } catch (e: IOException) {
                Timber.e(e)
                null
            }
        }
    }

    val preferencesFlow: Flow<Preferences?> = dataStore.data.flowOn(ioDispatcher)
}
