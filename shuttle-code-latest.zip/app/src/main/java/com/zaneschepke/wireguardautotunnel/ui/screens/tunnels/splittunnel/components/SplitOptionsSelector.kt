package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleSettingsCardColor
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.state.SplitBehavior
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender

/**
 * Split mode as three pills in one rounded container (user
 * 2026-11-25, approved preview): tap a pill to switch directly.
 * Replaces the old "Split mode" row + bottom sheet; the per-mode
 * descriptions from the sheet are gone with it.
 */
@Composable
fun SplitBehaviorOptions(
    activeBehavior: SplitBehavior,
    onBehaviorChange: (SplitBehavior) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(shuttleSettingsCardColor())
                .padding(4.dp),
    ) {
        SplitBehavior.entries.forEach { behavior ->
            val selected = activeBehavior == behavior
            Box(
                contentAlignment = Alignment.Center,
                modifier =
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (selected) OrionLavender else Color.Transparent)
                        .clickable { onBehaviorChange(behavior) }
                        .padding(vertical = 10.dp),
            ) {
                Text(
                    text = behavior.label(),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color =
                        if (selected) OnSelectedCapsule
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun SplitBehavior.label(): String =
    stringResource(
        when (this) {
            SplitBehavior.ALL -> R.string.split_tunnel_all_label
            SplitBehavior.INCLUDE -> R.string.split_tunnel_include_label
            SplitBehavior.EXCLUDE -> R.string.split_tunnel_exclude_label
        },
    )
