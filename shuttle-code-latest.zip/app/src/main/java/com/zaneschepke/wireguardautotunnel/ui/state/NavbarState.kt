package com.zaneschepke.wireguardautotunnel.ui.state

import androidx.compose.runtime.Composable

data class NavbarState(
    val topTitle: String? = null,
    val topTrailing: (@Composable () -> Unit)? = null,
    val topLeading: (@Composable () -> Unit)? = null,
    val showBottomItems: Boolean = false,
    /** Show the real Shuttle app icon next to the title (Tunnels screen). */
    val showShuttleMark: Boolean = false,
    /**
     * Show the title inside a lavender capsule (user 2026-11-25):
     * every sub-screen's name sits in a capsule like the SHUTTLE
     * capsule on Home. Set automatically for sub-screen routes;
     * Tunnels keeps its own showShuttleMark logic (plain text while
     * selecting / reordering).
     */
    val titleCapsule: Boolean = false,
)
