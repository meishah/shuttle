package com.zaneschepke.wireguardautotunnel.notification

import android.text.format.Formatter
import androidx.compose.ui.graphics.toArgb
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.NotificationAction
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelActionSource
import com.zaneschepke.wireguardautotunnel.notification.AndroidNotificationService.NotificationChannels
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.TUNNEL_ERROR_NOTIFICATION_ID
import com.zaneschepke.wireguardautotunnel.notification.NotificationService.Companion.TUNNEL_MESSAGES_NOTIFICATION_ID
import com.zaneschepke.wireguardautotunnel.ui.state.DisplayTunnelState

class AndroidTunnelNotificationService(private val notificationService: NotificationService) :
    TunnelNotificationService {

    private val context = notificationService.context

    private fun createGroupNotification(
        tunnelNotificationLines: Map<Int, TunnelNotificationLine>,
        channel: NotificationChannels.Tunnel,
        options: TunnelNotificationOptions,
        lockdown: Boolean = false,
    ): android.app.Notification {
        val singleTunnel = tunnelNotificationLines.size == 1
        val promote =
            options.liveUpdatesEnabled &&
                NotificationManagerCompat.from(context).canPostPromotedNotifications()

        val kind =
            when {
                lockdown -> context.getString(R.string.lockdown)
                channel is NotificationChannels.Tunnel.VPN -> context.getString(R.string.vpn)
                channel is NotificationChannels.Tunnel.Proxy -> context.getString(R.string.proxy)
                else -> context.getString(R.string.vpn)
            }

        val title =
            when {
                singleTunnel -> "$kind • ${tunnelNotificationLines.values.first().name}"
                else -> kind
            }

        val formattedLines =
            tunnelNotificationLines.values.map { line ->
                formatLine(line, includeName = !singleTunnel, options = options)
            }

        // Collapsed view: one short line only (status + transfer), so
        // the notification is compact like other apps'. The full
        // multi-line details (Status / Transfer / Duration) live in
        // the BigTextStyle expanded view below — nothing is removed.
        val description =
            if (singleTunnel) {
                collapsedLine(tunnelNotificationLines.values.first(), options)
            } else {
                formattedLines.joinToString("\n")
            }

        val actions =
            when {
                singleTunnel ->
                    listOf(
                        notificationService.createNotificationAction(
                            notificationAction = NotificationAction.TUNNEL_OFF,
                            extraId = tunnelNotificationLines.keys.first(),
                            authenticationRequired = true,
                        ),
                    )
                tunnelNotificationLines.isNotEmpty() ->
                    listOf(
                        notificationService.createNotificationAction(
                            notificationAction = NotificationAction.STOP_ALL,
                            extraId = null,
                            authenticationRequired = true,
                        ),
                    )
                else -> emptyList()
            }

        val style =
            when {
                tunnelNotificationLines.size > 1 ->
                    NotificationCompat.InboxStyle()
                        .setBigContentTitle(title)
                        .setSummaryText(
                            "${tunnelNotificationLines.size} ${context.getString(R.string.tunnels).lowercase()}",
                        )
                        .also { inbox -> formattedLines.forEach { inbox.addLine(it) } }
                // Single tunnel: expanded view shows the full lines
                // (Status / Transfer / Duration) via BigTextStyle; the
                // collapsed view shows only the one-line description.
                else -> NotificationCompat.BigTextStyle().bigText(formattedLines.joinToString("\n"))
            }

        val shortCriticalText = if (promote) kind else null

        val color =
            if (
                options.showFailureTint &&
                    tunnelNotificationLines.values.any {
                        it.displayState == DisplayTunnelState.HandshakeFailure
                    }
            ) {
                DisplayTunnelState.HandshakeFailure.asColor().toArgb()
            } else {
                null
            }

        return notificationService.createNotification(
            channel = channel,
            title = title,
            description = description,
            actions = actions,
            onGoing = true,
            onlyAlertOnce = true,
            // Header shows the app name only — no chronometer, no
            // timestamp (Mei: the "Shuttle 02:26" time in the header
            // is removed). Duration lives only as the "Duration:"
            // line in the expanded view, refreshed on re-post.
            showTimestamp = false,
            style = style,
            requestPromotedOngoing = promote,
            shortCriticalText = shortCriticalText,
            chronometerBaseMillis = null,
            color = color,
        )
    }

    /**
     * Collapsed notification line: status + transfer only, one short
     * line (e.g. "Connected • ↓ 1.46 MB ↑ 406 kB"). The Duration line
     * is NOT here — it appears only in the expanded BigTextStyle
     * view. No live speed, ever.
     */
    private fun collapsedLine(
        line: TunnelNotificationLine,
        options: TunnelNotificationOptions,
    ): String {
        val parts = mutableListOf(line.displayState.asLocalizedString(context))
        if (options.showTransfer) {
            parts +=
                "↓ ${Formatter.formatFileSize(context, line.rxBytes)} " +
                    "↑ ${Formatter.formatFileSize(context, line.txBytes)}"
        }
        return parts.joinToString(" • ")
    }

    private fun formatLine(
        line: TunnelNotificationLine,
        includeName: Boolean,
        options: TunnelNotificationOptions,
    ): String {
        val parts = labeledParts(line, options)
        return if (includeName) {
            (listOf(line.name) + parts).joinToString(" • ")
        } else {
            parts.joinToString("\n")
        }
    }

    /** Connection duration as HH:MM:SS (e.g. 00:12:34) from the connect timestamp. */
    private fun formatDurationHms(startedAtMillis: Long): String {
        val seconds = ((System.currentTimeMillis() - startedAtMillis) / 1000).coerceAtLeast(0L)
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return "${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}"
    }

    private fun labeledParts(
        line: TunnelNotificationLine,
        options: TunnelNotificationOptions,
    ): List<String> {
        val parts = mutableListOf<String>()
        parts +=
            context.getString(
                R.string.notification_status_format,
                line.displayState.asLocalizedString(context),
            )
        if (!line.viaName.isNullOrBlank()) {
            parts += context.getString(R.string.via_entry, line.viaName)
        }
        if (options.showOrigin) {
            when (line.origin) {
                TunnelActionSource.USER ->
                    parts +=
                        context.getString(
                            R.string.notification_source_format,
                            context.getString(R.string.notification_connection_manual),
                        )
                TunnelActionSource.AUTO_TUNNEL ->
                    parts +=
                        context.getString(
                            R.string.notification_source_format,
                            context.getString(R.string.notification_connection_auto),
                        )
                null -> Unit
            }
        }
        if (options.showTransfer) {
            parts +=
                context.getString(
                    R.string.notification_transfer_format,
                    Formatter.formatFileSize(context, line.rxBytes),
                    Formatter.formatFileSize(context, line.txBytes),
                )
            // Shuttle change #7: connection duration right next to the
            // data volume (no live speed, ever). This text line
            // refreshes when the notification is re-posted — the
            // transfer line is bucketed to 2 s, see
            // AppProvider.persistentNotificationKey. The Duration line
            // shows ONLY in the expanded BigTextStyle view; the header
            // has no chronometer and no timestamp.
            line.startedAtMillis?.let { startedAt ->
                parts +=
                    context.getString(
                        R.string.notification_duration_format,
                        formatDurationHms(startedAt),
                    )
            }
        }
        if (options.showRecovery && line.recoveryAttempts > 0) {
            parts += context.getString(R.string.notification_recovery_format, line.recoveryAttempts)
        }
        return parts
    }

    override fun buildVpnPersistentNotification(
        tunnelNotificationLines: Map<Int, TunnelNotificationLine>,
        options: TunnelNotificationOptions,
        lockdown: Boolean,
    ): android.app.Notification {
        return createGroupNotification(
            tunnelNotificationLines,
            NotificationChannels.Tunnel.VPN,
            options,
            lockdown = lockdown,
        )
    }

    override fun buildProxyPersistentNotification(
        tunnelNotificationLines: Map<Int, TunnelNotificationLine>,
        options: TunnelNotificationOptions,
    ): android.app.Notification {
        return createGroupNotification(
            tunnelNotificationLines,
            NotificationChannels.Tunnel.Proxy,
            options,
        )
    }

    override fun showIpv4Fallback(tunnelName: String) {
        showEvent(
            title = "${context.getString(R.string.ipv4_fallback)} • $tunnelName",
            message = context.getString(R.string.notification_ipv4_fallback_message, tunnelName),
        )
    }

    override fun showIpv6Recovery(tunnelName: String) {
        showEvent(
            title = "${context.getString(R.string.ipv6_recovery)} • $tunnelName",
            message = context.getString(R.string.notification_ipv6_recovery_message, tunnelName),
        )
    }

    override fun showDynamicDnsUpdate(tunnelName: String) {
        showEvent(
            title = "${context.getString(R.string.dynamic_dns_update)} • $tunnelName",
            message = context.getString(R.string.notification_dynamic_dns_message, tunnelName),
        )
    }

    override fun showSeamlessRecoveryAttempt(tunnelName: String) {
        showEvent(
            title = "${context.getString(R.string.seamless_recovery)} • $tunnelName",
            message = context.getString(R.string.seamless_recovery_attempt_message),
        )
    }

    override fun showVpnRequired() {
        showError(notificationService.context.getString(R.string.vpn_permission_required))
    }

    override fun showRootShellAccess() {
        // TODO could improve with fix action
        val context = notificationService.context
        showError(context.getString(R.string.error_root_denied))
    }

    override fun showSocks5PortUnavailable(port: Int, tunnelName: String) {
        showErrorNotification(
            title = "${context.getString(R.string.error)} • $tunnelName",
            message = context.getString(R.string.error_socks5_port_unavailable, port),
        )
    }

    override fun showHttpPortUnavailable(port: Int, tunnelName: String) {
        showErrorNotification(
            title = "${context.getString(R.string.error)} • $tunnelName",
            message = context.getString(R.string.error_http_port_unavailable, port),
        )
    }

    override fun showConfigMissingDns(tunnelName: String) {
        val context = notificationService.context
        val message = context.getString(R.string.error_config_missing_dns, tunnelName)
        showError(message)
    }

    override fun showError(message: String) {
        showErrorNotification(title = context.getString(R.string.error), message = message)
    }

    private fun showErrorNotification(title: String, message: String) {
        val notification =
            notificationService.createNotification(
                channel = NotificationChannels.Errors,
                title = title,
                description = message,
                onGoing = false,
                onlyAlertOnce = true,
                style = NotificationCompat.BigTextStyle().bigText(message),
            )

        notificationService.show(TUNNEL_ERROR_NOTIFICATION_ID, notification)
    }

    private fun showEvent(title: String, message: String) {
        val notification =
            notificationService.createNotification(
                channel = NotificationChannels.Events,
                title = title,
                description = message,
                onGoing = false,
                onlyAlertOnce = true,
            )

        notificationService.show(TUNNEL_MESSAGES_NOTIFICATION_ID, notification)
    }
}
