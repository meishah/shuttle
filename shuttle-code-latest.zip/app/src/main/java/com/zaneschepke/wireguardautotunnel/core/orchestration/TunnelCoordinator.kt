package com.zaneschepke.wireguardautotunnel.core.orchestration

import com.dokar.sonner.ToastType
import com.wgtunnel.backend.model.BackendMode
import com.wgtunnel.parser.AmneziaConfigNormalizer
import com.wgtunnel.parser.Config
import com.wgtunnel.parser.ConfigReconciler
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.event.TunnelErrorEvent
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnState
import com.zaneschepke.wireguardautotunnel.core.tunnel.StrictSplitDefaults
import com.zaneschepke.wireguardautotunnel.core.tunnel.TunnelProvider
import com.zaneschepke.wireguardautotunnel.data.repository.RoomDnsSettingsRepository
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelActionSource
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.domain.events.TunnelActionEvent
import com.zaneschepke.wireguardautotunnel.domain.model.DnsSettings
import com.zaneschepke.wireguardautotunnel.domain.model.GeneralSettings
import com.zaneschepke.wireguardautotunnel.domain.model.LockdownSettings
import com.zaneschepke.wireguardautotunnel.domain.model.MonitoringSettings
import com.zaneschepke.wireguardautotunnel.domain.model.ProxySettings
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.repository.AppStateRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.GeneralSettingRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.GlobalEffectRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.LockdownSettingsRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.MonitoringSettingsRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.ProxySettingsRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.GlobalSideEffect
import com.zaneschepke.wireguardautotunnel.service.ServiceManager
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.toTunnelDnsConfigOrNull
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber

class TunnelCoordinator(
    private val tunnelProvider: TunnelProvider,
    private val serviceManager: ServiceManager,
    private val bootstrapCoordinator: AppBoostrapCoordinator,
    settingsRepository: GeneralSettingRepository,
    private val tunnelRepository: TunnelRepository,
    dnsSettingsRepository: RoomDnsSettingsRepository,
    monitoringSettingsRepository: MonitoringSettingsRepository,
    globalEffectRepository: GlobalEffectRepository,
    proxyRepository: ProxySettingsRepository,
    lockdownModeRepository: LockdownSettingsRepository,
    private val appStateRepository: AppStateRepository,
    private val strictSplitDefaults: StrictSplitDefaults,
    private val openVpnCoordinator: OpenVpnCoordinator,
    scope: CoroutineScope,
) {

    // Invoked synchronously inside the user action's lock, so an auto tunnel action queued behind
    // it already sees the override when it checks its guard
    @Volatile var userOverrideListener: (() -> Unit)? = null

    private fun markUserOverride() {
        userOverrideListener?.invoke()
    }

    data class RuntimeSettingsSnapshot(
        val general: GeneralSettings,
        val dns: DnsSettings,
        val monitoring: MonitoringSettings,
        val proxy: ProxySettings,
        val lockdown: LockdownSettings,
    )

    private val runtimeSettingsSnapshot =
        combine(
            settingsRepository.flow,
            dnsSettingsRepository.flow,
            monitoringSettingsRepository.flow,
            proxyRepository.flow,
            lockdownModeRepository.flow,
        ) { general, dns, monitoring, proxy, lockdown ->
            RuntimeSettingsSnapshot(
                general = general,
                dns = dns,
                monitoring = monitoring,
                proxy = proxy,
                lockdown = lockdown,
            )
        }

    private val _actions = MutableSharedFlow<TunnelActionEvent>(extraBufferCapacity = 8)
    val actions = _actions.asSharedFlow()

    private val runtimeSettingsSnapshotState =
        runtimeSettingsSnapshot.stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = null,
        )

    val backendStatus = tunnelProvider.backendStatus

    init {
        scope.launch {
            combine(
                    runtimeSettingsSnapshot,
                    tunnelRepository.userTunnelsFlow,
                    backendStatus,
                ) { snapshot, tunnels, status ->
                    val activeIds = status.activeTunnels.keys
                    LiveTunnelFeatureKey(
                        statsEnabled = snapshot.monitoring.tunnelStatisticsEnabled,
                        statsInterval = snapshot.monitoring.tunnelStatisticsPollInterval,
                        seamlessRecovery = snapshot.general.seamlessRecoveryEnabled,
                        bounceDelaySec = snapshot.general.seamlessRecoveryBounceDelaySec,
                        perTunnel =
                            tunnels.associate { tun ->
                                tun.id to
                                    Triple(
                                        tun.isDDNSTunnel,
                                        tun.isIpv6Preferred,
                                        tun.ipv6RestoreEnabled,
                                    )
                            },
                    ) to
                        LiveTunnelFeaturePayload(
                            general = snapshot.general,
                            monitoring = snapshot.monitoring,
                            tunnels = tunnels.filter { it.id in activeIds },
                        )
                }
                .distinctUntilChangedBy { it.first }
                .drop(1)
                .collect { (_, payload) ->
                    payload.tunnels.forEach { config ->
                        tunnelProvider
                            .updateTunnel(
                                config.toBackendTunnel(
                                    payload.monitoring,
                                    payload.general.tunnelScriptingEnabled,
                                    payload.general,
                                ),
                            )
                            .onFailure {
                                Timber.e(
                                    it,
                                    "Failed to apply live tunnel features to tunnel ${config.id}",
                                )
                            }
                            .onSuccess {
                                globalEffectRepository.post(
                                    GlobalSideEffect.Snackbar(
                                        message =
                                            StringValue.StringResource(
                                                R.string.active_tunnel_updated,
                                            ),
                                        ToastType.Success,
                                    ),
                                )
                            }
                    }
                }
        }
    }

    private data class LiveTunnelFeatureKey(
        val statsEnabled: Boolean,
        val statsInterval: Int,
        val seamlessRecovery: Boolean,
        val bounceDelaySec: Int,
        val perTunnel: Map<Int, Triple<Boolean, Boolean, Boolean>>,
    )

    private data class LiveTunnelFeaturePayload(
        val general: GeneralSettings,
        val monitoring: MonitoringSettings,
        val tunnels: List<TunnelConfig>,
    )

    private suspend fun getSnapshot(): RuntimeSettingsSnapshot {
        return runtimeSettingsSnapshotState.filterNotNull().first()
    }

    private var lastActiveTunnels: List<Int> = emptyList()
    private val tunnelMutex = Mutex()
    private val _errors = MutableSharedFlow<TunnelErrorEvent>()
    val errors = _errors.asSharedFlow()

    suspend fun awaitReady() {
        bootstrapCoordinator.isReady.first { it }
    }

    suspend fun startTunnel(
        config: TunnelConfig,
        source: TunnelActionSource = TunnelActionSource.USER,
    ) = tunnelMutex.withLock {
        // wait for app to be bootstrapped
        bootstrapCoordinator.isReady.first { it }

        if (source == TunnelActionSource.USER) {
            markUserOverride()
        }

        startExclusive(config, source)
    }

    // enforce single tunnel, for now. We do not clear the last active here as start success
    // replaces it
    private suspend fun startExclusive(config: TunnelConfig, source: TunnelActionSource) {
        // Remember the tunnel the user connected to, so the hero Connect
        // button, the tile and the widget reconnect to THIS tunnel after
        // a disconnect — not the first tunnel in the list. Persisted:
        // survives app restarts (unlike lastActiveTunnels, which is
        // in-memory and cleared on a clean stop).
        appStateRepository.setLastUsedTunnelId(config.id)
        if (
            backendStatus.value.activeTunnels.isNotEmpty() ||
                openVpnCoordinator.activeTunnelId.value != null
        ) {
            // Switch, not a fresh connect: stop the old tunnel FIRST
            // and wait until it is actually gone before starting the
            // new one. Starting the new tunnel on the return of the
            // stop call alone used to drop the switch — the old
            // tunnel's teardown is asynchronous (the OpenVPN core
            // dies on a management SIGINT that may land late, and the
            // WireGuard backend gives up waiting for its VpnService
            // after 1500ms), so the new start raced the dying old
            // tunnel, failed, and left the user disconnected with
            // nothing connecting. The switch is sequential, never
            // overlapping: the new tunnel starts only once the old
            // one is observed stopped.
            val stopResult = stopActiveTunnelsInternal(source, persistLastActive = false)
            if (stopResult.isFailure) {
                Timber.e(
                    stopResult.exceptionOrNull(),
                    "Switch to ${config.name}: previous tunnel would not stop",
                )
                _errors.emit(TunnelErrorEvent.SwitchStopFailed(config.id))
                return
            }
            when (awaitPreviousStopped(SWITCH_STOP_TIMEOUT_MS)) {
                StopWaitResult.STOPPED,
                StopWaitResult.ONLY_OVPN_UNCONFIRMED -> Unit // proceed to start below
                StopWaitResult.STILL_ACTIVE -> {
                    // The old tunnel is still up: starting the new one
                    // now would overlap two tunnels. Abort the switch
                    // with a clear error instead of leaving an
                    // ambiguous state — the user can tap again.
                    _errors.emit(TunnelErrorEvent.SwitchStopFailed(config.id))
                    return
                }
            }
        }
        // No TunnelActionEvent.Started is emitted for OpenVPN here —
        // the OpenVPN bridge reports the real state
        // (connecting/connected) and the UI gates on that.
        if (config.isOpenVpn) {
            openVpnCoordinator.start(config)
            replaceLastActiveTunnelIds(setOf(config.id))
            return
        }

        startTunnelInternal(config, source)
    }

    /**
     * Result of waiting for the previous tunnel(s) to die before a
     * switch/restart starts the next one.
     */
    private enum class StopWaitResult {
        /** Nothing is active any more: safe to start the next tunnel. */
        STOPPED,

        /**
         * Only the OpenVPN core's death confirmation is missing. The
         * WireGuard side is fully down and the OpenVPN tunnel is
         * already marked disconnected — its core is almost certainly
         * dead already (its death callback is legitimately lost when
         * the management socket is down). Safe to proceed: a late
         * NOTCONNECTED from the old core is generation-guarded in
         * [OpenVpnCoordinator], and a genuinely lingering core makes
         * the new start fail loudly instead of silently.
         */
        ONLY_OVPN_UNCONFIRMED,

        /** A previous tunnel is still up: starting another would overlap. */
        STILL_ACTIVE,
    }

    /**
     * Waits until the previous tunnel(s) are actually gone — observed
     * on the state flows, not on the stop call's return: the stop
     * calls return before the old core has finished dying. Runs under
     * [tunnelMutex], so no other start/stop can interleave while
     * waiting. Returns [StopWaitResult.STILL_ACTIVE] on timeout with a
     * tunnel still up.
     */
    private suspend fun awaitPreviousStopped(timeoutMs: Long): StopWaitResult {
        val stopped = withTimeoutOrNull(timeoutMs) {
            combine(
                    backendStatus,
                    openVpnCoordinator.activeTunnelId,
                    openVpnCoordinator.state,
                    openVpnCoordinator.stopConfirmed,
                ) { status, ovpnId, ovpnState, stopConfirmed ->
                    status.activeTunnels.isEmpty() &&
                        ovpnId == null &&
                        ovpnState is OpenVpnState.Disconnected &&
                        stopConfirmed
                }
                .first { it }
            true
        } ?: false
        if (stopped) return StopWaitResult.STOPPED
        return if (backendStatus.value.activeTunnels.isEmpty()) {
            Timber.w(
                "Switch: only the OpenVPN stop is unconfirmed after ${timeoutMs}ms; proceeding (guarded)",
            )
            StopWaitResult.ONLY_OVPN_UNCONFIRMED
        } else {
            Timber.w(
                "Switch: previous tunnel still active after ${timeoutMs}ms; aborting switch",
            )
            StopWaitResult.STILL_ACTIVE
        }
    }

    suspend fun stopTunnel(id: Int, source: TunnelActionSource = TunnelActionSource.USER) =
        tunnelMutex.withLock {
            if (source == TunnelActionSource.USER) {
                markUserOverride()
            }
            stopTunnelInternal(id, source)
        }

    /** Start/stop without taking [tunnelMutex], only reachable through [exclusively]. */
    inner class Exclusive internal constructor() {
        suspend fun start(config: TunnelConfig, source: TunnelActionSource) =
            startExclusive(config, source)

        suspend fun stop(id: Int, source: TunnelActionSource) = stopTunnelInternal(id, source)
    }

    private val exclusive = Exclusive()

    /**
     * Runs [block] holding the lock every start/stop holds, so a caller can decide and act without
     * anything changing in between.
     */
    suspend fun <T> exclusively(block: suspend (Exclusive) -> T): T = tunnelMutex.withLock {
        block(exclusive)
    }

    suspend fun stopActiveTunnels(source: TunnelActionSource = TunnelActionSource.USER) =
        tunnelMutex.withLock {
            if (source == TunnelActionSource.USER) {
                markUserOverride()
            }
            stopActiveTunnelsInternal(source, persistLastActive = true)
        }

    private suspend fun startTunnelInternal(
        tunnelConfig: TunnelConfig,
        source: TunnelActionSource,
    ) {

        val snapshot = getSnapshot()
        var settings = snapshot.general
        val dnsSettings = snapshot.dns
        val proxySettings = snapshot.proxy
        val monitoringSettings = snapshot.monitoring
        val lockdownSettings = snapshot.lockdown

        var config = tunnelConfig.getConfig()

        // makes sure Amnezia configs are 2.0 compatible
        config = AmneziaConfigNormalizer.ensureAmneziaCompatibility(config)

        val policy =
            ConfigReconciler.ConfigReconcilePolicy(
                dnsSettings.isGlobalTunnelConfigDnsEnabled,
                settings.isGlobalSplitTunnelEnabled,
                settings.isGlobalAmneziaEnabled,
            )

        val globalConfig =
            if (policy.hasAnyOverrides) {
                tunnelRepository.globalTunnelFlow.firstOrNull()?.getConfig()
            } else {
                null
            }

        val runConfig =
            if (policy.hasAnyOverrides) {
                ConfigReconciler.reconcileConfig(config, globalConfig, policy)
            } else config

        settings = strictSplitDefaults.beforeStart(settings, runConfig)

        val tunnelDnsConfig = dnsSettings.toTunnelDnsConfigOrNull(runConfig)
        val outerConfig = resolveOuterConfig(tunnelConfig, globalConfig, policy)

        val backendMode =
            when (settings.tunnelMode) {
                TunnelMode.VPN -> {

                    if (!serviceManager.hasVpnPermission()) {
                        _errors.emit(TunnelErrorEvent.VpnPermissionDenied(tunnelConfig.id))
                        return
                    }

                    BackendMode.Vpn(runConfig)
                }

                TunnelMode.PROXY -> {
                    BackendMode.Proxy.Standard(
                        config = runConfig,
                        proxyConfig = proxySettings.toProxyConfig(),
                    )
                }

                TunnelMode.LOCK_DOWN -> {
                    BackendMode.Proxy.KillSwitchPrimary(
                        runConfig,
                        lockdownSettings.toKillSwitchConfig(),
                    )
                }
            }

        tunnelProvider
            .startTunnel(
                tunnel =
                    tunnelConfig.toBackendTunnel(
                        monitoringSettings,
                        settings.tunnelScriptingEnabled,
                        settings,
                    ),
                mode = backendMode,
                tunnelDnsConfig = tunnelDnsConfig,
                outerConfig = outerConfig,
            )
            .onSuccess {
                _actions.emit(
                    TunnelActionEvent.Started(tunnelId = tunnelConfig.id, source = source),
                )
                replaceLastActiveTunnelIds(
                    tunnelProvider.backendStatus.value.activeTunnels.keys + tunnelConfig.id,
                )
            }
            .onFailure {
                Timber.e(it)
                _errors.emit(TunnelErrorEvent.from(it, tunnelConfig.id))
            }
    }

    private suspend fun resolveOuterConfig(
        exit: TunnelConfig,
        globalConfig: Config?,
        policy: ConfigReconciler.ConfigReconcilePolicy,
    ): Config? {
        val entryId = exit.entryTunnelId ?: return null
        if (entryId == exit.id) {
            Timber.w("Ignoring self-referential entry tunnel on ${exit.name}")
            return null
        }
        val entry = tunnelRepository.getById(entryId)
        if (entry == null) {
            Timber.w("Entry tunnel id=$entryId missing for ${exit.name}; starting one-hop")
            return null
        }
        return runCatching {
            var outer = AmneziaConfigNormalizer.ensureAmneziaCompatibility(entry.getConfig())
            if (policy.amnezia) {
                outer =
                    ConfigReconciler.reconcileConfig(
                        outer,
                        globalConfig,
                        ConfigReconciler.ConfigReconcilePolicy(
                            dns = false,
                            splitTunnel = false,
                            amnezia = true,
                        ),
                    )
            }
            outer
        }
            .onFailure {
                Timber.e(it, "Failed to load entry tunnel ${entry.name} for ${exit.name}")
            }
            .getOrNull()
    }

    suspend fun startDefault() {
        tunnelRepository.getDefaultTunnel()?.let { tunnel -> startTunnel(tunnel) }
    }

    suspend fun restartActiveTunnels() = tunnelMutex.withLock {
        val configs =
            backendStatus.value.activeTunnels.keys.mapNotNull { tunnelRepository.getById(it) }
        if (configs.isEmpty()) return@withLock
        // Same switch race as startExclusive: the restart must wait
        // until the old tunnels are actually gone before starting
        // them again, or the restart silently fails to come back up.
        val stopResult =
            stopActiveTunnelsInternal(TunnelActionSource.USER, persistLastActive = true)
        if (stopResult.isFailure) {
            Timber.e(stopResult.exceptionOrNull(), "Restart: previous tunnels would not stop")
            _errors.emit(TunnelErrorEvent.SwitchStopFailed(configs.first().id))
            return@withLock
        }
        when (awaitPreviousStopped(SWITCH_STOP_TIMEOUT_MS)) {
            StopWaitResult.STOPPED,
            StopWaitResult.ONLY_OVPN_UNCONFIRMED -> Unit
            StopWaitResult.STILL_ACTIVE -> {
                _errors.emit(TunnelErrorEvent.SwitchStopFailed(configs.first().id))
                return@withLock
            }
        }
        configs.forEach { startTunnelInternal(it, TunnelActionSource.USER) }
    }

    /**
     * Rebuild the kill-switch TUN in place. HEV is rebound to the new fd by VpnService using the
     * still-running SOCKS listener
     */
    suspend fun applyLockdownSettings(settings: LockdownSettings) = tunnelMutex.withLock {
        tunnelProvider
            .setLockDown(settings)
            .onFailure { Timber.e(it, "Failed to apply lockdown/kill-switch settings") }
            .getOrThrow()
    }

    suspend fun toggleTunnel(
        tunnelConfig: TunnelConfig,
        source: TunnelActionSource = TunnelActionSource.USER,
    ) = tunnelMutex.withLock {
        if (source == TunnelActionSource.USER) {
            markUserOverride()
        }

        val isActive =
            tunnelProvider.backendStatus.value.activeTunnels.keys.contains(tunnelConfig.id) ||
                openVpnCoordinator.isActive(tunnelConfig.id)
        if (isActive) {
            stopTunnelInternal(tunnelConfig.id, source)
            return@withLock
        }
        // Not active — but another tunnel may be: go through
        // startExclusive so the old tunnel is stopped (and observed
        // stopped) first, instead of starting this one over a live
        // tunnel. The widget / remote-control taps hit this path.
        // (startExclusive also records the last-used tunnel.)
        startExclusive(tunnelConfig, source)
    }

    // for quick settings tile
    suspend fun toggleActiveTunnels(source: TunnelActionSource = TunnelActionSource.USER) =
        tunnelMutex.withLock {
            if (source == TunnelActionSource.USER) {
                markUserOverride()
            }

            val active = tunnelProvider.backendStatus.value.activeTunnels
            val ovpnActive = openVpnCoordinator.activeTunnelId.value != null
            if (active.isNotEmpty() || ovpnActive) {
                lastActiveTunnels = active.keys.toList() +
                    listOfNotNull(openVpnCoordinator.activeTunnelId.value)

                active.keys.forEach { id ->
                    _actions.emit(TunnelActionEvent.Stopped(tunnelId = id, source = source))
                }
                if (ovpnActive) {
                    openVpnCoordinator.activeTunnelId.value?.let { id ->
                        _actions.emit(TunnelActionEvent.Stopped(tunnelId = id, source = source))
                    }
                    openVpnCoordinator.stop()
                }

                stopActiveTunnelsInternal(source, persistLastActive = true)
                return@withLock
            }

            val tunnelsToStart =
                when {
                    lastActiveTunnels.isNotEmpty() -> {
                        lastActiveTunnels.mapNotNull { tunnelRepository.getById(it) }
                    }

                    else -> {
                        // No in-memory last-active (e.g. after a restart):
                        // reconnect to the tunnel the user last used,
                        // persisted across restarts. Only if there is none,
                        // fall back to the default tunnel.
                        getLastUsedTunnel()?.let(::listOf)
                            ?: tunnelRepository.getDefaultTunnel()?.let(::listOf)
                            ?: emptyList()
                    }
                }

            tunnelsToStart.forEach { startExclusive(it, source) }
        }

    /** The tunnel the user last connected to (persisted across restarts). */
    suspend fun getLastUsedTunnel(): TunnelConfig? {
        val id = appStateRepository.getLastUsedTunnelId() ?: return null
        return tunnelRepository.getById(id)
    }

    private suspend fun stopTunnelInternal(id: Int, source: TunnelActionSource) {
        if (openVpnCoordinator.isActive(id)) {
            openVpnCoordinator.stop()
            _actions.emit(TunnelActionEvent.Stopped(tunnelId = id, source = source))
            replaceLastActiveTunnelIds(
                tunnelProvider.backendStatus.value.activeTunnels.keys - id,
            )
            return
        }
        tunnelProvider
            .stopTunnel(id)
            .onSuccess {
                _actions.emit(TunnelActionEvent.Stopped(tunnelId = id, source = source))
                replaceLastActiveTunnelIds(
                    tunnelProvider.backendStatus.value.activeTunnels.keys - id,
                )
            }
            .onFailure { _errors.emit(TunnelErrorEvent.from(it, id)) }
    }

    private suspend fun stopActiveTunnelsInternal(
        source: TunnelActionSource = TunnelActionSource.USER,
        persistLastActive: Boolean,
    ): Result<Unit> {
        val active = tunnelProvider.backendStatus.value.activeTunnels

        active.keys.forEach { id ->
            _actions.emit(TunnelActionEvent.Stopped(tunnelId = id, source = source))
        }

        // The result matters: a failed stop must not be followed by a
        // start — that would overlap two tunnels. Callers that switch
        // or restart check it and abort with a clear error instead.
        // (The OpenVPN stop has no result: it only asks the core to
        // die, and its death is observed via stopConfirmed.)
        val stopResult = tunnelProvider.stopActiveTunnels()
        if (openVpnCoordinator.activeTunnelId.value != null) {
            openVpnCoordinator.stop()
        }
        if (persistLastActive) {
            replaceLastActiveTunnelIds(emptySet())
        }
        return stopResult
    }

    private suspend fun replaceLastActiveTunnelIds(ids: Set<Int>) {
        if (ids.isEmpty()) {
            appStateRepository.clearLastActiveTunnelIds()
        } else {
            appStateRepository.setLastActiveTunnelIds(ids.toList())
        }
    }

    companion object {
        /**
         * Bound on waiting for the previous tunnel to die during a
         * switch/restart. Teardown is normally well under a second
         * (the backend's own VpnService shutdown wait is 1500ms); 5s
         * is generous without leaving the user hanging — and the
         * switch aborts with a clear error past it rather than
         * overlapping two tunnels.
         */
        private const val SWITCH_STOP_TIMEOUT_MS = 5_000L
    }
}
