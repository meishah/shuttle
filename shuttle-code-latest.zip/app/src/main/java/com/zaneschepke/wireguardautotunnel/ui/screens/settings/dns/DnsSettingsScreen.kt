package com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.AltRoute
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import com.zaneschepke.networkmonitor.PrivateDnsMode
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.constants.TunnelDns
import com.zaneschepke.wireguardautotunnel.domain.enums.BootstrapDnsProtocol
import com.zaneschepke.wireguardautotunnel.domain.enums.ForeignDnsPolicy
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelDnsMode
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelDnsProtocol
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsFieldCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.banner.InfoNotice
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.rememberRestartToApplyChanges
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.common.textbox.ConfigurationTextBox
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.components.ProtocolBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.components.ResolutionMethodBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.components.SplitSuffixTargetBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.components.TransitDnsPolicyBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.dns.components.TunnelDnsModeBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.util.extensions.launchNetworkAndInternetSettings
import com.zaneschepke.wireguardautotunnel.viewmodel.DnsViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState
import org.orbitmvi.orbit.compose.collectSideEffect

@Composable
fun DnsSettingsScreen(
    viewModel: DnsViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val context = LocalContext.current
    val uiState by viewModel.collectAsState()
    val sharedUiState by sharedViewModel.collectAsState()
    var showAppModeSheet by rememberSaveable { mutableStateOf(false) }
    var showResolutionMethodSheet by rememberSaveable { mutableStateOf(false) }
    var showProtocolSheet by rememberSaveable { mutableStateOf(false) }
    var showTransitPolicySheet by rememberSaveable { mutableStateOf(false) }
    var showSplitSuffixTargetSheet by rememberSaveable { mutableStateOf(false) }

    if (uiState.isLoading) return

    val requestApply =
        rememberRestartToApplyChanges(
            needsRestart = uiState.hasActiveTunnel,
            onSave = viewModel::save,
        )

    sharedViewModel.collectSideEffect { effect ->
        when (effect) {
            is LocalSideEffect.SaveChanges -> requestApply()
            else -> Unit
        }
    }

    if (showAppModeSheet) {
        TunnelDnsModeBottomSheet(
            onTunnelDnsModeChange = viewModel::setTunnelDnsMode,
            uiState.dnsSettings.tunnelDnsMode,
        ) {
            showAppModeSheet = false
        }
    }

    if (showResolutionMethodSheet) {
        ResolutionMethodBottomSheet(
            onProtocolChange = viewModel::setBootstrapDnsProtocol,
            protocol = uiState.dnsSettings.bootstrapDnsProtocol,
        ) {
            showResolutionMethodSheet = false
        }
    }

    val isSplitMode = uiState.dnsSettings.tunnelDnsMode.isSplitMode()
    if (showProtocolSheet) {
        ProtocolBottomSheet(
            options =
                if (isSplitMode) TunnelDnsProtocol.entries
                else TunnelDnsProtocol.entries.filter { it != TunnelDnsProtocol.Plain },
            onProtocolChange = viewModel::setTunnelDnsProtocol,
            protocol = uiState.dnsSettings.tunnelDnsProtocol,
        ) {
            showProtocolSheet = false
        }
    }

    if (showTransitPolicySheet) {
        TransitDnsPolicyBottomSheet(
            onPolicyChange = viewModel::setForeignDnsPolicy,
            policy = uiState.dnsSettings.foreignDnsPolicy,
        ) {
            showTransitPolicySheet = false
        }
    }

    if (showSplitSuffixTargetSheet) {
        SplitSuffixTargetBottomSheet(
            onTargetChange = viewModel::setSplitSuffixTarget,
            target = uiState.dnsSettings.splitSuffixTarget,
        ) {
            showSplitSuffixTargetSheet = false
        }
    }

    val privateDnsEnabled =
        uiState.systemDnsInfo?.privateDnsMode?.let { it != PrivateDnsMode.OFF } == true
    val tunnelDnsActive = uiState.dnsSettings.tunnelDnsMode != TunnelDnsMode.Off

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState())
                .statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
    ) {
        InfoNotice(
            title = stringResource(R.string.private_dns_enabled_warning),
            actionLabel = stringResource(R.string.fix),
            onClick = { context.launchNetworkAndInternetSettings() },
            visible = privateDnsEnabled && tunnelDnsActive,
        )
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.system))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.NetworkCheck) },
                    title = stringResource(R.string.current_system_dns),
                    description = {
                        val dnsInfo = uiState.systemDnsInfo

                        val descriptionText =
                            if (dnsInfo == null) {
                                stringResource(R.string.no_system_dns_information)
                            } else {
                                when (dnsInfo.privateDnsMode) {
                                    PrivateDnsMode.OFF -> {
                                        if (dnsInfo.servers.isNotEmpty()) {
                                            stringResource(
                                                R.string.system_dns_servers,
                                                dnsInfo.servers.joinToString(", "),
                                            )
                                        } else {
                                            stringResource(R.string.no_system_dns_detected)
                                        }
                                    }

                                    PrivateDnsMode.AUTOMATIC -> {
                                        buildString {
                                            append(stringResource(R.string.private_dns_automatic))

                                            append("\n")

                                            append(
                                                if (dnsInfo.servers.isNotEmpty()) {
                                                    stringResource(
                                                        R.string.system_dns_servers,
                                                        dnsInfo.servers.joinToString(", "),
                                                    )
                                                } else {
                                                    stringResource(R.string.no_system_dns_detected)
                                                },
                                            )
                                        }
                                    }

                                    PrivateDnsMode.HOSTNAME -> {
                                        stringResource(
                                            R.string.private_dns_hostname,
                                            dnsInfo.privateDnsHostname
                                                ?: stringResource(R.string.unknown),
                                        )
                                    }
                                }
                            }

                        DescriptionText(descriptionText)
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.peer_resolution))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Dns) },
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    title = stringResource(R.string.resolution_method),
                    description = {
                        DescriptionText(uiState.dnsSettings.bootstrapDnsProtocol.asString(context))
                    },
                    onClick = { showResolutionMethodSheet = true },
                    containerColor = Color.Transparent,
                )
            }
            AnimatedVisibility(
                uiState.dnsSettings.bootstrapDnsProtocol != BootstrapDnsProtocol.SYSTEM,
            ) {
                ShuttleSettingsFieldCard {
                    ConfigurationTextBox(
                        modifier = Modifier.fillMaxWidth(),
                        hint = stringResource(R.string.dns_endpoint_hint),
                        label = stringResource(R.string.dns_endpoint_label),
                        value = uiState.dnsSettings.bootstrapDnsEndpoint ?: "",
                        isError = uiState.bootstrapEndpointError != null,
                        onValueChange = viewModel::setBootstrapDnsEndpoint,
                    )
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.tunnel_dns))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(ImageVector.vectorResource(R.drawable.sdk))
                    },
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    title = stringResource(R.string.tunnel_dns_mode),
                    description = {
                        DescriptionText(uiState.dnsSettings.tunnelDnsMode.asString(context))
                    },
                    onClick = { showAppModeSheet = true },
                    containerColor = Color.Transparent,
                )
            }
            AnimatedVisibility(
                visible = uiState.dnsSettings.tunnelDnsMode == TunnelDnsMode.Off,
                enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
                exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ShuttleSettingsCard {
                        SurfaceRow(
                            leading = { ShuttleSettingIcon(Icons.Outlined.Dns) },
                            title = stringResource(R.string.global_tunnel_dns),
                            trailing = { modifier ->
                                SwitchWithDivider(
                                    checked = uiState.dnsSettings.isGlobalTunnelConfigDnsEnabled,
                                    onClick = viewModel::setGlobalTunnelDnsEnabled,
                                    modifier = modifier,
                                    checkedTrackColor = LimeConnect,
                                    // No page behind this row — it only
                                    // flips the switch (user 2026-11-25).
                                    showChevron = false,
                                )
                            },
                            description = {
                                DescriptionText(stringResource(R.string.global_tunnel_dns_desc))
                            },
                            onClick = {
                                viewModel.setGlobalTunnelDnsEnabled(
                                    !uiState.dnsSettings.isGlobalTunnelConfigDnsEnabled,
                                )
                            },
                            containerColor = Color.Transparent,
                        )
                    }
                    AnimatedVisibility(
                        visible = uiState.dnsSettings.isGlobalTunnelConfigDnsEnabled,
                        enter = fadeIn() + expandVertically(expandFrom = Alignment.Top),
                        exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Top),
                    ) {
                        ShuttleSettingsFieldCard {
                            ConfigurationTextBox(
                                modifier = Modifier.fillMaxWidth(),
                                hint =
                                    stringResource(
                                            R.string.hint_template,
                                            stringResource(R.string.comma_separated),
                                        )
                                        .lowercase(Locale.current.platformLocale),
                                label = stringResource(R.string.dns_servers),
                                value = uiState.globalDnsServers,
                                onValueChange = viewModel::setGlobalDnsServers,
                            )
                        }
                    }
                }
            }
            AnimatedVisibility(
                uiState.dnsSettings.tunnelDnsMode in
                    setOf(TunnelDnsMode.Encrypted, TunnelDnsMode.Split, TunnelDnsMode.AllLocal),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val showCustomServer =
                        !isSplitMode ||
                            !(uiState.dnsSettings.useTunnelDnsServersInSplit &&
                                uiState.dnsSettings.tunnelDnsProtocol == TunnelDnsProtocol.Plain)
                    val showProtocolRow =
                        uiState.dnsSettings.tunnelDnsMode != TunnelDnsMode.AllLocal
                    val showUseTunnelRow =
                        isSplitMode &&
                            uiState.dnsSettings.tunnelDnsProtocol == TunnelDnsProtocol.Plain
                    if (showProtocolRow || showUseTunnelRow) {
                        ShuttleSettingsCard {
                            if (showProtocolRow) {
                                SurfaceRow(
                                    leading = { ShuttleSettingIcon(Icons.Outlined.Router) },
                                    trailing = { modifier ->
                                        Icon(
                                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                                            contentDescription = null,
                                            modifier = modifier,
                                        )
                                    },
                                    title = stringResource(R.string.protocol),
                                    description = {
                                        DescriptionText(
                                            uiState.dnsSettings.tunnelDnsProtocol.asString(context),
                                        )
                                    },
                                    onClick = { showProtocolSheet = true },
                                    containerColor = Color.Transparent,
                                )
                            }
                            if (showProtocolRow && showUseTunnelRow) {
                                ShuttleSettingsDivider()
                            }
                            if (showUseTunnelRow) {
                                SurfaceRow(
                                    leading = { ShuttleSettingIcon(Icons.Outlined.Route) },
                                    title = stringResource(R.string.use_tunnel_dns_servers),
                                    trailing = { modifier ->
                                        SwitchWithDivider(
                                            checked = uiState.dnsSettings.useTunnelDnsServersInSplit,
                                            onClick = viewModel::setUseTunnelDnsServersInSplit,
                                            modifier = modifier,
                                            checkedTrackColor = LimeConnect,
                                            // No page behind this row — it
                                            // only flips the switch (user
                                            // 2026-11-25).
                                            showChevron = false,
                                        )
                                    },
                                    onClick = {
                                        viewModel.setUseTunnelDnsServersInSplit(
                                            !uiState.dnsSettings.useTunnelDnsServersInSplit,
                                        )
                                    },
                                    containerColor = Color.Transparent,
                                )
                            }
                        }
                    }
                    if (
                        showCustomServer &&
                            uiState.dnsSettings.tunnelDnsMode != TunnelDnsMode.AllLocal
                    ) {
                        ShuttleSettingsFieldCard {
                            ConfigurationTextBox(
                                modifier = Modifier.fillMaxWidth(),
                                hint = stringResource(R.string.dns_endpoint_hint),
                                label = stringResource(R.string.dns_endpoint_label),
                                value = uiState.dnsSettings.tunnelDnsEndpoint ?: "",
                                isError = uiState.tunnelEndpointError != null,
                                onValueChange = viewModel::setTunnelDnsEndpoint,
                            )
                        }
                    }
                    AnimatedVisibility(isSplitMode) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ShuttleSettingsFieldCard {
                                ConfigurationTextBox(
                                    modifier = Modifier.fillMaxWidth(),
                                    hint = TunnelDns.DEFAULT_SPLIT_SUFFIXES.joinToString(),
                                    label = stringResource(R.string.domain_suffixes),
                                    value = uiState.dnsSettings.localSuffixes ?: "",
                                    isError = uiState.localSuffixesError != null,
                                    onValueChange = viewModel::setLocalDomainSuffixes,
                                )
                            }
                            ShuttleSettingsCard {
                                SurfaceRow(
                                    leading = {
                                        ShuttleSettingIcon(
                                            Icons.AutoMirrored.Outlined.AltRoute,
                                        )
                                    },
                                    trailing = { modifier ->
                                        Icon(
                                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                                            contentDescription = null,
                                            modifier = modifier,
                                        )
                                    },
                                    title = stringResource(R.string.split_suffix_target),
                                    description = {
                                        DescriptionText(
                                            uiState.dnsSettings.splitSuffixTarget.asString(context),
                                        )
                                    },
                                    onClick = { showSplitSuffixTargetSheet = true },
                                    containerColor = Color.Transparent,
                                )
                            }
                        }
                    }
                    val transitPolicyLocked = sharedUiState.tunnelMode == TunnelMode.PROXY
                    val transitPolicyValue =
                        if (transitPolicyLocked) ForeignDnsPolicy.Redirect
                        else uiState.dnsSettings.foreignDnsPolicy
                    ShuttleSettingsCard {
                        SurfaceRow(
                            leading = {
                                ShuttleSettingIcon(Icons.Outlined.Dns)
                            },
                            trailing = { modifier ->
                                IconButton(
                                    onClick = { showTransitPolicySheet = true },
                                    modifier,
                                    enabled = !transitPolicyLocked,
                                ) {
                                    Icon(
                                        Icons.Outlined.ExpandMore,
                                        contentDescription = stringResource(R.string.select),
                                    )
                                }
                            },
                            title = stringResource(R.string.transit_dns_policy),
                            description = {
                                DescriptionText(
                                    transitPolicyValue.asString(context),
                                    disabled = transitPolicyLocked,
                                )
                            },
                            enabled = !transitPolicyLocked,
                            onClick = { showTransitPolicySheet = true },
                            containerColor = Color.Transparent,
                        )
                    }
                }
            }
        }
    }
}
