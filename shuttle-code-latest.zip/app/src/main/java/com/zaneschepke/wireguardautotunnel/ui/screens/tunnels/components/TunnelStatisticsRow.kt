package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.wgtunnel.backend.state.ActiveTunnel
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroOnGradient
import com.zaneschepke.wireguardautotunnel.util.extensions.proxyStatusTexts
import com.zaneschepke.wireguardautotunnel.ui.common.functions.rememberTickingNow

@Composable
fun TunnelStatisticsRow(
    activeTunnel: ActiveTunnel,
    // First line of the left column, replacing the "status:
    // Connected" line when provided (user 2026-11-28).
    overviewTop: (@Composable () -> Unit)? = null,
) {
    val context = LocalContext.current
    val now by rememberTickingNow()

    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Two columns (user 2026-11-27): the old single stack left
        // the hero's right half empty. Left: status / uptime / peer;
        // right: transfer / handshake / endpoint — same lines, same
        // text, only the arrangement changed.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                TunnelOverviewSection(
                    activeTunnel = activeTunnel,
                    now = now,
                    statusLine = overviewTop,
                )

                activeTunnel.activeConfig?.peers?.forEach { peer -> PeerStatisticsLeft(peer) }
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                activeTunnel.activeConfig?.peers?.forEach { peer ->
                    PeerStatisticsRight(peer, now)
                }
            }
        }

        val proxyTexts = activeTunnel.proxyStatusTexts(context)
        if (proxyTexts.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                proxyTexts.forEach {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall,
                        color = HeroOnGradient,
                    )
                }
            }
        }
    }
}
