package com.zaneschepke.wireguardautotunnel.ui.navigation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentPasteGo
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.RemoveRedEye
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Reorder
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.navigation.NavController
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Advanced
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.AndroidIntegrations
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Appearance
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.AutoTunnel
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Config
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.ConfigEdit
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.ConfigGlobal
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Display
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Dns
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.EntryTunnel
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.GlobalAmnezia
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.IPv6
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Language
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.License
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.LocationDisclosure
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Lock
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.LockdownSettings
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Logs
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Monitoring
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.MonitoringAndRecovery
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Notifications
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.OpenVpnEdit
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.PreferredTunnel
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.ProxySettings
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Security
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Settings
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.SplitTunnel
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.SplitTunnelGlobal
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Support
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.TunnelGlobals
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.TunnelRecovery
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.TunnelSettings
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.Tunnels
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.WifiDetectionMethod
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route.WifiPreferences
import com.zaneschepke.wireguardautotunnel.ui.navigation.TunnelNetwork
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender
import com.zaneschepke.wireguardautotunnel.ui.state.GlobalAppUiState
import com.zaneschepke.wireguardautotunnel.ui.state.NavbarState
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel

/**
 * One capsule holding the top-right action icons (user 17:44): the
 * "+" and the "⋮" sit TOGETHER in a single pill, matching the
 * SHUTTLE capsule on the left — lavender background with DARK icons
 * in BOTH themes (user 17:52), never a dark pill with light icons.
 * The DropdownMenu anchored to the ⋮ is a popup, so the capsule's
 * clip cannot cut it off.
 */
@Composable
private fun TopBarActionsCapsule(content: @Composable RowScope.() -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            Modifier
                .clip(RoundedCornerShape(50))
                .background(OrionLavender)
                .padding(horizontal = 4.dp),
    ) {
        CompositionLocalProvider(
            LocalContentColor provides OnSelectedCapsule,
        ) {
            content()
        }
    }
}

@Composable
fun currentRouteAsNavbarState(
    globalState: GlobalAppUiState,
    sharedViewModel: SharedAppViewModel,
    route: Route?,
    navController: NavController,
): State<NavbarState> {
    val keyboardController = LocalSoftwareKeyboardController.current
    val context = LocalContext.current

    return remember(route, globalState) {
        derivedStateOf {
            when (route) {
                Appearance -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.appearance),
                    )
                }
                AutoTunnel -> {
                    NavbarState(
                        showBottomItems = true,
                        topTitle =
                            if (!globalState.isLocationDisclosureShown) null
                            else {
                                context.getString(R.string.auto_tunnel)
                            },
                    )
                }
                Display -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.display_theme),
                    )
                }
                Dns -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.dns_settings),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                        },
                    )
                }
                Language -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.language),
                    )
                }
                Notifications -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.notifications),
                    )
                }
                LockdownSettings -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.lockdown_settings),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                        },
                    )
                }
                License -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.licenses),
                    )
                }
                LocationDisclosure -> {
                    NavbarState(showBottomItems = true)
                }
                Lock -> {
                    NavbarState(showBottomItems = false)
                }
                Logs -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = false,
                        topTitle = context.getString(R.string.logs),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    sharedViewModel.postSideEffect(
                                        LocalSideEffect.Sheet.LoggerActions,
                                    )
                                },
                            ) {
                                Icon(Icons.Rounded.Menu, stringResource(R.string.quick_actions))
                            }
                        },
                    )
                }
                ProxySettings -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.proxy_settings),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                        },
                    )
                }
                Settings -> {
                    NavbarState(
                        showBottomItems = true,
                        topTitle = context.getString(R.string.settings),
                    )
                }
                is OpenVpnEdit -> {
                    val tunnelName = globalState.tunnelNames[route.id]
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = tunnelName ?: context.getString(R.string.ovpn_edit_title),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                        },
                    )
                }
                is ConfigEdit -> {
                    val tunnelName = globalState.tunnelNames[route.id]
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = tunnelName ?: context.getString(R.string.new_tunnel),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                            IconButton(
                                onClick = {
                                    sharedViewModel.postSideEffect(LocalSideEffect.ShowSensitive)
                                },
                            ) {
                                Icon(
                                    Icons.Outlined.RemoveRedEye,
                                    stringResource(R.string.show_password),
                                )
                            }
                            if (globalState.tunnelNames.isNotEmpty())
                                IconButton(
                                    onClick = {
                                        sharedViewModel.postSideEffect(
                                            LocalSideEffect.Modal.SelectTunnel,
                                        )
                                    },
                                ) {
                                    Icon(
                                        Icons.Outlined.ContentPasteGo,
                                        stringResource(R.string.copy_from),
                                    )
                                }
                        },
                    )
                }
                is ConfigGlobal,
                GlobalAmnezia -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = context.getString(R.string.amnezia_for_all_tunnels),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                },
                            ) {
                                Icon(Icons.Rounded.Save, stringResource(R.string.save))
                            }
                        },
                    )
                }
                is SplitTunnel,
                is SplitTunnelGlobal -> {
                    val tunnelName =
                        if (route is SplitTunnel) globalState.tunnelNames[route.id]
                        else context.getString(R.string.splt_tunneling)
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = tunnelName ?: "",
                        topTrailing = {
                            var showOverflowMenu by remember { mutableStateOf(false) }
                            val showSystemApps by
                                sharedViewModel.showSplitSystemApps.collectAsStateWithLifecycle()
                            Row {
                                IconButton(
                                    onClick = {
                                        sharedViewModel.postSideEffect(LocalSideEffect.SaveChanges)
                                    },
                                ) {
                                    Icon(Icons.Rounded.Save, stringResource(R.string.save))
                                }
                                IconButton(onClick = { showOverflowMenu = true }) {
                                    Icon(
                                        Icons.Outlined.MoreVert,
                                        contentDescription = stringResource(R.string.more_options),
                                    )
                                }
                                DropdownMenu(
                                    expanded = showOverflowMenu,
                                    onDismissRequest = { showOverflowMenu = false },
                                    containerColor =
                                        MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                                    tonalElevation = 4.dp,
                                    shadowElevation = 4.dp,
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.copy_from)) },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Outlined.ContentPasteGo,
                                                contentDescription = null,
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            sharedViewModel.postSideEffect(
                                                LocalSideEffect.Modal.SelectTunnel,
                                            )
                                        },
                                    )
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                stringResource(
                                                    if (showSystemApps) R.string.hide_system_apps
                                                    else R.string.show_system_apps,
                                                ),
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                if (showSystemApps) Icons.Outlined.VisibilityOff
                                                else Icons.Outlined.Visibility,
                                                contentDescription = null,
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            sharedViewModel.setShowSplitSystemApps(!showSystemApps)
                                        },
                                    )
                                }
                            }
                        },
                        showBottomItems = true,
                    )
                }
                Support -> {
                    NavbarState(
                        topTitle = context.getString(R.string.support),
                        showBottomItems = true,
                    )
                }
                AndroidIntegrations -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.android_integrations),
                        showBottomItems = true,
                    )
                }
                is TunnelSettings -> {
                    val tunnelName = globalState.tunnelNames[route.id]
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        showBottomItems = true,
                        topTitle = tunnelName ?: "",
                    )
                }
                Tunnels -> {
                    val selecting = globalState.selectedTunnelCount > 0
                    NavbarState(
                        topLeading =
                            when {
                                globalState.isReorderMode -> {
                                    {
                                        TvBackButton {
                                            if (globalState.reorderScopeTitle != null) {
                                                sharedViewModel.exitReorderScope()
                                            } else {
                                                sharedViewModel.cancelReorder()
                                            }
                                        }
                                    }
                                }
                                selecting -> {
                                    {
                                        IconButton(
                                            onClick = sharedViewModel::clearSelectedTunnels,
                                        ) {
                                            Icon(
                                                Icons.Rounded.Close,
                                                stringResource(R.string.cancel),
                                                tint =
                                                    MaterialTheme.colorScheme.onSurface,
                                            )
                                        }
                                    }
                                }
                                else -> null
                            },
                        topTitle =
                            when {
                                globalState.isReorderMode &&
                                    globalState.reorderScopeTitle != null ->
                                    globalState.reorderScopeTitle
                                globalState.isReorderMode -> context.getString(R.string.reorder)
                                selecting ->
                                    context.getString(
                                        R.string.n_selected,
                                        globalState.selectedTunnelCount,
                                    )
                                else -> context.getString(R.string.app_name)
                            },
                        topTrailing = {
                            when {
                                globalState.isReorderMode ->
                                    TopBarActionsCapsule {
                                        IconButton(onClick = sharedViewModel::saveReorder) {
                                            Icon(
                                                Icons.Rounded.Check,
                                                stringResource(R.string.done),
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                sharedViewModel.postSideEffect(
                                                    LocalSideEffect.Sheet.ReorderActions,
                                                )
                                            },
                                        ) {
                                            Icon(
                                                Icons.Outlined.MoreVert,
                                                stringResource(R.string.more_options),
                                            )
                                        }
                                    }
                                selecting ->
                                    // No top ⋮ any more (user 2026-11-24:
                                    // long-press removed, each config has
                                    // its own ⋮ menu) — the selection
                                    // top bar carries no actions.
                                    TopBarActionsCapsule {
                                    }
                                else -> {
                                    // The ⋮ (three-dot) menu was
                                    // removed entirely in 1.5 (user
                                    // 20:01: "اینم کلا بردار نیاز
                                    // نمیشه"): the top-right capsule
                                    // is just the + button now.
                                    // Reorder moved to long-press on
                                    // a group (see TunnelsScreen's
                                    // group-actions sheet); Ping
                                    // servers already has its own
                                    // centered pill in the list.
                                    TopBarActionsCapsule {
                                        IconButton(
                                            onClick = {
                                                sharedViewModel.postSideEffect(
                                                    LocalSideEffect.Sheet.ImportTunnels,
                                                )
                                            },
                                        ) {
                                            Icon(
                                                Icons.Rounded.Add,
                                                stringResource(R.string.add_tunnel),
                                            )
                                        }
                                    }
                                }
                            }
                        },
                        showBottomItems = true,
                        // Real Shuttle icon next to the title — only in the
                        // normal state (not while selecting / reordering,
                        // when the title shows the selection / reorder).
                        showShuttleMark =
                            !selecting && !globalState.isReorderMode,
                    )
                }
                WifiDetectionMethod -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.wifi_detection_method),
                        showBottomItems = true,
                    )
                }
                is WifiPreferences -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.wifi_settings),
                        showBottomItems = true,
                    )
                }
                is PreferredTunnel -> {
                    val title =
                        when (route.tunnelNetwork) {
                            TunnelNetwork.MOBILE_DATA,
                            TunnelNetwork.ETHERNET -> context.getString(R.string.preferred_tunnel)
                            TunnelNetwork.WIFI -> context.getString(R.string.tunnel_mapping)
                        }
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = title,
                        showBottomItems = true,
                    )
                }
                is Config -> {
                    val tunnelName = globalState.tunnelNames[route.id] ?: ""
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTrailing = {
                            var showOverflowMenu by remember { mutableStateOf(false) }
                            if (!route.live) {
                                IconButton(
                                    onClick = {
                                        if (globalState.openVpnTunnelIds.contains(route.id)) {
                                            navController.push(OpenVpnEdit(route.id))
                                        } else {
                                            navController.push(ConfigEdit(route.id))
                                        }
                                    },
                                ) {
                                    Icon(
                                        Icons.Outlined.Edit,
                                        contentDescription = stringResource(R.string.edit_tunnel),
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    sharedViewModel.postSideEffect(LocalSideEffect.ShowSensitive)
                                },
                            ) {
                                Icon(
                                    Icons.Outlined.RemoveRedEye,
                                    stringResource(R.string.toggle_sensitive_data_visibility),
                                )
                            }

                            if (!route.live) {
                                IconButton(onClick = { showOverflowMenu = true }) {
                                    Icon(
                                        Icons.Outlined.MoreVert,
                                        contentDescription = stringResource(R.string.more_options),
                                    )
                                }

                                DropdownMenu(
                                    expanded = showOverflowMenu,
                                    onDismissRequest = { showOverflowMenu = false },
                                    containerColor =
                                        MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                                    tonalElevation = 4.dp,
                                    shadowElevation = 4.dp,
                                ) {
                                    // A QR code only makes sense for WireGuard
                                    // quick configs; .ovpn text is far too
                                    // large and has no quick-config form.
                                    if (!globalState.openVpnTunnelIds.contains(route.id)) {
                                        DropdownMenuItem(
                                            text = { Text(stringResource(R.string.show_qr)) },
                                            leadingIcon = { Icon(Icons.Default.QrCode, null) },
                                            onClick = {
                                                showOverflowMenu = false
                                                sharedViewModel.postSideEffect(LocalSideEffect.Modal.QR)
                                            },
                                        )
                                    }
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.copy)) },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Outlined.ContentCopy,
                                                contentDescription = null,
                                            )
                                        },
                                        onClick = {
                                            showOverflowMenu = false
                                            sharedViewModel.postSideEffect(
                                                LocalSideEffect.CopyToClipboard,
                                            )
                                        },
                                    )
                                }
                            }
                        },
                        topTitle = tunnelName,
                        showBottomItems = true,
                    )
                }
                is IPv6 -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.ipv6_settings),
                        showBottomItems = true,
                    )
                }
                is EntryTunnel -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.entry_tunnel),
                        showBottomItems = true,
                    )
                }
                is TunnelGlobals -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.tunnel_globals),
                        showBottomItems = true,
                    )
                }
                is Advanced -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.advanced),
                        showBottomItems = true,
                    )
                }
                is Security -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.security),
                        showBottomItems = true,
                    )
                }
                is Monitoring -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle = context.getString(R.string.monitoring),
                        showBottomItems = true,
                    )
                }
                is TunnelRecovery,
                is MonitoringAndRecovery -> {
                    NavbarState(
                        topLeading = { TvBackButton { navController.pop() } },
                        topTitle =
                            context.getString(
                                if (route is MonitoringAndRecovery) R.string.monitoring_and_recovery
                                else R.string.tunnel_recovery,
                            ),
                        topTrailing = {
                            IconButton(
                                onClick = {
                                    sharedViewModel.postSideEffect(
                                        LocalSideEffect.Modal.RecoveryDetails,
                                    )
                                },
                            ) {
                                Icon(
                                    Icons.Outlined.Info,
                                    contentDescription = stringResource(R.string.recovery_details),
                                )
                            }
                        },
                        showBottomItems = true,
                    )
                }
                null -> {
                    NavbarState()
                }
            }
        }
    }
}
