package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.ipv6

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.viewmodel.TunnelViewModel
import org.orbitmvi.orbit.compose.collectAsState

@Composable
fun IPv6Screen(viewModel: TunnelViewModel) {

    val uiState by viewModel.collectAsState()

    if (uiState.isLoading) return
    val tunnel = uiState.tunnel ?: return

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.peer_endpoints))

            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Public) },
                    title = stringResource(R.string.prefer_ipv6),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = tunnel.isIpv6Preferred,
                            onClick = {
                                viewModel.onIPv6Action(IPv6Intent.ToggleIpv6Preferred(it))
                            },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = { DescriptionText(stringResource(R.string.prefer_ipv6_desc)) },
                    onClick = {
                        viewModel.onIPv6Action(
                            IPv6Intent.ToggleIpv6Preferred(!tunnel.isIpv6Preferred),
                        )
                    },
                    containerColor = Color.Transparent,
                )

                val ipv6Enabled = tunnel.isIpv6Preferred

                ShuttleSettingsDivider()

                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Restore) },
                    title = stringResource(R.string.restore_ipv6),
                    onClick = {
                        viewModel.onIPv6Action(IPv6Intent.ToggleRestore(!tunnel.ipv6RestoreEnabled))
                    },
                    enabled = ipv6Enabled,
                    description = {
                        DescriptionText(
                            stringResource(R.string.restore_ipv6_desc),
                            disabled = !ipv6Enabled,
                        )
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = tunnel.ipv6RestoreEnabled,
                            onClick = { viewModel.onIPv6Action(IPv6Intent.ToggleRestore(it)) },
                            enabled = ipv6Enabled,
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
    }
}
