package com.zaneschepke.wireguardautotunnel.ui.screens.autotunnel.detection

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.WifiDetectionMethod
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.util.extensions.asDescriptionString
import com.zaneschepke.wireguardautotunnel.util.extensions.asTitleString
import com.zaneschepke.wireguardautotunnel.viewmodel.AutoTunnelViewModel
import kotlin.enums.enumEntries
import org.koin.androidx.compose.koinViewModel
import org.orbitmvi.orbit.compose.collectAsState

@Composable
fun WifiDetectionMethodScreen(viewModel: AutoTunnelViewModel = koinViewModel()) {
    val context = LocalContext.current

    val autoTunnelState by viewModel.collectAsState()

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Top,
        modifier =
            Modifier.fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(top = 70.dp, bottom = 140.dp),
    ) {
        val methods = enumEntries<WifiDetectionMethod>()
        ShuttleSettingsCard {
            methods.forEachIndexed { index, it ->
                val title = it.asTitleString(context)
                val description = it.asDescriptionString(context)
                val selected =
                    autoTunnelState.autoTunnelSettings.wifiDetectionMethod == it
                SurfaceRow(
                    title = title,
                    description =
                        description?.let { desc -> { DescriptionText(desc) } },
                    trailing =
                        if (selected) {
                            {
                                Icon(
                                    Icons.Outlined.Check,
                                    stringResource(id = R.string.selected),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        } else null,
                    onClick = { viewModel.setWifiDetectionMethod(it) },
                    containerColor = Color.Transparent,
                )
                if (index < methods.size - 1) {
                    ShuttleSettingsDivider()
                }
            }
        }
    }
}
