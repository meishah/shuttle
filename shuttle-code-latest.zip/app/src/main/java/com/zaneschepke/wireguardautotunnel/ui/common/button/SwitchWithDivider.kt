package com.zaneschepke.wireguardautotunnel.ui.common.button

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

@Composable
fun SwitchWithDivider(
    checked: Boolean,
    modifier: Modifier = Modifier,
    onClick: (Boolean) -> Unit,
    enabled: Boolean = true,
    // Hide the chevron + divider when the row only flips the switch
    // and opens no page (user 2026-11-25). Default keeps the old
    // look for rows that do navigate (split tunnel, logs, …).
    showChevron: Boolean = true,
    checkedTrackColor: androidx.compose.ui.graphics.Color =
        MaterialTheme.colorScheme.primary,
) {
    PreferenceTrailing(showChevron = showChevron) {
        Box(modifier = Modifier.pointerInput(Unit) { detectTapGestures {} }) {
            ThemedSwitch(
                checked = checked,
                onClick = onClick,
                enabled = enabled,
                modifier = modifier,
                checkedTrackColor = checkedTrackColor,
            )
        }
    }
}
