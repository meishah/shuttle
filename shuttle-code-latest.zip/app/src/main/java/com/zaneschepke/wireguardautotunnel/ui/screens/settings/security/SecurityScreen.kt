package com.zaneschepke.wireguardautotunnel.ui.screens.settings.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Pin
import androidx.compose.material.icons.outlined.ScreenLockPortrait
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState

@Composable
fun SecurityScreen(viewModel: SharedAppViewModel = koinActivityViewModel()) {

    val uiState by viewModel.collectAsState()

    val navController = LocalNavController.current

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
    ) {
        ShuttleSettingsCard {
            SurfaceRow(
                leading = { ShuttleSettingIcon(Icons.Outlined.ScreenLockPortrait) },
                title = stringResource(R.string.screen_recording_protection),
                trailing = { modifier ->
                    SwitchWithDivider(
                        checked = uiState.isScreenRecordingProtectionEnabled,
                        onClick = { viewModel.setScreenRecordingSecurity(it) },
                        modifier = modifier,
                        checkedTrackColor = LimeConnect,
                        // No page behind this row — it only flips the
                        // switch (user 2026-11-25).
                        showChevron = false,
                    )
                },
                description = {
                    DescriptionText(stringResource(R.string.screen_recording_protection_desc))
                },
                onClick = {
                    viewModel.setScreenRecordingSecurity(!uiState.isScreenRecordingProtectionEnabled)
                },
                containerColor = Color.Transparent,
            )
            ShuttleSettingsDivider()
            SurfaceRow(
                leading = { ShuttleSettingIcon(Icons.Outlined.Pin) },
                title = stringResource(R.string.app_lock),
                trailing = { modifier ->
                    SwitchWithDivider(
                        checked = uiState.pinLockEnabled,
                        onClick = {
                            if (it) {
                                navController.push(Route.Lock)
                            } else {
                                viewModel.setPinLockEnabled(false)
                            }
                        },
                        modifier = modifier,
                        checkedTrackColor = LimeConnect,
                        // No page behind this row — it only flips the
                        // switch (user 2026-11-25).
                        showChevron = false,
                    )
                },
                description = { DescriptionText(stringResource(R.string.app_lock_desc)) },
                onClick = {
                    if (!uiState.pinLockEnabled) {
                        navController.push(Route.Lock)
                    } else {
                        viewModel.setPinLockEnabled(false)
                    }
                },
                containerColor = Color.Transparent,
            )
        }
    }
}
