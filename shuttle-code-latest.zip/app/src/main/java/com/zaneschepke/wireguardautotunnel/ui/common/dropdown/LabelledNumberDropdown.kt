package com.zaneschepke.wireguardautotunnel.ui.common.dropdown

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow

@Composable
fun <T> LabeledDropdown(
    title: String,
    description: (@Composable () -> Unit)? = null,
    leading: @Composable () -> Unit,
    onSelected: (T?) -> Unit,
    options: List<T?>,
    currentValue: T?,
    optionToString: @Composable (T?) -> String,
    enabled: Boolean = true,
    // Lets a settings card supply its own background (transparent,
    // so the card's flat colour shows through). Null keeps the
    // default surface colour.
    containerColor: Color? = null,
) {
    var isDropDownExpanded by remember { mutableStateOf(false) }

    SurfaceRow(
        leading = leading,
        title = title,
        description = description,
        enabled = enabled,
        onClick = { isDropDownExpanded = true },
        containerColor = containerColor,
        trailing = {
            DropdownSelector(
                currentValue = currentValue,
                options = options,
                onValueSelected = { selected -> onSelected(selected) },
                isExpanded = isDropDownExpanded,
                onDismiss = { isDropDownExpanded = false },
                enabled = enabled,
                optionToString = optionToString,
            )
        },
    )
}
