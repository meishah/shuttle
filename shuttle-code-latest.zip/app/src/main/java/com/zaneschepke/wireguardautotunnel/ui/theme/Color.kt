package com.zaneschepke.wireguardautotunnel.ui.theme

import androidx.compose.ui.graphics.Color

val OffWhite = Color(0xFFF2F2F4)
val CoolGray = Color(0xFF8D9D9F)
val LightGrey = Color(0xFFECEDEF)
val Aqua = Color(0xFF76BEBD)
val Plantation = Color(0xFF2E3538)
val Shark = Color(0xFF21272A)
val BalticSea = Color(0xFF1C1B1F)

// Orion Store look (from the user's own screenshots of the Orion app):
// near-black background, lavender / periwinkle accent for primary pills,
// highlights and selected states. Teal is only used for small success
// text (e.g. "Installed"), never as the main accent.
val OrionBackground = Color(0xFF0D0D11)
val OrionSurface = Color(0xFF1A1A21)
val OrionLavender = Color(0xFFC2BCF7)
val OrionLavenderDeep = Color(0xFF5B54C7)

// Deep navy icon tint for the Sky light theme (user 2026-11-25).
val SkyDeep = Color(0xFF1D4E89)
val OrionLavenderContainer = Color(0xFF3E3C5E)
// Connect / Disconnect buttons only: light lime green sampled from the
// user's reference picture (~#CAFA80). Dark text/icons on it for contrast.
// Everything else keeps the Orion lavender look.
val LimeConnect = Color(0xFFCAFA80)
val OnLimeConnect = Color(0xFF1E2A0A)

// Config tiles (from the user's reference picture): dark navy blue tile
// with the flower-petal blob in a slightly lighter blue. The running
// tile is the same family, one step lighter, so it stays findable.
val TileNavy = Color(0xFF18376D)
val TileNavyFlower = Color(0xFF28467C)
val TileNavyActive = Color(0xFF21468A)
val TileNavyActiveFlower = Color(0xFF2C5496)

// Config tiles in the LIGHT theme (user 17:52, final approval "این
// خوبه"): the navy tiles belong to the dark themes only. Light tiles
// are pale lavender with dark text, same shape and flower motif —
// the running tile one step deeper, so it stays findable.
val TileLight = Color(0xFFDDE9F6)
val TileLightFlower = Color(0xFFD5CEF8)
val TileLightActive = Color(0xFFD9D2F8)
val TileLightActiveFlower = Color(0xFFC6BCF2)

// Config tiles, single flat colour (user 2026-11-24, approved
// preview): NO flower blob, NO separate idle/running shades —
// one flat colour per theme, dark #262638, light very pale sky
// blue #DDE9F6 (Sky light theme, user 2026-11-25). The
// SELECTED tile (long-press, Pin) is a clearly darker purple
// #7C74D0 with white text, so the selection is visible at a
// glance — this fixes the pin-selection bug where the old
// secondaryContainer selected colour was ~identical to the idle
// tile (contrast ~1.05:1) and the tile looked unselected.
val TileDark = Color(0xFF262638)
val TileSelected = Color(0xFF7C74D0)

// Text inside a SELECTED capsule (user 17:52): the selected filter
// chip, the SHUTTLE + actions capsules and the active bottom-nav tab
// all use a lavender background with DARK text in BOTH themes —
// never a dark pill with light text. The background is OrionLavender
// (#C2BCF7); this is its dark text.
val OnSelectedCapsule = Color(0xFF211D47)

// Ping colours on LIGHT tiles (user 17:52): the dark-theme ping
// colours (SilverTree / OrionAmber / AlertRed) are too light to read
// on pale lavender — the light theme needs dark green / amber / red.
val PingGreenDark = Color(0xFF1E6B33)
val PingAmberDark = Color(0xFF8A5200)
val PingRedDark = Color(0xFFB3261E)

// Ping colours on the connected hero's dark Pilot gradient (user
// 2026-11-25, preview approved «حله», red deepened «خوبه همین»):
// bright, saturated green / amber / red — the normal dark-card ping
// colours (SilverTree / OrionAmber / AlertRed) are too muted against
// the bright gradient. Same thresholds as the config rows.
val PingGreenHero = Color(0xFF7CFC9A)
val PingAmberHero = Color(0xFFFFB86B)
val PingRedHero = Color(0xFFFF5252)

val OrionTeal = Color(0xFF5BC8BE)
val OrionAmber = Color(0xFFE8A33D)

// Text on the connected hero's purple-blue gradient: near-white at high
// opacity. The theme's outline/onSurfaceVariant are washed out against
// the bright gradient in BOTH themes (dark and light) — never use them
// on the gradient. Also used by the WG hero stats rows (hero-only).
val HeroOnGradient = Color(0xFFF4F4FF)

// Connected hero background (Orion Pilot card reference, user 18:56 —
// "دقیقا این زمینه رو بساز"): EXACTLY the reference's smooth
// purple-to-blue gradient, sampled 3x3 from the reference image
// (workspace/user/files/122554_10_vuqt.jpg). Static — no animation
// at all. The waves are barely lighter/darker than the gradient,
// feathered edges. No dark navy blobs, no pale wash.
val HeroPilotTopMid = Color(0xFF3E3F92)
val HeroPilotCentre = Color(0xFF453D92)
val HeroPilotBottomMid = Color(0xFF4C3EAD)
val HeroPilotTopLeft = Color(0xFF6B6AD2)
val HeroPilotMidLeft = Color(0xFF6653BE)
val HeroPilotTopRight = Color(0xFF4F56A4)
val HeroPilotMidRight = Color(0xFF2B5FCC)
val HeroPilotBottomLeft = Color(0xFF423E9C)
val HeroPilotBottomRight = Color(0xFF3859BA)
val HeroPilotWaveRight = Color(0xFF504CBA)
val HeroPilotWaveBottom = Color(0xFF3756C0)

// Connected hero in the LIGHT theme (user 18:50 — "من دقیقا اینو
// میخواستم"): a LIGHT LAVENDER gradient with DARK text. The deep
// purple hero is dark-theme only.
val HeroLightTop = Color(0xFFE9E5FD)
val HeroLightMid = Color(0xFFDCD6FB)
val HeroLightBottom = Color(0xFFCFC8F7)
val HeroLightWave = Color(0xFFC5BDF3)
val HeroOnLightGradient = Color(0xFF211D47)

// Text on the navy config tiles (#18376D, same in both themes): the
// theme's onSurface/outline are dark in the light theme and unreadable
// on navy. Tile text is always explicit light, never scheme colours.
val TileOnNavy = Color(0xFFF2F2F4)
val TileOnNavySecondary = Color(0xFFDCE4F5)

// Status colors
val SilverTree = Color(0xFF6DB58B)
val AlertRed = Color(0xFFCF6679)
val Straw = Color(0xFFD4C483)

val Disabled = CoolGray.copy(alpha = 0.4f)

// Other colors
val ConfigHeaderColor = Color(0xFFBB86FC)
val ConfigKeyColor = Color(0xFF03DAC5)
val Heart = Color(0xFFDB61A2)

sealed class ThemeColors(
    val background: Color,
    val surface: Color,
    val primary: Color,
    val secondary: Color,
    val onSurface: Color,
    val onBackground: Color,
    val outline: Color,
) {

    data object Light :
        ThemeColors(
            background = Color(0xFFF4F4F8),
            surface = Color.White,
            primary = OrionLavenderDeep,
            secondary = Color(0xFFE7E4FA),
            onSurface = Color(0xFF1A1A21),
            outline = Color(0xFF7C7C8A),
            onBackground = Color(0xFF1A1A21),
        )

    data object Dark :
        ThemeColors(
            background = OrionBackground,
            surface = OrionSurface,
            primary = OrionLavender,
            secondary = OrionLavenderContainer,
            onSurface = OffWhite,
            outline = Color(0xFF43434F),
            onBackground = OffWhite,
        )
}
