package com.zaneschepke.wireguardautotunnel.ui.sideeffect

import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup

sealed class LocalSideEffect {
    data object SaveChanges : LocalSideEffect()

    data object ShowSensitive : LocalSideEffect()

    data object CopyToClipboard : LocalSideEffect()

    sealed class Sheet : LocalSideEffect() {

        data object ImportTunnels : Sheet()

        data object MoveToGroup : Sheet()

        data object SelectionActions : Sheet()

        data object ReorderActions : Sheet()

        data object LoggerActions : Sheet()

        // The floating top bar (MainActivity overlay) lives outside
        // TunnelsScreen, so its + / group-long-press reach the screen
        // through these side effects instead of callbacks.
        data object CreateGroup : Sheet()

        data class GroupActions(val group: TunnelGroup) : Sheet()
    }

    data object LaunchExportPicker : LocalSideEffect()

    sealed class Modal : LocalSideEffect() {
        data object QR : Modal()

        data object SelectTunnel : Modal()

        data object RecoveryDetails : Modal()
    }

    sealed class SelectedTunnels : LocalSideEffect() {
        data object SelectAll : SelectedTunnels()

        data object Copy : SelectedTunnels()
    }
}
