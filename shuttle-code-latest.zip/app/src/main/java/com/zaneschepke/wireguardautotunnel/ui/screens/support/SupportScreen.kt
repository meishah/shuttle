package com.zaneschepke.wireguardautotunnel.ui.screens.support

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Launch
import androidx.compose.material.icons.outlined.Balance
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.InstallMobile
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Reviews
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dokar.sonner.ToastType
import com.zaneschepke.wireguardautotunnel.BuildConfig
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.model.UpdateDownloadState
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.GlobalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.functions.rememberClipboardHelper
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.PermissionDialog
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.UpdateDialog
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.UpdateDownloadProgress
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.rememberUpdateDownloadPresentation
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.ShuttleMark
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.connectedHeroBackground
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.isLightShuttleTheme
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroOnGradient
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroOnLightGradient
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.PermissionDialog
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.UpdateDialog
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.UpdateDownloadProgress
import com.zaneschepke.wireguardautotunnel.ui.screens.support.components.rememberUpdateDownloadPresentation
import com.zaneschepke.wireguardautotunnel.util.Constants
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.canInstallPackages
import com.zaneschepke.wireguardautotunnel.util.extensions.launchPlayStoreListing
import com.zaneschepke.wireguardautotunnel.util.extensions.launchPlayStoreReview
import com.zaneschepke.wireguardautotunnel.util.extensions.openWebUrl
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SupportViewModel
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState

/**
 * Shuttle's About screen. The WG Tunnel links that used to live here
 * (donate, docs, website, desktop app, translation, Telegram, Matrix,
 * GitHub issues, support email) all pointed at wgtunnel.com / WG
 * Tunnel's channels, so they are removed — there is no Shuttle
 * equivalent to link to, except the project's own GitHub repo
 * (github.com/meishah/shuttle), linked in Resources below.
 * Kept: licenses, about/version, update check.
 *
 * Update check targets Shuttle's own GitHub releases
 * (github.com/meishah/shuttle, latest release) and is offered from the
 * row directly below the GitHub link. It must never point at WG
 * Tunnel's releases: installing one would replace Shuttle with WG
 * Tunnel.
 */
@Composable
fun SupportScreen(
    viewModel: SupportViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val context = LocalContext.current
    val navController = LocalNavController.current
    val isTv = LocalIsAndroidTV.current
    val scope = rememberCoroutineScope()

    val supportState by viewModel.collectAsState()

    val clipboardManager = rememberClipboardHelper()

    var showPermissionDialog by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        sharedViewModel.supportAutoUpdateRequests.collect { startDownload ->
            if (BuildConfig.DEBUG) return@collect
            if (BuildConfig.FLAVOR != Constants.STANDALONE_FLAVOR) return@collect
            if (startDownload && !context.canInstallPackages()) {
                viewModel.checkForStandaloneUpdate(startDownloadIfAvailable = false)
                showPermissionDialog = true
            } else {
                viewModel.checkForStandaloneUpdate(startDownloadIfAvailable = startDownload)
            }
        }
    }

    val izzyUrl = stringResource(R.string.fdroid_url)
    val githubUrl = stringResource(R.string.github_project_url)
    val playStoreUrl = "https://play.google.com/store/apps/details?id=${context.packageName}"
    val playReviewsUrl =
        "https://play.google.com/store/apps/details?id=${context.packageName}&showAllReviews=true"

    val version = remember {
        "v${BuildConfig.VERSION_NAME +
                if(BuildConfig.DEBUG) "-debug" else "" }"
    }

    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (isTv) {
            focusRequester.requestFocus()
        }
    }

    if (supportState.appUpdate != null) {
        UpdateDialog(
            viewModel = viewModel,
            context = context,
            onPermissionNeeded = { showPermissionDialog = true },
        )
    }

    if (showPermissionDialog) {
        PermissionDialog(context = context, onDismiss = { showPermissionDialog = false })
    }

    fun openWebUrl(url: String) {
        context.openWebUrl(url).onFailure {
            scope.launch {
                viewModel.postSideEffect(
                    GlobalSideEffect.Snackbar(
                        StringValue.StringResource(R.string.no_browser_detected),
                        ToastType.Error,
                    ),
                )
            }
        }
    }

    val scrollState = rememberScrollState()

    // The update row sits near the top (Resources), so this brings it into view
    LaunchedEffect(Unit) {
        sharedViewModel.showUpdateStatusRequested.collect { requested ->
            if (!requested) return@collect
            scrollState.animateScrollTo(0)
            sharedViewModel.consumeShowUpdateStatus()
        }
    }

    // Shuttle (user 2026-11-24, approved preview): the About screen
    // opens with a hero card — the same purple-blue gradient as the
    // home hero, the shuttle mark, the version and the thank-you line
    // — and the links are grouped into big rounded cards (Resources,
    // Other) with tinted-squircle icons. The rows and their actions
    // are unchanged; only the grouping and styling are new.
    val isLight = isLightShuttleTheme()
    val heroTextColor = if (isLight) HeroOnLightGradient else HeroOnGradient

    Column(
        modifier =
            Modifier.fillMaxSize()
                .verticalScroll(scrollState)
                .padding(top = 8.dp, bottom = 16.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
    ) {
        Box(
            modifier =
                Modifier.padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .connectedHeroBackground(isLight)
                    .padding(vertical = 24.dp, horizontal = 16.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ShuttleMark(size = 64.dp, cornerRadius = 18.dp)
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = heroTextColor,
                )
                Text(
                    text = version,
                    style = MaterialTheme.typography.bodyMedium,
                    color = heroTextColor,
                )
                Text(
                    text = stringResource(R.string.thank_you),
                    style = MaterialTheme.typography.bodySmall,
                    color = heroTextColor.copy(alpha = 0.8f),
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.resources))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Balance) },
                    title = stringResource(R.string.licenses),
                    onClick = { navController.push(Route.License) },
                    modifier = Modifier.focusRequester(focusRequester),
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                // The project's own GitHub repo (user 22:19): opens
                // github.com/meishah/shuttle in the browser.
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Code) },
                    title = stringResource(R.string.github),
                    description = { DescriptionText(githubUrl) },
                    trailing = { Icon(Icons.AutoMirrored.Outlined.Launch, null) },
                    onClick = { openWebUrl(githubUrl) },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                // Check update: latest release of github.com/meishah/shuttle,
                // checked only when tapped (no auto-check on opening the screen).
                val download = supportState.download
                val presentation = rememberUpdateDownloadPresentation(download)
                val downloadReady = download is UpdateDownloadState.Completed
                val downloadFailed = download is UpdateDownloadState.Failed
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.InstallMobile) },
                    title =
                        stringResource(
                            when {
                                presentation.showProgress -> R.string.downloading_update
                                downloadReady -> R.string.update_ready_to_install
                                downloadFailed -> R.string.update_download_failed_title
                                else -> R.string.check_update
                            },
                        ),
                    description =
                        when {
                            presentation.showProgress -> {
                                { UpdateDownloadProgress(presentation) }
                            }
                            downloadReady -> {
                                { DescriptionText(stringResource(R.string.update_tap_to_install)) }
                            }
                            downloadFailed -> {
                                { DescriptionText(stringResource(R.string.update_tap_to_retry)) }
                            }
                            else -> null
                        },
                    onClick = {
                        if (BuildConfig.DEBUG) {
                            scope.launch {
                                viewModel.postSideEffect(
                                    GlobalSideEffect.Snackbar(
                                        StringValue.StringResource(
                                            R.string.update_check_unsupported,
                                        ),
                                        ToastType.Warning,
                                    ),
                                )
                            }
                            return@SurfaceRow
                        }
                        when (BuildConfig.FLAVOR) {
                            Constants.GOOGLE_PLAY_FLAVOR ->
                                context.launchPlayStoreListing().onFailure {
                                    openWebUrl(playStoreUrl)
                                }
                            Constants.FDROID_FLAVOR -> openWebUrl(izzyUrl)
                            // A running or finished download reopens the dialog, no new check
                            else ->
                                if (download is UpdateDownloadState.Downloading || downloadReady) {
                                    viewModel.showActiveDownload()
                                } else {
                                    viewModel.checkForStandaloneUpdate()
                                }
                        }
                    },
                    trailing =
                        if (BuildConfig.FLAVOR == Constants.STANDALONE_FLAVOR) null
                        else {
                            { Icon(Icons.AutoMirrored.Outlined.Launch, null) }
                        },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.other))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Memory) },
                    title = stringResource(R.string.about),
                    description = {
                        Column {
                            DescriptionText(stringResource(R.string.version_template, version))
                            DescriptionText(
                                stringResource(R.string.flavor_template, BuildConfig.FLAVOR),
                            )
                        }
                    },
                    onClick = { clipboardManager.copy(version) },
                    containerColor = Color.Transparent,
                )
                if (BuildConfig.FLAVOR == Constants.GOOGLE_PLAY_FLAVOR) {
                    ShuttleSettingsDivider()
                    SurfaceRow(
                        leading = { ShuttleSettingIcon(Icons.Outlined.Reviews) },
                        title = stringResource(R.string.review),
                        trailing = { Icon(Icons.AutoMirrored.Outlined.Launch, null) },
                        onClick = {
                            context.launchPlayStoreReview().onFailure {
                                openWebUrl(playReviewsUrl)
                            }
                        },
                        containerColor = Color.Transparent,
                    )
                }
            }
        }
    }
}
