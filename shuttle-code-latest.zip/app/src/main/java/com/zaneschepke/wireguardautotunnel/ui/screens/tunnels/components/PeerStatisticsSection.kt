package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import android.text.format.Formatter
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroOnGradient
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wgtunnel.parser.ActivePeer
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.util.extensions.abbreviateKey
import com.zaneschepke.wireguardautotunnel.util.extensions.toAgoDisplay

/**
 * The peer stats are split across the two columns of the connected
 * hero (user 2026-11-27): the old single stack left the hero's right
 * half empty. Left column: just the peer line (the overview's status
 * + uptime sit above it). Right column: transfer / handshake /
 * endpoint. Same lines, same text — only the arrangement changed.
 */
@Composable
fun PeerStatisticsLeft(peer: ActivePeer) {
    val style = MaterialTheme.typography.bodySmall
    // Hero-only stats on the connected gradient: near-white on the
    // dark theme's purple gradient, dark on the light theme's
    // light-lavender gradient — never outline (washed out).
    val color = HeroOnGradient

    StatText(
        text = stringResource(R.string.peer_template, peer.publicKey.abbreviateKey()),
        style = style,
        color = color,
    )
}

@Composable
fun PeerStatisticsRight(peer: ActivePeer, now: Long) {
    val context = LocalContext.current
    val style = MaterialTheme.typography.bodySmall
    // Hero-only stats on the connected gradient: near-white on the
    // dark theme's purple gradient, dark on the light theme's
    // light-lavender gradient — never outline (washed out).
    val color = HeroOnGradient

    val rx = Formatter.formatFileSize(context, peer.rxBytes ?: 0L)

    val tx = Formatter.formatFileSize(context, peer.txBytes ?: 0L)

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        TransferStatsRow(rx = rx, tx = tx, style = style, color = color)

        StatText(
            text =
                stringResource(
                    R.string.handshake_template,
                    peer.lastHandshakeSeconds?.toAgoDisplay(now)
                        ?: stringResource(R.string.never).lowercase(),
                ),
            style = style,
            color = color,
        )
        peer.endpoint?.let {
            StatText(stringResource(R.string.endpoint_template, it), style = style, color = color)
        }
    }
}
