package com.zaneschepke.wireguardautotunnel.ui.screens.openvpn

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dokar.sonner.ToastType
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsFieldCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.viewmodel.OpenVpnEditViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectSideEffect

/**
 * OpenVPN config editor: username/password fields on top (saved encrypted
 * on the profile, used automatically at connect time), raw .ovpn text
 * editor below. Save is triggered by the nav bar's save icon
 * (LocalSideEffect.SaveChanges), matching ConfigEditScreen.
 *
 * Restyled like Settings (user 2026-11-25, approved preview): the
 * fields sit in big rounded cards. Fields and actions unchanged.
 */
@Composable
fun OpenVpnEditScreen(
    viewModel: OpenVpnEditViewModel,
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val navController = LocalNavController.current
    val text by viewModel.text.collectAsStateWithLifecycle()
    val username by viewModel.username.collectAsStateWithLifecycle()
    val password by viewModel.password.collectAsStateWithLifecycle()
    val serverOverride by viewModel.serverOverride.collectAsStateWithLifecycle()
    val saved by viewModel.saved.collectAsStateWithLifecycle()
    val saveError by viewModel.saveError.collectAsStateWithLifecycle()
    val credentialsError by viewModel.credentialsError.collectAsStateWithLifecycle()
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(saved) {
        if (saved) {
            sharedViewModel.showSnackMessage(
                StringValue.StringResource(R.string.ovpn_edit_saved),
                ToastType.Success,
            )
            navController.pop()
        }
    }

    LaunchedEffect(saveError) {
        if (saveError) {
            sharedViewModel.showSnackMessage(
                StringValue.StringResource(R.string.ovpn_edit_invalid),
                ToastType.Error,
            )
            viewModel.consumeSaveError()
        }
    }

    LaunchedEffect(credentialsError) {
        if (credentialsError) {
            sharedViewModel.showSnackMessage(
                StringValue.StringResource(R.string.ovpn_credentials_save_failed),
                ToastType.Error,
            )
            viewModel.consumeCredentialsError()
        }
    }

    sharedViewModel.collectSideEffect { sideEffect ->
        if (sideEffect is LocalSideEffect.SaveChanges) {
            viewModel.save()
        }
    }

    val currentText = text ?: return
    val scrollState = rememberScrollState()
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .statusBarsPadding()
                .padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.ovpn_credentials_title))
            DescriptionText(
                text = stringResource(R.string.ovpn_credentials_hint),
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            ShuttleSettingsFieldCard {
                // Explicit label colours (user 2026-11-27): the
                // default focused label rendered near-white on the
                // light background and was unreadable.
                val labelColors =
                    OutlinedTextFieldDefaults.colors(
                        focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                OutlinedTextField(
                    value = username,
                    onValueChange = viewModel::onUsernameChanged,
                    label = {
                        Text(
                            text = stringResource(R.string.username),
                            // Explicit colour on the label Text itself
                            // (user 2026-11-27): the 1.4.2
                            // focusedLabelColor had no effect on-device
                            // — the label stayed near-white. An explicit
                            // color here always wins.
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    singleLine = true,
                    colors = labelColors,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = viewModel::onPasswordChanged,
                    label = {
                        Text(
                            text = stringResource(R.string.password),
                            // Same explicit label colour as the username
                            // field above (user 2026-11-27).
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    singleLine = true,
                    colors = labelColors,
                    visualTransformation =
                        if (passwordVisible) VisualTransformation.None
                        else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector =
                                    if (passwordVisible) Icons.Filled.VisibilityOff
                                    else Icons.Filled.Visibility,
                                contentDescription =
                                    stringResource(
                                        if (passwordVisible) R.string.hide_password
                                        else R.string.show_password,
                                    ),
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.ovpn_server_override))
            DescriptionText(
                text = stringResource(R.string.ovpn_server_override_hint),
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            ShuttleSettingsFieldCard {
                OutlinedTextField(
                    value = serverOverride,
                    onValueChange = viewModel::onServerOverrideChanged,
                    label = {
                        Text(
                            text = stringResource(R.string.ovpn_server_override),
                            // Same explicit label colour as the
                            // credentials fields above (user 2026-11-27).
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    singleLine = true,
                    // Same explicit label colours as the credentials
                    // fields above (user 2026-11-27).
                    colors =
                        OutlinedTextFieldDefaults.colors(
                            focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.configuration))
            ShuttleSettingsFieldCard {
                BasicTextField(
                    value = currentText,
                    onValueChange = viewModel::onTextChanged,
                    textStyle =
                        TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = MaterialTheme.typography.bodyMedium.fontSize,
                            color = MaterialTheme.colorScheme.onSurface,
                        ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
