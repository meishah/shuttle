package com.zaneschepke.wireguardautotunnel.domain.repository

import com.zaneschepke.wireguardautotunnel.domain.enums.StrictSplitNotice
import com.zaneschepke.wireguardautotunnel.domain.model.AppState
import kotlinx.coroutines.flow.Flow

interface AppStateRepository {
    suspend fun isLocationDisclosureShown(): Boolean

    suspend fun setLocationDisclosureShown(shown: Boolean)

    suspend fun isBatteryOptimizationDisableShown(): Boolean

    suspend fun setBatteryOptimizationDisableShown(shown: Boolean)

    suspend fun isNotificationPermissionRequested(): Boolean

    suspend fun setNotificationPermissionRequested(requested: Boolean)

    suspend fun setShouldShowDonationSnackbar(show: Boolean)

    suspend fun shouldShowDonationSnackbar(): Boolean

    suspend fun isDesktopPromptShown(): Boolean

    suspend fun setDesktopPromptShown(shown: Boolean)

    suspend fun isStrictSplitDecided(): Boolean

    suspend fun setStrictSplitDecided(decided: Boolean)

    val strictSplitNotice: Flow<StrictSplitNotice?>

    suspend fun setStrictSplitNotice(notice: StrictSplitNotice?)

    suspend fun getLastActiveTunnelIds(): List<Int>

    suspend fun setLastActiveTunnelIds(ids: List<Int>)

    suspend fun clearLastActiveTunnelIds()

    /** The tunnel the user last connected to (survives disconnects and restarts). */
    suspend fun getLastUsedTunnelId(): Int?

    suspend fun setLastUsedTunnelId(id: Int)

    /** The group filter the user last left the app on (All = null). */
    suspend fun getSelectedGroupId(): Int?

    suspend fun setSelectedGroupId(id: Int?)

    /** The update version the on-open dialog was last shown for (null = never). */
    suspend fun getLastShownUpdateVersion(): String?

    suspend fun setLastShownUpdateVersion(version: String)

    val flow: Flow<AppState>
}
