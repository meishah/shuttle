package com.zaneschepke.wireguardautotunnel.ui.navigation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.common.animations.AnimatedFloatIcon
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleBottomScrim
import com.zaneschepke.wireguardautotunnel.ui.navigation.Tab
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender
import com.zaneschepke.wireguardautotunnel.ui.theme.SilverTree

/**
 * Orion Store style bottom bar: a floating dark pill that hovers above the
 * content with side and bottom margins, whose selected tab is a centered
 * highlighted light-lavender pill with icon + label (like Orion's "Orbit"
 * pill), while the other tabs are bare icons.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun BottomNavbar(
    isAutoTunnelActive: Boolean,
    currentTab: Tab,
    onTabSelected: (Tab) -> Unit,
    modifier: Modifier = Modifier,
    // Frosted glass (user 17:46): the whole bottom slot is a
    // gradient scrim (see ShuttleHaze.kt), fading in smoothly from
    // clear at its top to full frost at the screen edge — no hard
    // line (user 19:53: "اون خط باید کم کم محو بشه"). Haze was
    // replaced in 1.5 because its progressive blur drew a hard
    // edge on her phone instead of a fade.
) {
    val isTv = LocalIsAndroidTV.current
    val rippleTheme = LocalRippleConfiguration.current
    val theme = remember { if (isTv) rippleTheme else null }
    // Light-theme contrast (audit 1.3): the pill is translucent so
    // the blur shows through, but in the light theme dark-grey
    // unselected icons sit on it — over a dark blurred tile behind,
    // a 0.6-alpha light pill darkens to mid grey and the icons lose
    // contrast. Keep the pill nearly opaque in the light theme
    // (0.88) and more translucent in the dark theme (0.65), where
    // the icons are light grey and stay readable either way. The
    // surface luminance decides, so dynamic themes follow too.
    val isLightTheme = MaterialTheme.colorScheme.surface.luminance() > 0.5f
    val pillColor =
        MaterialTheme.colorScheme.surfaceContainerHigh.copy(
            alpha = if (isLightTheme) 0.88f else 0.65f,
        )
    Box(
        // Raised off the bottom edge (user 18:24, "خیلی رفته پایین
        // باید بالاتر باشه"): the pill floats clearly above the
        // bottom edge with clear space beneath it — 48dp below it,
        // not 28dp. The scrim stays on this OUTER box, whose bounds
        // still span the whole bottom slot to the screen edge, so
        // the frost itself still reaches the very bottom (user
        // 17:49) — only the pill sits higher inside it.
        modifier =
            modifier
                .shuttleBottomScrim()
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 48.dp),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = pillColor,
            contentColor = MaterialTheme.colorScheme.onSurface,
            shadowElevation = 8.dp,
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Shuttle: the AutoTunnel tab (auto-tunnel rules) is hidden
                // from the UI — the user never asked for it. The route and
                // engine stay intact, just unreachable from the nav bar.
                Tab.entries.filter { it != Tab.AUTOTUNNEL }.forEach { tab ->
                    val isSelected = currentTab == tab
                    val hasBadge = tab == Tab.AUTOTUNNEL && isAutoTunnelActive
                    val button =
                        @Stable @Composable {
                            CompositionLocalProvider(LocalRippleConfiguration provides theme) {
                                val pillColor by
                                    animateColorAsState(
                                        targetValue =
                                            if (isSelected) {
                                                // Light lavender pill with DARK text/icon
                                                // in BOTH themes (user 17:52) — like
                                                // Orion's highlighted active tab. Never
                                                // a dark pill with light text.
                                                OrionLavender
                                            } else {
                                                Color.Transparent
                                            },
                                        animationSpec =
                                            spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMediumLow,
                                            ),
                                        label = "navTabPill",
                                    )
                                CompositionLocalProvider(
                                    LocalContentColor provides
                                        if (isSelected) {
                                            OnSelectedCapsule
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier =
                                            Modifier.semantics { selected = isSelected }
                                                .clip(RoundedCornerShape(50))
                                                .background(pillColor)
                                                .clickable { onTabSelected(tab) }
                                                .padding(
                                                    horizontal = if (isSelected) 16.dp else 12.dp,
                                                    vertical = 10.dp,
                                                )
                                                .animateContentSize(
                                                    animationSpec =
                                                        spring(
                                                            dampingRatio =
                                                                Spring.DampingRatioMediumBouncy,
                                                            stiffness = Spring.StiffnessMediumLow,
                                                        ),
                                                ),
                                    ) {
                                        AnimatedFloatIcon(
                                            activeIcon = tab.activeIcon,
                                            inactiveIcon = tab.inactiveIcon,
                                            isSelected = isSelected,
                                            contentDescription = stringResource(tab.titleRes),
                                            modifier = Modifier.size(24.dp),
                                        )
                                        AnimatedVisibility(visible = isSelected) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = stringResource(tab.titleRes),
                                                    style =
                                                        MaterialTheme.typography
                                                            .labelLargeEmphasized,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    if (hasBadge) {
                        BadgedBox(
                            badge = {
                                Badge(
                                    modifier = Modifier.offset(x = (-4).dp, y = (4).dp).size(6.dp),
                                    containerColor = SilverTree,
                                )
                            },
                        ) {
                            button()
                        }
                    } else {
                        button()
                    }
                }
            }
        }
    }
}
