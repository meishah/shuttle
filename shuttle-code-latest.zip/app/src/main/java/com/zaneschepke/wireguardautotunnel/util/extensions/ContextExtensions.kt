package com.zaneschepke.wireguardautotunnel.util.extensions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import com.zaneschepke.wireguardautotunnel.BuildConfig
import com.zaneschepke.wireguardautotunnel.util.Constants
import com.zaneschepke.wireguardautotunnel.util.FileUtils
import java.io.File
import java.io.InputStream
import java.util.Locale
import timber.log.Timber

fun Context.openWebUrl(url: String): Result<Unit> = runCatching {
    val webpage: Uri = url.toUri()
    val intent =
        Intent(Intent.ACTION_VIEW, webpage).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    startActivity(intent)
}

fun Context.launchNotificationSettings() {
    if (isRunningOnTv()) return launchAppSettings()
    val settingsIntent: Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    this.startActivity(settingsIntent)
}

fun Context.hasSAFSupport(mimeType: String): Boolean {
    // Some Android TV devices falsely report to support SAF
    // In general, on Android TV devices we should fall back to legacy exports
    if (isRunningOnTv()) return false
    val intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = mimeType
            addCategory(Intent.CATEGORY_OPENABLE)
        }
    val activitiesToResolveIntent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()),
            )
        } else {
            packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
    Timber.d(
        "Found ${activitiesToResolveIntent.size} activities: ${activitiesToResolveIntent.map { it.activityInfo.packageName }}",
    )

    return if (activitiesToResolveIntent.isEmpty()) {
        Timber.w("No activities found to handle SAF intent")
        false
    } else if (
        isRunningOnTv() &&
            activitiesToResolveIntent.all {
                val name = it.activityInfo.packageName
                name.startsWith(FileUtils.GOOGLE_TV_EXPLORER_STUB) ||
                    name.startsWith(FileUtils.ANDROID_TV_EXPLORER_STUB)
            }
    ) {
        Timber.w("Only stub file explorers found on TV")
        false
    } else {
        true
    }
}

fun Context.isRunningOnTv(): Boolean {
    return packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
}

fun Context.launchVpnSettings(): Result<Unit> {
    return kotlin.runCatching {
        val intent =
            Intent(Constants.VPN_SETTINGS_PACKAGE).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        startActivity(intent)
    }
}

fun Context.getInputStreamFromUri(uri: Uri): InputStream? {
    return this.applicationContext.contentResolver.openInputStream(uri)
}

fun Context.launchLocationServicesSettings(): Result<Unit> {
    return kotlin.runCatching {
        val intent =
            Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        startActivity(intent)
    }
}

fun Context.launchNetworkAndInternetSettings(): Result<Unit> = runCatching {
    startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun Context.launchAppSettings() {
    kotlin
        .runCatching {
            val intent =
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            startActivity(intent)
        }
        .onFailure {
            val fallback = Intent(Settings.ACTION_SETTINGS)
            startActivity(fallback)
        }
}

fun Context.canInstallPackages(): Boolean {
    return packageManager.canRequestPackageInstalls()
}

fun Context.requestInstallPackagesPermission() {
    val intent =
        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
            data = "package:${packageName}".toUri()
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    startActivity(intent)
}

fun Context.apkInstallIntent(apkFile: File): Intent {
    val apkUri = FileProvider.getUriForFile(this, BuildConfig.FILE_PROVIDER_AUTHORITY, apkFile)
    return Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(apkUri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}

fun Context.installApk(apkFile: File) {
    startActivity(apkInstallIntent(apkFile))
}

fun Context.launchPlayStoreListing(): Result<Unit> = runCatching {
    val intent =
        Intent(Intent.ACTION_VIEW, "market://details?id=$packageName".toUri()).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.android.vending")
        }

    if (intent.resolveActivity(packageManager) != null) {
        startActivity(intent)
    } else {
        throw IllegalStateException("Play Store not found")
    }
}

fun Context.launchPlayStoreReview(): Result<Unit> = runCatching {
    val uri = "market://details?id=$packageName&showAllReviews=true".toUri()
    val intent =
        Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.android.vending")
        }
    if (intent.resolveActivity(packageManager) != null) {
        startActivity(intent)
    } else {
        throw IllegalStateException("Play Store not found")
    }
}

fun Activity.setScreenBrightness(brightness: Float) {
    window.attributes = window.attributes.apply { screenBrightness = brightness }
}

fun PackageManager.getFriendlyAppName(packageName: String, appInfo: ApplicationInfo): String {
    val label =
        try {
            getApplicationLabel(appInfo).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName
        }

    // probably a package, parse it
    return if (label.count { it == '.' } > 1) {
        val lastSegment = label.substringAfterLast(".", label)
        lastSegment.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
        }
    } else {
        label
    }
}
