package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.model.InstalledPackage
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.banner.InfoNotice
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleSettingsCardColor
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.state.SplitBehavior
import com.zaneschepke.wireguardautotunnel.ui.state.SplitAppListSummary

/**
 * Restyled like Settings (user 2026-11-25, approved preview): the
 * mode is three pills, the strict row sits in a card, and the apps
 * live in one big rounded card with a pill search on top. Rows and
 * actions unchanged.
 */
@Composable
fun SplitTunnelContent(
    activeBehavior: SplitBehavior,
    selectedPackages: Set<String>,
    installedPackages: List<InstalledPackage>,
    onActiveBehaviorChange: (SplitBehavior) -> Unit,
    onAppSelectionToggle: (String, Boolean) -> Unit,
    showSystemApps: Boolean,
    globalOverride: SplitAppListSummary? = null,
    strictSplitEnabled: Boolean? = null,
    onStrictSplitClick: () -> Unit = {},
) {
    val isTv = LocalIsAndroidTV.current
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (isTv) focusRequester.requestFocus() }

    var query by rememberSaveable { mutableStateOf("") }
    val locale = Locale.current
    // Pin the selection from the first time this mode is shown.
    val showApps = activeBehavior != SplitBehavior.ALL
    val pinnedByBehavior = remember { mutableMapOf<SplitBehavior, Set<String>>() }
    val pinnedPackages =
        if (showApps) pinnedByBehavior.getOrPut(activeBehavior) { selectedPackages } else emptySet()
    val filteredAndSortedPackages =
        remember(
            installedPackages,
            query,
            pinnedPackages,
            selectedPackages,
            showSystemApps,
            locale,
        ) {
            filterAndSortPackages(
                installedPackages,
                query,
                pinnedPackages,
                selectedPackages,
                showSystemApps,
                locale,
            )
        }

    // Floating bars (fade fix, user 2026-11-25): the fixed header
    // clears the floating top bar; the app list scrolls inside its
    // card, with bottom content padding so the last app clears the
    // floating bottom nav.
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding().padding(top = 70.dp)) {
        if (globalOverride != null) {
            InfoNotice(
                title = stringResource(R.string.managed_globally),
                message = stringResource(R.string.split_override_notice),
                detail = splitAppsLabel(globalOverride),
            )
        }
        SplitBehaviorOptions(
            activeBehavior = activeBehavior,
            onBehaviorChange = onActiveBehaviorChange,
            modifier = Modifier.focusRequester(focusRequester).padding(top = 16.dp),
        )
        if (showApps && strictSplitEnabled != null) {
            ShuttleSettingsCard(modifier = Modifier.padding(top = 12.dp)) {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Shield) },
                    title = stringResource(R.string.strict_split_tunnel),
                    description = {
                        DescriptionText(
                            stringResource(
                                if (strictSplitEnabled) R.string.state_on else R.string.state_off,
                            ),
                        )
                    },
                    trailing = { modifier ->
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            contentDescription = null,
                            modifier = modifier,
                        )
                    },
                    onClick = onStrictSplitClick,
                    containerColor = Color.Transparent,
                )
            }
        }
        if (showApps) {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                ShuttleSettingsLabel(
                    stringResource(
                        when (activeBehavior) {
                            SplitBehavior.INCLUDE -> R.string.select_apps_to_include
                            SplitBehavior.EXCLUDE -> R.string.select_apps_to_exclude
                            SplitBehavior.ALL -> R.string.select_apps_to_exclude
                        },
                    ),
                )
                AppSearchField(query = query, onQueryChange = { query = it })
            }
            // One big rounded card for the whole app list (the
            // LazyColumn scrolls inside it, clipped to the corners).
            // weight(1f): the card takes exactly the remaining
            // height, so the last app is never hidden under the nav.
            Box(
                modifier =
                    Modifier.weight(1f)
                        .padding(horizontal = 16.dp)
                        .padding(top = 8.dp, bottom = 16.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(shuttleSettingsCardColor()),
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 140.dp),
                    horizontalAlignment = Alignment.Start,
                ) {
                    itemsIndexed(
                        filteredAndSortedPackages,
                        key = { _, pkg -> pkg.packageName },
                    ) { index, pkg ->
                        val selected = selectedPackages.contains(pkg.packageName)
                        AppListItem(
                            installedPackage = pkg,
                            isSelected = selected,
                            onToggle = { onAppSelectionToggle(pkg.packageName, it) },
                        )
                        if (index < filteredAndSortedPackages.lastIndex) {
                            ShuttleSettingsDivider()
                        }
                    }
                }
            }
        }
    }
}
