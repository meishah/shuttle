package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.OnLimeConnect

/**
 * Pre-connect username/password prompt for OpenVPN configs (user
 * 2026-11-27): shown when the user taps a config that needs auth and
 * has no saved credentials, BEFORE the core is launched. Same design
 * as the mid-connection prompt (OpenVpnUserInputActivity): username +
 * password fields, Remember password (default on), Cancel + lime
 * Connect. Connect stays disabled until both fields are filled — an
 * empty password must never reach the core (it would fail auth
 * without ever asking again).
 */
@Composable
fun OvpnCredentialsDialog(
    tunnelName: String,
    savedUsername: String,
    onSubmit: (username: String, password: String, rememberPassword: Boolean) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var username by rememberSaveable { mutableStateOf(savedUsername) }
    var password by rememberSaveable { mutableStateOf("") }
    var rememberPassword by rememberSaveable { mutableStateOf(true) }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    val canSubmit = username.isNotBlank() && password.isNotEmpty()

    AlertDialog(
        onDismissRequest = onCancel,
        modifier = modifier,
        title = {
            Text(
                text = tunnelName,
                style = MaterialTheme.typography.titleLargeEmphasized,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = stringResource(R.string.ovpn_need_auth),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = {
                        Text(
                            stringResource(R.string.username),
                            // Explicit colour on the label Text itself
                            // (user 2026-11-27): the 1.4.2
                            // focusedLabelColor had no effect on-device
                            // — the label stayed near-white. An explicit
                            // color here always wins.
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    singleLine = true,
                    // Explicit label colours (user 2026-11-27): the
                    // default focused label rendered near-white on the
                    // light dialog background and was unreadable.
                    // onSurface / onSurfaceVariant read in both themes.
                    colors =
                        OutlinedTextFieldDefaults.colors(
                            focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = {
                        Text(
                            stringResource(R.string.password),
                            // Same explicit label colour as the username
                            // field above (user 2026-11-27).
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    },
                    singleLine = true,
                    colors =
                        OutlinedTextFieldDefaults.colors(
                            focusedLabelColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                    visualTransformation =
                        if (passwordVisible) VisualTransformation.None
                        else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector =
                                    if (passwordVisible) Icons.Filled.VisibilityOff
                                    else Icons.Filled.Visibility,
                                contentDescription =
                                    stringResource(
                                        if (passwordVisible) R.string.hide_password
                                        else R.string.show_password,
                                    ),
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = rememberPassword,
                        onCheckedChange = { rememberPassword = it },
                    )
                    Text(stringResource(R.string.ovpn_remember_password))
                }
            }
        },
        dismissButton = {
            Button(
                onClick = onCancel,
                colors =
                    ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                shape = RoundedCornerShape(50),
            ) {
                Text(stringResource(R.string.cancel))
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(username, password, rememberPassword) },
                enabled = canSubmit,
                colors =
                    ButtonDefaults.buttonColors(
                        containerColor = LimeConnect,
                        contentColor = OnLimeConnect,
                    ),
                shape = RoundedCornerShape(50),
            ) {
                Text(stringResource(R.string.ovpn_connect))
            }
        },
    )
}
