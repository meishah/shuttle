package com.zaneschepke.wireguardautotunnel.ui.screens.support.license

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mikepenz.aboutlibraries.ui.compose.m3.LibrariesContainer
import com.mikepenz.aboutlibraries.ui.compose.variant.LibraryDetailMode

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun LicenseScreen() {
    val context = LocalContext.current
    val libs = remember { buildLibsWithAdditionalLibraries(context) }

    LibrariesContainer(
        libraries = libs,
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(top = 70.dp, bottom = 140.dp),
        detailMode = LibraryDetailMode.Sheet,
    )
}
