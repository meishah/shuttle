package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.settings.config.edit.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.wgtunnel.parser.crypto.Key
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.MimicMode
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleSettingsLabelColor
import com.zaneschepke.wireguardautotunnel.ui.state.ConfigUiState
import com.zaneschepke.wireguardautotunnel.ui.state.EditableInterface

/**
 * Restyled like Settings (user 2026-11-25, approved preview): the
 * interface fields sit in big rounded cards (Interface, DNS & MTU,
 * Scripts, Amnezia groups). Fields and actions unchanged.
 */
@Composable
fun InterfaceSection(
    uiState: ConfigUiState,
    onInterfaceChange: (EditableInterface) -> Unit,
    onTunnelNameChange: (String) -> Unit,
    onMimic: (MimicMode) -> Unit,
    onToggleScripts: () -> Unit,
    onToggleAmneziaValues: () -> Unit,
    onToggleAmneziaCompat: () -> Unit,
    onToggleDropdown: (Boolean) -> Unit,
) {
    val isTv = LocalIsAndroidTV.current

    Column(verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top)) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        ) {
            Text(
                text = stringResource(R.string.interface_),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = shuttleSettingsLabelColor(),
            )
            Row {
                if (isTv) {
                    IconButton(
                        enabled = true,
                        onClick = {
                            val privateKey = Key.generatePrivateKey()
                            val publicKey = Key.generatePublicKey(privateKey)
                            onInterfaceChange(
                                uiState.draft.config.`interface`.copy(
                                    privateKey = privateKey.toBase64(),
                                    publicKey = publicKey.toBase64(),
                                ),
                            )
                        },
                    ) {
                        Icon(
                            Icons.Rounded.Refresh,
                            stringResource(R.string.rotate_keys),
                            tint = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
                InterfaceDropdown(
                    uiState = uiState,
                    onToggleDropdown = onToggleDropdown,
                    onToggleScripts = onToggleScripts,
                    onToggleAmneziaValues = onToggleAmneziaValues,
                    onToggleAmneziaCompatibility = onToggleAmneziaCompat,
                    onMimic = onMimic,
                )
            }
        }
        InterfaceFields(
            uiState = uiState,
            onInterfaceChange = onInterfaceChange,
            onTunnelNameChange = onTunnelNameChange,
        )
    }
}
