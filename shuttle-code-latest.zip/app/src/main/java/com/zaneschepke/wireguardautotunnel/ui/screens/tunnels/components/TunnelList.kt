package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.overscroll
import androidx.compose.foundation.rememberOverscrollEffect
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wgtunnel.backend.state.ActiveTunnel
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnState
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ExpandingRowListItem
import com.zaneschepke.wireguardautotunnel.ui.common.scroll.appScrollbar
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.screens.pin.LocalAppLocked
import com.zaneschepke.wireguardautotunnel.ui.state.DisplayTunnelState
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelListRow
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelsUiState
import com.zaneschepke.wireguardautotunnel.ui.state.applyDisplayedOrder
import com.zaneschepke.wireguardautotunnel.ui.state.buildTunnelListRows
import com.zaneschepke.wireguardautotunnel.ui.state.partitionUnreachableLast
import com.zaneschepke.wireguardautotunnel.ui.theme.AlertRed
import com.zaneschepke.wireguardautotunnel.ui.theme.TileOnNavySecondary
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.OnLimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionAmber
import com.zaneschepke.wireguardautotunnel.ui.theme.PingAmberDark
import com.zaneschepke.wireguardautotunnel.ui.theme.PingGreenDark
import com.zaneschepke.wireguardautotunnel.ui.theme.PingRedDark
import com.zaneschepke.wireguardautotunnel.ui.theme.SilverTree
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import sh.calvin.reorderable.DragGestureDetector
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TunnelList(
    uiState: TunnelsUiState,
    modifier: Modifier = Modifier,
    viewModel: SharedAppViewModel,
    onImportClick: () -> Unit = {},
    // Per-tile ⋮ menu action (user 2026-11-24: long-press removed).
    onTunnelMenuAction: (TunnelConfig, TunnelMenuAction) -> Unit = { _, _ -> },
    // The home top bar's clearance (from MainActivity, two-edge
    // measurement fix14): the distance from this list's top edge to
    // the bar's bottom edge, plus the approved 10dp chips→hero gap.
    // It is measured on every phone, not guessed — the old fixed
    // 186dp was shorter than the bar, so the chips row covered the
    // hero's title in 1.4 (user 19:48). The default is the same
    // 186dp, used before the first measurement.
    topPadding: Dp = 186.dp,
    // Reports this list's top edge (root coordinates, px) so
    // MainActivity can measure it against the bar's bottom edge.
    onListTopPx: (Float) -> Unit = {},
) {
    val navController = LocalNavController.current
    val isTv = LocalIsAndroidTV.current
    val hapticFeedback = LocalHapticFeedback.current

    val focusRequester = remember { FocusRequester() }
    var editableRows by remember { mutableStateOf(uiState.rows) }

    val locked = LocalAppLocked.current
    // Waits for the PIN lock, which holds focus while it covers this screen
    LaunchedEffect(locked) {
        if (isTv && !locked) {
            focusRequester.requestFocus()
        }
    }

    val lazyListState = rememberLazyListState()

    fun persistRows(rows: List<TunnelListRow>) {
        val (groups, tunnels) =
            applyDisplayedOrder(
                rows,
                uiState.groups,
                uiState.tunnels,
                uiState.reorderScopeGroupId,
            )
        viewModel.applyReorderDraft(groups, tunnels)
    }

    val reorderableLazyListState =
        rememberReorderableLazyListState(
            lazyListState,
            scrollThresholdPadding = WindowInsets.systemBars.asPaddingValues(),
        ) { from, to ->
            editableRows =
                editableRows.toMutableList().apply { add(to.index, removeAt(from.index)) }
            persistRows(editableRows)
            hapticFeedback.performHapticFeedback(HapticFeedbackType.SegmentFrequentTick)
        }

    LaunchedEffect(
        uiState.isReorderMode,
        uiState.reorderScopeGroupId,
        uiState.groups,
        uiState.tunnels,
    ) {
        if (uiState.isReorderMode && !reorderableLazyListState.isAnyItemDragging) {
            editableRows =
                buildTunnelListRows(
                    groups = uiState.groups,
                    tunnels = uiState.tunnels,
                    activeTunnelIds = uiState.backendStatus.activeTunnels.keys,
                    collapseGroups = uiState.reorderScopeGroupId == null,
                    scopeGroupId = uiState.reorderScopeGroupId,
                )
        }
    }

    val rows = if (uiState.isReorderMode) editableRows else uiState.rows

    // Group filter chips (user 17:29): groups live at the TOP next
    // to All — the protocol filter chips (WireGuard / OpenVPN) are
    // gone, and the big expandable group rows in the main list are
    // gone too. The list below shows only the configs of the selected
    // chip (All, or one group), flat — group headers stay only in
    // reorder mode. The filter lives in the activity-scoped ViewModel,
    // so opening a config detail and pressing back returns to the
    // same filtered view instead of resetting to All.
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedGroupId by viewModel.selectedGroupId.collectAsStateWithLifecycle()
    val pingProgress by viewModel.pingProgress.collectAsStateWithLifecycle()
    val displayRows =
        remember(rows, searchQuery, selectedGroupId, uiState.isReorderMode, uiState.pingLatencies, uiState.tunnels) {
            if (uiState.isReorderMode) {
                rows
            } else {
                val query = searchQuery.trim()
                val filtered =
                    rows.filterIsInstance<TunnelListRow.TunnelRow>().filter { row ->
                        val groupOk =
                            selectedGroupId == null || row.tunnel.groupId == selectedGroupId
                        val queryOk =
                            query.isEmpty() ||
                                row.tunnel.name.contains(query, ignoreCase = true) ||
                                (row.tunnel.ovpnServerLabel?.contains(query, ignoreCase = true) ==
                                    true)
                        groupOk && queryOk
                    }
                // Unreachable-last, applied at display time (user
                // 18:48): after a ping, configs that did not answer
                // sink below every reachable one, whatever positions
                // the database still holds. The partition is stable,
                // so the reachable rows keep their ping order.
                partitionUnreachableLast(filtered, uiState.pingLatencies)
            }
        }
    val listItems = if (uiState.isReorderMode) rows else displayRows
    val firstTunnelIndex = listItems.indexOfFirst { it is TunnelListRow.TunnelRow }
    val lastTunnelIndex = listItems.indexOfLast { it is TunnelListRow.TunnelRow }
    // Index of the first config tile in the visible list — it gets
    // the 21dp top / 8dp bottom corners (user 2026-11-24, measured
    // from her photo); every other tile is 8dp on all corners.

    // Report which tunnels are currently shown (after search + group
    // filter) so Ping only tests them. LaunchedEffect on the ID set:
    // no recomposition loop, and a mid-ping change cannot corrupt the
    // running ping's counts (the ViewModel snapshots the set when the
    // run starts).
    val visibleTunnelIds = remember(displayRows) {
        displayRows.filterIsInstance<TunnelListRow.TunnelRow>().map { it.tunnel.id }.toSet()
    }
    LaunchedEffect(visibleTunnelIds) { viewModel.setVisibleTunnelIds(visibleTunnelIds) }

    // Shuttle hero: the currently active tunnel (WireGuard or OpenVPN)
    // and its REAL state — connected only when the tunnel is really up.
    val ovpnActiveTunnel =
        uiState.openVpnActiveId?.let { id -> uiState.tunnels.firstOrNull { it.id == id } }
    val wgActiveTunnel =
        uiState.backendStatus.activeTunnels.keys.firstOrNull()?.let { id ->
            uiState.tunnels.firstOrNull { it.id == id }
        }
    val heroTunnel = ovpnActiveTunnel ?: wgActiveTunnel
    val heroBackendTunnel =
        heroTunnel?.let { uiState.backendStatus.activeTunnels[it.id] } ?: ActiveTunnel()
    val heroState: DisplayTunnelState =
        when {
            ovpnActiveTunnel != null ->
                when (uiState.openVpnState) {
                    is OpenVpnState.Connected -> DisplayTunnelState.Connected
                    is OpenVpnState.Connecting,
                    is OpenVpnState.WaitingForInput ->
                        DisplayTunnelState.EstablishingConnection
                    is OpenVpnState.AuthFailed,
                    is OpenVpnState.Error -> DisplayTunnelState.HandshakeFailure
                    is OpenVpnState.Disconnected -> DisplayTunnelState.Disconnected
                }
            heroTunnel != null -> DisplayTunnelState.from(heroBackendTunnel)
            else -> DisplayTunnelState.Disconnected
        }
    val heroStats: (@Composable () -> Unit)? =
        if (heroState is DisplayTunnelState.Connected && heroTunnel != null) {
            if (
                ovpnActiveTunnel != null &&
                    uiState.openVpnState is OpenVpnState.Connected
            ) {
                { OpenVpnStatisticsRow(uiState.openVpnState as OpenVpnState.Connected) }
            } else {
                { TunnelStatisticsRow(heroBackendTunnel) }
            }
        } else {
            null
        }
    val heroToggle: () -> Unit = {
        if (heroTunnel != null) {
            viewModel.stopTunnel(heroTunnel)
        } else {
            // Reconnect to the tunnel she last used — not the first
            // tunnel in the list (that was the reconnect bug: after a
            // disconnect, Connect started the wrong config).
            viewModel.startLastUsedTunnel()
        }
    }

    LazyColumn(
        // Clearance for the floating bars (user 17:41): the top bar
        // (SHUTTLE + actions capsules, search and chips) and the
        // bottom nav pill (~120dp incl. gesture bar, raised 48dp
        // off the bottom edge — user 18:24) float OVER the list, so
        // the first and last rows get padding and no config is ever
        // hidden or cut off under either bar. The content scrolls
        // beneath the frosted bars; the hero sits fully below the
        // top bar (user 18:48: nothing hidden behind it, nothing
        // cut off at the top). The fade zone under the top bar
        // overlaps the hero's top edge, exactly as in the approved
        // preview (user 18:24). In reorder/selection mode the top
        // bar shrinks to just the mode row (no search/chips), so the
        // padding drops to match.
        contentPadding =
            PaddingValues(
                // The measured top-bar clearance (topPadding, from
                // MainActivity) — fix11: the old fixed 186dp was
                // shorter than the real bar, so the chips row
                // covered the hero's title in 1.4. It is measured
                // against the bar's VISIBLE content bottom edge
                // (chips / mode row, fix15 — NOT the layout bottom,
                // which sits 18dp lower in the fade zone) in both
                // modes (the bar shrinks to just the mode row in
                // reorder/selection mode, so the measured clearance
                // drops to match on its own — no separate hardcoded
                // value, fix14).
                top = topPadding,
                bottom = 140.dp,
            ),
        horizontalAlignment = Alignment.Start,
        // Approved spacing (user 19:58: "عالیه همینو میخوام"),
        // fixed for real in the version-"1" build (user 19:57/21:04):
        // the visible gaps are spacedBy + the items' own vertical
        // padding, and the items used to carry 4dp top + 4dp bottom
        // of their own — so the visible gaps were 13-14dp, not 5dp.
        // Gap budget now (matches the approved preview file):
        //   chips→hero = 10dp, baked into topPadding in MainActivity
        //   (fix13: the measured bar height alone left gap ~0 — the
        //   hero sat jammed under the chips in version "1")
        //   hero→Ping  = spacedBy 5dp + actions-row 5dp = 10dp
        //   Ping→tile  = actions-row 5dp + spacedBy 5dp = 10dp
        //   tile→tile  = spacedBy 5dp alone = 5dp
        // (The 2dp tile gap was tried in a preview and cancelled by
        // the user 2026-11-24: "اینم کنسله همون حالت قبلی خوبه" —
        // back to the approved 5dp.)
        // The hero and tile items carry NO vertical padding — the
        // numbers above are the whole gaps. Do not re-add any.
        verticalArrangement = Arrangement.spacedBy(5.dp, Alignment.Top),
        modifier =
            modifier
                .then(
                    if (uiState.isReorderMode) Modifier
                    else
                        Modifier.pointerInput(Unit) {
                            detectTapGestures {
                                if (uiState.tunnels.isEmpty() && uiState.groups.isEmpty()) {
                                    return@detectTapGestures
                                }
                                viewModel.clearSelectedTunnels()
                            }
                        },
                )
                .overscroll(rememberOverscrollEffect())
                .appScrollbar(
                    state = lazyListState.scrollIndicatorState,
                    orientation = Orientation.Vertical,
                )
                // Report this list's top edge (root coordinates) so
                // MainActivity can measure the top clearance against
                // the bar's bottom edge (two-edge measurement,
                // fix14). Fires on layout and on any position change;
                // the callback only stores a new value when the edge
                // actually moved, so there is no recomposition loop.
                .onGloballyPositioned { coords ->
                    onListTopPx(coords.positionInRoot().y)
                },
        state = lazyListState,
        userScrollEnabled = true,
        reverseLayout = false,
        flingBehavior = ScrollableDefaults.flingBehavior(),
    ) {
        if (uiState.tunnels.isEmpty() && uiState.groups.isEmpty()) {
            item(key = "shuttle-hero") {
                ShuttleHomeHero(
                    activeTunnelName = null,
                    activeState = DisplayTunnelState.Disconnected,
                    configCount = 0,
                    groupCount = 0,
                    hasTunnels = false,
                    statsContent = null,
                    onToggle = {},
                    onImportClick = onImportClick,
                    modifier = Modifier.animateItem(),
                )
            }
            item(key = "shuttle-empty") {
                ShuttleEmptyState(
                    onImportClick = onImportClick,
                    modifier = Modifier.animateItem(),
                )
            }
            return@LazyColumn
        }

        // Search and group chips live in the floating top bar now
        // (user 18:48: the search capsule sits directly under the
        // two top capsules, grouped with them) — they are NOT
        // LazyColumn items any more, so they never scroll away and
        // never sit detached from the capsules.

        if (!uiState.isReorderMode) {
            item(key = "shuttle-actions") {
                Row(
                    modifier =
                        Modifier.fillMaxWidth()
                            // Approved spacing (user 19:58): 5dp
                            // above and below the Ping pill, so the
                            // hero→Ping gap equals the chips→hero gap.
                            .padding(horizontal = 16.dp, vertical = 5.dp)
                            .animateItem(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                ) {
                    // Ping servers alone, centered (Add group moved
                    // up to the filter chips row as a round icon-only
                    // button, user 15:22).
                    ShuttlePingButton(
                        pinged = pingProgress?.pinged,
                        total = pingProgress?.total,
                        onClick = { viewModel.pingTunnels() },
                    )
                }
            }
        }

        itemsIndexed(items = listItems, key = { _, row -> row.key }) { index, row ->
            if (uiState.isReorderMode) {
                ReorderableItem(reorderableLazyListState, row.key) { isDragging ->
                    val latency =
                        (row as? TunnelListRow.TunnelRow)?.let {
                            uiState.reorderLatencies[it.tunnel.id]
                        }
                    val latencyLabel = latency?.let { pingLatencyLabel(it) }
                    val title = buildAnnotatedString {
                        when (row) {
                            is TunnelListRow.GroupHeader -> {
                                // Not pinged as a unit, so there's no latency for a header
                                append(
                                    if (row.childCount == 0) row.group.name
                                    else
                                        stringResource(
                                            R.string.group_with_count,
                                            row.group.name,
                                            row.childCount,
                                        ),
                                )
                            }
                            is TunnelListRow.TunnelRow -> {
                                append(row.tunnel.name)
                                if (latency != null && latencyLabel != null) {
                                    append(" - ")
                                    withStyle(SpanStyle(color = pingLatencyColor(latency))) {
                                        append(latencyLabel)
                                    }
                                }
                            }
                        }
                    }
                    ExpandingRowListItem(
                        leading = {
                            if (row is TunnelListRow.GroupHeader) {
                                Icon(
                                    Icons.Outlined.Folder,
                                    contentDescription = row.group.name,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        },
                        text = title,
                        // Whole row, not just the folder icon, so it's an easy tap target
                        onClick =
                            if (row is TunnelListRow.GroupHeader && row.childCount > 0) {
                                { viewModel.enterReorderScope(row.group.id) }
                            } else {
                                null
                            },
                        trailing = {
                            if (!isTv) {
                                Icon(
                                    Icons.Default.DragHandle,
                                    stringResource(R.string.drag_handle),
                                )
                            } else {
                                Row {
                                    IconButton(
                                        onClick = {
                                            editableRows =
                                                editableRows.toMutableList().apply {
                                                    add(index - 1, removeAt(index))
                                                }
                                            persistRows(editableRows)
                                        },
                                        enabled = index != 0,
                                    ) {
                                        Icon(
                                            Icons.Default.ArrowUpward,
                                            stringResource(R.string.move_up),
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            editableRows =
                                                editableRows.toMutableList().apply {
                                                    add(index + 1, removeAt(index))
                                                }
                                            persistRows(editableRows)
                                        },
                                        enabled = index != listItems.size - 1,
                                    ) {
                                        Icon(
                                            Icons.Default.ArrowDownward,
                                            stringResource(R.string.move_down),
                                        )
                                    }
                                }
                            }
                        },
                        isSelected = isDragging,
                        expanded = {},
                        modifier =
                            if (!isTv)
                                Modifier.draggableHandle(
                                    onDragStarted = {
                                        hapticFeedback.performHapticFeedback(
                                            HapticFeedbackType.GestureThresholdActivate,
                                        )
                                    },
                                    onDragStopped = {
                                        hapticFeedback.performHapticFeedback(
                                            HapticFeedbackType.GestureEnd,
                                        )
                                    },
                                    dragGestureDetector = DragGestureDetector.LongPress,
                                )
                            else Modifier,
                    )
                }
            } else {
                ListRow(
                    row = row,
                    index = index,
                    rowCount = listItems.size,
                    firstTunnelIndex = firstTunnelIndex,
                    lastTunnelIndex = lastTunnelIndex,
                    uiState = uiState,
                    viewModel = viewModel,
                    isTv = isTv,
                    isDragging = false,
                    focusRequester = if (index == 0) focusRequester else null,
                    onNavigateTunnel = { navController.push(Route.TunnelSettings(it)) },
                    onTunnelMenuAction = onTunnelMenuAction,
                    modifier = Modifier.animateItem(),
                )
            }
        }
    }
}

@Composable
private fun ListRow(
    row: TunnelListRow,
    index: Int,
    rowCount: Int,
    firstTunnelIndex: Int,
    lastTunnelIndex: Int,
    uiState: TunnelsUiState,
    viewModel: SharedAppViewModel,
    isTv: Boolean,
    isDragging: Boolean,
    focusRequester: FocusRequester?,
    onNavigateTunnel: (Int) -> Unit,
    onTunnelMenuAction: (TunnelConfig, TunnelMenuAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    when (row) {
        is TunnelListRow.GroupHeader -> {
            ShuttleGroupHeader(
                row = row,
                uiState = uiState,
                selected = isDragging || uiState.selectedGroups.any { it.id == row.group.id },
                onClick = {
                    when {
                        uiState.isReorderMode -> viewModel.enterReorderScope(row.group.id)
                        uiState.isSelectionMode -> viewModel.toggleSelectedGroup(row.group.id)
                        row.childCount > 0 -> viewModel.toggleGroupExpanded(row.group)
                        else -> Unit
                    }
                },
                onLongClick =
                    if (uiState.isReorderMode) null
                    else {
                        { viewModel.toggleSelectedGroup(row.group.id) }
                    },
                modifier =
                    modifier.then(
                        if (focusRequester != null) Modifier.focusRequester(focusRequester)
                        else Modifier,
                    ),
            )
        }
        is TunnelListRow.TunnelRow -> {
            val tunnel = row.tunnel
            val activeTunnel = uiState.backendStatus.activeTunnels[tunnel.id] ?: ActiveTunnel()
            // OpenVPN tunnels are not in the WireGuard backend status:
            // their display state comes from the :openvpn core bridge, and
            // only LEVEL_CONNECTED counts as connected.
            val ovpnActive = tunnel.isOpenVpn && uiState.openVpnActiveId == tunnel.id
            val ovpnState = uiState.openVpnState
            val displayState =
                if (ovpnActive) {
                    when (ovpnState) {
                        is OpenVpnState.Connected -> DisplayTunnelState.Connected
                        is OpenVpnState.Connecting,
                        is OpenVpnState.WaitingForInput ->
                            DisplayTunnelState.EstablishingConnection

                        is OpenVpnState.AuthFailed,
                        is OpenVpnState.Error -> DisplayTunnelState.HandshakeFailure

                        is OpenVpnState.Disconnected -> DisplayTunnelState.Disconnected
                    }
                } else {
                    remember(activeTunnel) { DisplayTunnelState.from(activeTunnel) }
                }
            val isRunning =
                uiState.backendStatus.activeTunnels.containsKey(tunnel.id) || ovpnActive
            val selected =
                remember(uiState.selectedTunnels) {
                    uiState.selectedTunnels.any { it.id == tunnel.id }
                }
            // MORPHED tile (user 2026-11-24): when this config is the
            // active one, its own tile expands (animated) and BECOMES
            // the Connect/hero tile — status + stats + Disconnect live
            // inside it, on the hero gradient. There is no top hero
            // card any more.
            val isHero = isRunning
            val heroStatsContent: (@Composable () -> Unit)? =
                if (isHero && displayState is DisplayTunnelState.Connected) {
                    if (ovpnActive && ovpnState is OpenVpnState.Connected) {
                        { OpenVpnStatisticsRow(ovpnState) }
                    } else {
                        { TunnelStatisticsRow(activeTunnel) }
                    }
                } else {
                    null
                }
            ShuttleTunnelCard(
                tunnel = tunnel,
                displayState = displayState,
                isRunning = isRunning,
                selected = selected || isDragging,
                isFirst = index == firstTunnelIndex,
                isLast = index == lastTunnelIndex,
                description = tunnelRowDescription(tunnel, uiState, isRunning, selected),
                expandedContent =
                    if (isHero) {
                        {
                            ShuttleTunnelHeroContent(
                                displayState = displayState,
                                statsContent = heroStatsContent,
                                onDisconnect = { viewModel.stopTunnel(tunnel) },
                            )
                        }
                    } else {
                        null
                    },
                // Tap the tile itself to connect/disconnect (user
                // 2026-11-24: the per-config Connect button is
                // removed, not needed). Long-press still selects
                // for Pin; the detail/edit screen is reached from
                // the selection sheet's Edit action.
                onClick = {
                    when {
                        uiState.isReorderMode -> Unit
                        uiState.isSelectionMode -> viewModel.toggleSelectedTunnel(tunnel.id)
                        isRunning -> viewModel.stopTunnel(tunnel)
                        else -> viewModel.startTunnel(tunnel)
                    }
                },
                // No long-press (user 2026-11-24: removed) — the
                // per-tile ⋮ menu holds the actions.
                onMenuAction = { action -> onTunnelMenuAction(tunnel, action) },
                // No Connect button (user 2026-11-24: removed, not
                // needed) — only the lime checkmark while connected
                // (same lime #CAFA80 as before), tapping it
                // disconnects. Disconnected rows show nothing here.
                trailing = { rowModifier ->
                    if (displayState is DisplayTunnelState.Connected && !isHero) {
                        Box(
                            modifier =
                                rowModifier
                                    .width(48.dp)
                                    .height(26.dp)
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(LimeConnect)
                                    .clickable(role = Role.Button) {
                                        viewModel.stopTunnel(tunnel)
                                    },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Rounded.Check,
                                contentDescription = stringResource(R.string.ovpn_disconnect),
                                tint = OnLimeConnect,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                },
                modifier = modifier,
            )
        }
    }
}

private fun tunnelRowDescription(
    tunnel: TunnelConfig,
    uiState: TunnelsUiState,
    isRunning: Boolean,
    selected: Boolean,
): (@Composable () -> Unit)? {
    val entryName =
        tunnel.entryTunnelId?.let { id -> uiState.tunnels.firstOrNull { it.id == id }?.name }
    // Last ping: fresh in-memory value first, then the persisted one —
    // the row keeps showing the last measured ping after connecting.
    // A RUNNING tunnel never shows "unreachable" (user 18:48): the
    // in-memory latencies are cleared while a tunnel is active, so
    // the fallback could still be a stale persisted MAX_VALUE from
    // an old ping — but the tunnel IS up, so the stale value is a
    // lie. Suppress it; the hero shows the live stats instead.
    val latency =
        (uiState.pingLatencies[tunnel.id] ?: tunnel.lastPingMs).let {
            if (isRunning && it == Double.MAX_VALUE) null else it
        }
    // Shuttle: the row shows only the config name, protocol/server and
    // (after a ping) its latency — connection info (IP, country, data
    // volume, duration) lives only in the hero card while connected.
    if (entryName == null && latency == null && !tunnel.isOpenVpn) return null
    return {
        // Selected tile is the dark purple #7C74D0, so the secondary
        // lines are light lavender. Light theme: the tile is white,
        // so they are the theme's dark onSurfaceVariant; dark
        // theme: the tile is dark slate, so they stay light blue.
        val secondaryColor =
            when {
                selected -> Color(0xFFD8D5F5)
                isLightShuttleTheme() -> MaterialTheme.colorScheme.onSurfaceVariant
                else -> TileOnNavySecondary
            }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (tunnel.isOpenVpn) {
                Text(
                    text =
                        buildString {
                            append(stringResource(R.string.openvpn))
                            tunnel.ovpnServerLabel?.let { append(" · $it") }
                        },
                    style = MaterialTheme.typography.bodySmall,
                    color = secondaryColor,
                )
            }
            if (entryName != null) {
                Text(
                    text = stringResource(R.string.via_entry, entryName),
                    style = MaterialTheme.typography.bodySmall,
                    color = secondaryColor,
                )
            }
            if (latency != null) {
                PingLatencyText(latency)
            }
        }
    }
}

@Composable
private fun PingLatencyText(latency: Double) {
    Text(
        text = pingLatencyLabel(latency),
        style = MaterialTheme.typography.bodySmall,
        color = pingLatencyColor(latency),
    )
}

@Composable
private fun pingLatencyLabel(latency: Double): String {
    return if (latency == Double.MAX_VALUE) stringResource(R.string.ping_unreachable)
    else "${latency.toInt()}ms"
}

@Composable
private fun pingLatencyColor(latency: Double): Color {
    // Dark theme: light green/amber/red on the navy tile. Light
    // theme: dark green/amber/red on the pale-lavender tile (the
    // dark-theme colours are unreadable on pale lavender).
    val isLight = isLightShuttleTheme()
    return when {
        latency == Double.MAX_VALUE -> if (isLight) PingRedDark else AlertRed
        // Colour-coded by value: green below 100ms, orange 100–300ms,
        // red above 300ms. Unreachable reads as red too.
        latency < 100.0 -> if (isLight) PingGreenDark else SilverTree
        latency <= 300.0 -> if (isLight) PingAmberDark else OrionAmber
        else -> if (isLight) PingRedDark else AlertRed
    }
}
