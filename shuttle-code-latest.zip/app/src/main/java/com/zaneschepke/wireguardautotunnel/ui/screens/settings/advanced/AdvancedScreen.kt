package com.zaneschepke.wireguardautotunnel.ui.screens.settings.advanced

import android.os.Build
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.CallSplit
import androidx.compose.material.icons.outlined.HdrAuto
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.rememberRestartToApplyChanges
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.common.text.ScreenSection
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.splittunnel.components.splitAppsLabel
import com.zaneschepke.wireguardautotunnel.ui.state.splitAppListSummary
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.viewmodel.SettingsViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.koin.compose.viewmodel.koinViewModel
import org.orbitmvi.orbit.compose.collectAsState

@Composable
fun AdvancedScreen(
    viewModel: SettingsViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val navController = LocalNavController.current
    val sharedUiState by sharedViewModel.collectAsState()
    val uiState by viewModel.collectAsState()
    if (uiState.isLoading) return

    val strictSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    val strictApplies = sharedUiState.tunnelMode == TunnelMode.VPN
    val proxyDisabled = sharedUiState.tunnelMode == TunnelMode.PROXY
    val vpnActive = uiState.tunnelActive && strictApplies
    var pendingStrict by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var pendingGlobalSplit by rememberSaveable { mutableStateOf<Boolean?>(null) }
    val applyStrict =
        rememberRestartToApplyChanges(needsRestart = vpnActive) { restart ->
            pendingStrict?.let { viewModel.setStrictSplitTunnel(it, restart) }
            pendingStrict = null
        }
    val applyGlobalSplit =
        rememberRestartToApplyChanges(needsRestart = vpnActive) { restart ->
            pendingGlobalSplit?.let { viewModel.setGlobalSplitTunneling(it, restart) }
            pendingGlobalSplit = null
        }

    val globalQuickConfig = uiState.globalTunnelConfig?.quickConfig
    val globalSummary =
        remember(globalQuickConfig) {
            val iface = uiState.globalTunnelConfig?.getConfig()?.`interface`
            splitAppListSummary(
                includedCount = iface?.allIncludedApps?.size ?: 0,
                excludedCount = iface?.allExcludedApps?.size ?: 0,
                emptyMeansAllTunneled = true,
            )
        }

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(AdvancedSection.PRIVACY.title))
            ShuttleSettingsCard {
                if (strictSupported) {
                    SurfaceRow(
                        leading = { ShuttleSettingIcon(Icons.Outlined.Shield) },
                        enabled = strictApplies,
                        title = stringResource(R.string.strict_split_tunnel),
                        trailing = { modifier ->
                            SwitchWithDivider(
                                checked = uiState.settings.strictSplitTunnelEnabled,
                                onClick = {
                                    pendingStrict = it
                                    applyStrict()
                                },
                                enabled = strictApplies,
                                modifier = modifier,
                                checkedTrackColor = LimeConnect,
                                // No page behind this row — it only
                                // flips the switch (user 2026-11-25).
                                showChevron = false,
                            )
                        },
                        description = {
                            DescriptionText(
                                if (strictApplies) {
                                    stringResource(R.string.strict_split_tunnel_desc) +
                                        " • " + stringResource(R.string.wireguard_only)
                                } else {
                                    stringResource(R.string.unavailable_in_mode)
                                },
                                disabled = !strictApplies,
                            )
                        },
                        onClick = {
                            pendingStrict = !uiState.settings.strictSplitTunnelEnabled
                            applyStrict()
                        },
                        containerColor = Color.Transparent,
                    )
                    ShuttleSettingsDivider()
                }
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.HdrAuto) },
                    title = stringResource(R.string.amnezia_for_all_tunnels),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.settings.isGlobalAmneziaEnabled,
                            onClick = { viewModel.setGlobalAmneziaEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    description = {
                        DescriptionText(
                            stringResource(R.string.amnezia_for_all_tunnels_desc) +
                                " • " + stringResource(R.string.wireguard_only),
                        )
                    },
                    onClick = { navController.push(Route.GlobalAmnezia) },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(AdvancedSection.SPLIT_TUNNELING.title))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.AutoMirrored.Outlined.CallSplit) },
                    enabled = !proxyDisabled,
                    title = stringResource(R.string.split_tunneling_for_all_tunnels),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.settings.isGlobalSplitTunnelEnabled,
                            onClick = {
                                pendingGlobalSplit = it
                                applyGlobalSplit()
                            },
                            modifier = modifier,
                            enabled = !proxyDisabled,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    description = {
                        if (proxyDisabled) {
                            DescriptionText(
                                stringResource(R.string.unavailable_in_mode),
                                disabled = true,
                            )
                        } else {
                            DescriptionText(
                                stringResource(R.string.split_tunneling_for_all_tunnels_desc) +
                                    " • " + stringResource(R.string.wireguard_only),
                            )
                            if (uiState.settings.isGlobalSplitTunnelEnabled) {
                                globalSummary?.let { DescriptionText(splitAppsLabel(it)) }
                            }
                        }
                    },
                    onClick = {
                        uiState.globalTunnelConfig?.let {
                            navController.push(Route.SplitTunnelGlobal(id = it.id))
                        }
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(AdvancedSection.SCRIPTS.title))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Terminal) },
                    title = stringResource(R.string.tunnel_scripting),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.settings.tunnelScriptingEnabled,
                            onClick = { viewModel.setTunnelScriptedEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = {
                        DescriptionText(
                            stringResource(R.string.root_required_template, "").trim() +
                                " • " + stringResource(R.string.wireguard_only),
                        )
                    },
                    onClick = {
                        viewModel.setTunnelScriptedEnabled(!uiState.settings.tunnelScriptingEnabled)
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
    }
}

/** Sections of the Advanced screen, in the order they appear. */
enum class AdvancedSection(@StringRes override val title: Int) : ScreenSection {
    PRIVACY(R.string.privacy_and_censorship),
    SPLIT_TUNNELING(R.string.split_tunneling),
    SCRIPTS(R.string.scripts),
}
