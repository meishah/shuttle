package com.zaneschepke.wireguardautotunnel.ui.common.button

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import com.zaneschepke.wireguardautotunnel.ui.theme.Disabled
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.SwitchTrackLight

@Composable
fun ThemedSwitch(
    checked: Boolean,
    onClick: (checked: Boolean) -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    // Shuttle: lime track while on (matches the Connect button /
    // checkmark accent). Defaults to the theme primary.
    checkedTrackColor: androidx.compose.ui.graphics.Color =
        MaterialTheme.colorScheme.primary,
) {
    // Light theme only (user 2026-11-27): the lime track is too pale
    // on the light background, so it is remapped to the deeper lime
    // #A3E635 there. Dark theme keeps #CAFA80. Any other track colour
    // (e.g. the default primary) passes through unchanged.
    val isLight = MaterialTheme.colorScheme.surface.luminance() > 0.5f
    val effectiveTrackColor =
        if (isLight && checkedTrackColor == LimeConnect) SwitchTrackLight
        else checkedTrackColor
    Switch(
        checked,
        { onClick(it) },
        modifier = modifier,
        enabled = enabled,
        colors =
            SwitchDefaults.colors()
                .copy(
                    checkedTrackColor = effectiveTrackColor,
                    checkedThumbColor = MaterialTheme.colorScheme.surface,
                    checkedIconColor = MaterialTheme.colorScheme.surface,
                    uncheckedTrackColor = MaterialTheme.colorScheme.surface,
                    uncheckedBorderColor = MaterialTheme.colorScheme.outline,
                    uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                    uncheckedIconColor = MaterialTheme.colorScheme.outline,
                    disabledUncheckedBorderColor = Disabled,
                    disabledUncheckedThumbColor = Disabled,
                    disabledUncheckedIconColor = Disabled,
                ),
    )
}
