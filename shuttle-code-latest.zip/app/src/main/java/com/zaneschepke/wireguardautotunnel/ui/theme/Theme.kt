package com.zaneschepke.wireguardautotunnel.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.RippleConfiguration
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV

import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV

/**
 * Orion Store palette (from the user's own screenshots of Orion):
 * near-black background, lavender / periwinkle primary for pills,
 * highlights and selected states, dark card-on-dark layering. Teal is
 * only a small success accent, never the main colour.
 */
private val DarkColorScheme =
    darkColorScheme(
        primary = OrionLavender,
        onPrimary = Color(0xFF211D47),
        primaryContainer = OrionLavenderContainer,
        onPrimaryContainer = Color(0xFFDDD9FB),
        secondary = Color(0xFFC9C4EE),
        onSecondary = Color(0xFF2A2745),
        secondaryContainer = Color(0xFF35334E),
        onSecondaryContainer = Color(0xFFDDD9F6),
        tertiary = OrionTeal,
        onTertiary = Color(0xFF003731),
        tertiaryContainer = Color(0xFF1F4A44),
        onTertiaryContainer = Color(0xFF9FE8DB),
        error = Color(0xFFFFB4AB),
        onError = Color(0xFF690005),
        errorContainer = Color(0xFF5A1A15),
        onErrorContainer = Color(0xFFFFDAD6),
        // Dark is the LIGHTEST dark theme: its background/surface are a
        // step lighter than Darker's near-black, so the two are visibly
        // distinct. Order: Dark (lightest) > Darker > AMOLED (pure black).
        background = Color(0xFF17171D),
        onBackground = Color(0xFFE9E9EF),
        surface = Color(0xFF17171D),
        onSurface = Color(0xFFE9E9EF),
        surfaceVariant = Color(0xFF3E3D4A),
        // Secondary/small text must stay readable on dark backgrounds:
        // outline (used by DescriptionText and other secondary text) and
        // onSurfaceVariant were far too dark (0xFF43434F / 0xFFA4A4B2).
        onSurfaceVariant = Color(0xFFC2C2CE),
        surfaceDim = Color(0xFF17171D),
        surfaceBright = Color(0xFF2E2E38),
        surfaceContainerLowest = Color(0xFF101014),
        surfaceContainerLow = Color(0xFF1D1D24),
        surfaceContainer = Color(0xFF22222A),
        surfaceContainerHigh = Color(0xFF2C2C36),
        surfaceContainerHighest = Color(0xFF383844),
        outline = Color(0xFF8A8A99),
        outlineVariant = Color(0xFF3A3A46),
        inverseSurface = Color(0xFFE9E9EF),
        inverseOnSurface = OrionSurface,
        inversePrimary = OrionLavenderDeep,
        scrim = Color.Black,
    )

private val LightColorScheme =
    lightColorScheme(
        primary = OrionLavenderDeep,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE3DFFF),
        onPrimaryContainer = Color(0xFF241B5E),
        secondary = Color(0xFF6A64B8),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFE7E4FA),
        onSecondaryContainer = Color(0xFF2A2745),
        tertiary = Color(0xFF2E7D72),
        onTertiary = Color.White,
        tertiaryContainer = Color(0xFFB9E8DD),
        onTertiaryContainer = Color(0xFF08332D),
        error = Color(0xFFBA1A1A),
        onError = Color.White,
        errorContainer = Color(0xFFFFDAD6),
        onErrorContainer = Color(0xFF410002),
        background = Color(0xFFEFEFEF),
        onBackground = Color(0xFF1A1A21),
        surface = Color.White,
        onSurface = Color(0xFF1A1A21),
        surfaceVariant = Color(0xFFE4E4EC),
        onSurfaceVariant = Color(0xFF5C5C68),
        surfaceDim = Color(0xFFDCDCE4),
        surfaceBright = Color.White,
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color(0xFFF2F2F7),
        surfaceContainer = Color(0xFFECECF2),
        surfaceContainerHigh = Color(0xFFD8D8D8),
        surfaceContainerHighest = Color(0xFFDBDBE4),
        outline = Color(0xFF7C7C8A),
        outlineVariant = Color(0xFFC9C9D4),
        inverseSurface = Color(0xFF2C2C36),
        inverseOnSurface = Color(0xFFF4F4F8),
        inversePrimary = OrionLavender,
        scrim = Color.Black,
    )

enum class Theme {
    AUTOMATIC,
    LIGHT,
    DARK,
    DARKER,
    AMOLED,
    DYNAMIC,
    AMOLED_DYNAMIC,
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun WireguardAutoTunnelTheme(theme: Theme = Theme.AUTOMATIC, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val isTv = LocalIsAndroidTV.current
    var isDark = isSystemInDarkTheme()
    val autoTheme = if (isDark) DarkColorScheme else LightColorScheme
    val colorScheme =
        when (theme) {
            Theme.AUTOMATIC -> autoTheme
            Theme.DARK -> {
                isDark = true
                DarkColorScheme
            }
            Theme.DARKER -> {
                isDark = true
                // Darker keeps the old near-black Orion look (0xFF0D0D11):
                // visibly darker than the lightened Dark, visibly lighter
                // than AMOLED's pure black.
                DarkColorScheme.copy(
                    background = OrionBackground,
                    surface = OrionBackground,
                    surfaceVariant = Color(0xFF35343F),
                    surfaceDim = OrionBackground,
                    surfaceBright = Color(0xFF26262E),
                    surfaceContainerLowest = Color(0xFF08080B),
                    surfaceContainerLow = Color(0xFF131318),
                    surfaceContainer = OrionSurface,
                    surfaceContainerHigh = Color(0xFF22222A),
                    surfaceContainerHighest = Color(0xFF2C2C36),
                    outlineVariant = Color(0xFF2B2B34),
                )
            }
            Theme.AMOLED -> {
                isDark = true
                // Pure black background/surface; containers near-black so
                // cards stay visible, but clearly darker than Darker's.
                // Outline stays bright so secondary text remains readable.
                DarkColorScheme.copy(
                    surface = Color.Black,
                    background = Color.Black,
                    primary = OrionLavender,
                    surfaceVariant = Color(0xFF1C1C21),
                    surfaceDim = Color.Black,
                    surfaceBright = Color(0xFF0E0E11),
                    surfaceContainerLowest = Color.Black,
                    surfaceContainerLow = Color(0xFF060608),
                    surfaceContainer = Color(0xFF0C0C0F),
                    surfaceContainerHigh = Color(0xFF121215),
                    surfaceContainerHighest = Color(0xFF18181C),
                    outlineVariant = Color(0xFF1A1A1F),
                )
            }
            Theme.LIGHT -> {
                isDark = false
                LightColorScheme
            }
            Theme.DYNAMIC -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (isDark) {
                        dynamicDarkColorScheme(context)
                    } else {
                        dynamicLightColorScheme(context)
                    }
                } else {
                    autoTheme
                }
            }
            Theme.AMOLED_DYNAMIC -> {
                isDark = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    dynamicDarkColorScheme(context)
                        .copy(
                            surface = Color.Black,
                            background = Color.Black,
                        )
                } else {
                    DarkColorScheme.copy(
                        surface = Color.Black,
                        background = Color.Black,
                        primary = OrionLavender,
                    )
                }
            }
        }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.setDecorFitsSystemWindows(window, false)
            // For API 33+, use WindowInsetsControllerCompat for appearance control
            val insetsController = WindowInsetsControllerCompat(window, window.decorView)
            insetsController.isAppearanceLightStatusBars = !isDark
            insetsController.isAppearanceLightNavigationBars = !isDark
        }
    }

    val rippleConfig =
        RippleConfiguration(
            color = colorScheme.primary,
            rippleAlpha =
                if (isTv)
                    RippleAlpha(
                        pressedAlpha = 0.5f,
                        focusedAlpha = 0.4f,
                        draggedAlpha = 0.2f,
                        hoveredAlpha = 0.4f,
                    )
                else
                    RippleAlpha(
                        pressedAlpha = 0.2f,
                        focusedAlpha = 0.1f,
                        draggedAlpha = 0.2f,
                        hoveredAlpha = 0.1f,
                    ),
        )

    CompositionLocalProvider(LocalRippleConfiguration provides rippleConfig) {
        // Material 3 Expressive (Orion Store look): spring motion via the
        // expressive MotionScheme, emphasized typography, Material You dynamic
        // colour kept as the default where the palette supports it.
        // NOTE: the app has no "disable animations" setting, so there is no
        // snap-everything MotionScheme here — expressive motion is always on.
        MaterialExpressiveTheme(
            colorScheme = colorScheme,
            motionScheme = MotionScheme.expressive(),
            typography = Typography,
            content = content,
        )
    }
}
