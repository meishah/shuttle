package com.zaneschepke.wireguardautotunnel.notification

data class TunnelNotificationOptions(
    // Shuttle change #7: the notification always shows total data
    // volume (حجم مصرفی) and the connection duration as a "Duration:"
    // line in the expanded view — never live speed — so both are on
    // by default. (The stored settings are stale/hidden in Shuttle's
    // simplified Settings; AppProvider.notificationPrefs also forces
    // both on.) The header has no chronometer and no timestamp.
    val liveUpdatesEnabled: Boolean = true,
    val showOrigin: Boolean = false,
    val showTransfer: Boolean = true,
    val showRecovery: Boolean = false,
    val showFailureTint: Boolean = false,
)
