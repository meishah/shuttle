package com.zaneschepke.wireguardautotunnel.util.extensions

import android.content.Context
import android.icu.text.MeasureFormat
import android.icu.util.Measure
import android.icu.util.MeasureUnit
import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.CallSplit
import androidx.compose.material.icons.automirrored.outlined.Forward
import androidx.compose.material.icons.outlined.Balance
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.Https
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.NoEncryption
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.VpnKey
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import com.wgtunnel.backend.model.BackendMode
import com.wgtunnel.backend.model.dns.DnsValidationError
import com.wgtunnel.backend.state.ActiveTunnel
import com.zaneschepke.networkmonitor.AndroidNetworkMonitor
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.BootstrapDnsProtocol
import com.zaneschepke.wireguardautotunnel.domain.enums.ForeignDnsPolicy
import com.zaneschepke.wireguardautotunnel.domain.enums.SplitDnsSuffixTarget
import com.zaneschepke.wireguardautotunnel.domain.enums.StatisticRefresh
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelDnsMode
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelDnsProtocol
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.domain.enums.WifiDetectionMethod
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup
import com.zaneschepke.wireguardautotunnel.ui.state.DisplayTunnelState
import com.zaneschepke.wireguardautotunnel.util.FileUtils
import java.time.Instant
import java.util.Locale
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

fun WifiDetectionMethod.asTitleString(context: Context): String {
    return when (this) {
        WifiDetectionMethod.DEFAULT -> context.getString(R.string._default)
        WifiDetectionMethod.LEGACY -> context.getString(R.string.legacy)
        WifiDetectionMethod.ROOT -> context.getString(R.string.root)
        WifiDetectionMethod.SHIZUKU -> context.getString(R.string.shizuku)
    }
}

fun WifiDetectionMethod.to(): AndroidNetworkMonitor.WifiDetectionMethod {
    return when (this) {
        WifiDetectionMethod.DEFAULT -> AndroidNetworkMonitor.WifiDetectionMethod.DEFAULT
        WifiDetectionMethod.LEGACY -> AndroidNetworkMonitor.WifiDetectionMethod.LEGACY
        WifiDetectionMethod.ROOT -> AndroidNetworkMonitor.WifiDetectionMethod.ROOT
        WifiDetectionMethod.SHIZUKU -> AndroidNetworkMonitor.WifiDetectionMethod.SHIZUKU
    }
}

fun WifiDetectionMethod.asDescriptionString(context: Context): String? {
    return when (this) {
        WifiDetectionMethod.LEGACY -> context.getString(R.string.legacy_api_description)
        WifiDetectionMethod.ROOT -> context.getString(R.string.use_root_shell_for_wifi)
        WifiDetectionMethod.SHIZUKU -> context.getString(R.string.use_shell_via_shizuku)
        WifiDetectionMethod.DEFAULT -> context.getString(R.string.use_android_recommended)
    }
}

fun TunnelMode.asTitleString(context: Context): String {
    return when (this) {
        TunnelMode.VPN -> asString(context)
        TunnelMode.PROXY -> asString(context)
        TunnelMode.LOCK_DOWN -> asString(context)
    }
}

fun TunnelMode.asString(context: Context): String {
    return when (this) {
        TunnelMode.VPN -> context.getString(R.string.vpn)
        TunnelMode.PROXY -> context.getString(R.string.local_proxy)
        TunnelMode.LOCK_DOWN -> context.getString(R.string.lockdown)
    }
}

@Composable
fun TunnelMode.asIcon(): ImageVector {
    return when (this) {
        TunnelMode.VPN -> Icons.Outlined.VpnKey
        TunnelMode.PROXY -> ImageVector.vectorResource(R.drawable.proxy)
        TunnelMode.LOCK_DOWN -> Icons.Outlined.Lock
    }
}

@Composable
fun TunnelDnsMode.asIcon(): ImageVector {
    return when (this) {
        TunnelDnsMode.Off -> Icons.Outlined.NoEncryption
        TunnelDnsMode.Encrypted -> Icons.Outlined.EnhancedEncryption
        TunnelDnsMode.Split -> Icons.AutoMirrored.Outlined.CallSplit
        TunnelDnsMode.AllLocal -> Icons.Outlined.Wifi
    }
}

fun BootstrapDnsProtocol.asIcon(): ImageVector {
    return when (this) {
        BootstrapDnsProtocol.SYSTEM -> Icons.Outlined.PhoneAndroid
        BootstrapDnsProtocol.DOH -> Icons.Outlined.Https
        BootstrapDnsProtocol.DOT -> Icons.Outlined.EnhancedEncryption
        BootstrapDnsProtocol.UDP -> Icons.Outlined.NoEncryption
    }
}

fun TunnelDnsProtocol.asIcon(): ImageVector {
    return when (this) {
        TunnelDnsProtocol.Doh -> Icons.Outlined.Https
        TunnelDnsProtocol.Dot -> Icons.Outlined.EnhancedEncryption
        TunnelDnsProtocol.Plain -> Icons.Outlined.NoEncryption
    }
}

fun ForeignDnsPolicy.asIcon(): ImageVector {
    return when (this) {
        ForeignDnsPolicy.Redirect -> Icons.AutoMirrored.Outlined.Forward
        ForeignDnsPolicy.Block -> Icons.Outlined.Block
        ForeignDnsPolicy.Allow -> Icons.Outlined.LockOpen
    }
}

fun SplitDnsSuffixTarget.asIcon(): ImageVector {
    return when (this) {
        SplitDnsSuffixTarget.System -> Icons.Outlined.PhoneAndroid
        SplitDnsSuffixTarget.Tunnel -> Icons.Outlined.VpnKey
    }
}

fun StatisticRefresh.asIcon(): ImageVector {
    return when (this) {
        StatisticRefresh.LIVE -> Icons.Outlined.Bolt
        StatisticRefresh.BALANCED -> Icons.Outlined.Balance
        StatisticRefresh.BATTERY_SAVER -> Icons.Outlined.BatterySaver
    }
}

fun Duration.localized(locale: Locale = Locale.getDefault()): String {
    require(this >= Duration.ZERO) { "Duration cannot be negative" }

    if (this < 1.seconds) {
        return MeasureFormat.getInstance(locale, MeasureFormat.FormatWidth.SHORT)
            .format(Measure(0, MeasureUnit.SECOND))
    }

    val measures = buildList {
        if (inWholeDays > 0) add(Measure(inWholeDays, MeasureUnit.DAY))
        if (inWholeHours % 24 > 0) add(Measure(inWholeHours % 24, MeasureUnit.HOUR))
        if (inWholeMinutes % 60 > 0) add(Measure(inWholeMinutes % 60, MeasureUnit.MINUTE))
        if (inWholeSeconds % 60 > 0) add(Measure(inWholeSeconds % 60, MeasureUnit.SECOND))
    }

    return MeasureFormat.getInstance(locale, MeasureFormat.FormatWidth.SHORT)
        .formatMeasures(*measures.toTypedArray())
}

fun Long?.toAgoDisplay(currentTimeMillis: Long = System.currentTimeMillis()): String? {
    val timestamp = this ?: return null
    if (timestamp <= 0L) return null

    val nowSeconds = currentTimeMillis / 1000
    val secondsAgo = (nowSeconds - timestamp).coerceAtLeast(0L)

    return secondsAgo.seconds.localized()
}

fun Long.toUptimeDisplay(currentTimeMillis: Long = System.currentTimeMillis()): String {
    val elapsedMillis = (currentTimeMillis - this).coerceAtLeast(0L)
    return elapsedMillis.milliseconds.localized()
}

@StringRes
fun DnsValidationError.labelRes(): Int {
    return when (this) {
        DnsValidationError.Empty -> R.string.dns_error_empty
        DnsValidationError.InvalidUrl -> R.string.dns_error_invalid_url
        DnsValidationError.InvalidScheme -> R.string.dns_error_invalid_scheme
        DnsValidationError.InvalidHost -> R.string.dns_error_invalid_host
        DnsValidationError.InvalidPort -> R.string.dns_error_invalid_port
        DnsValidationError.InvalidIpOrHost -> R.string.dns_error_invalid_ip_or_host
    }
}

fun ActiveTunnel.statusText(context: Context): String {
    return context.getString(
        R.string.status_template,
        DisplayTunnelState.from(this).asLocalizedString(context),
    )
}

fun ActiveTunnel.uptimeText(context: Context, now: Long): String? {

    val startedAt = uptime ?: return null

    val uptimeDisplay = startedAt.toUptimeDisplay(now)

    return context.getString(R.string.uptime_template, uptimeDisplay)
}

fun ActiveTunnel.proxyStatusTexts(context: Context): List<String> {
    val proxyConfig = (mode as? BackendMode.Proxy.Standard)?.proxyConfig ?: return emptyList()
    return buildList {
        proxyConfig.socks5?.let { socks5 ->
            val protected = !socks5.username.isNullOrBlank() || !socks5.password.isNullOrBlank()
            add(
                context.getString(
                    if (protected) R.string.socks5_proxy_protected_template
                    else R.string.socks5_proxy_template,
                    "${socks5.host}:${socks5.port}",
                ),
            )
        }
        proxyConfig.http?.let { http ->
            val protected = !http.username.isNullOrBlank() || !http.password.isNullOrBlank()
            add(
                context.getString(
                    if (protected) R.string.http_proxy_protected_template
                    else R.string.http_proxy_template,
                    "${http.host}:${http.port}",
                ),
            )
        }
    }
}

fun List<TunnelConfig>.asFileExportName(): Pair<String, String> {
    return if (size == 1) {
        val tunnel = first()
        val extension =
            if (tunnel.isOpenVpn) FileUtils.OVPN_FILE_EXTENSION
            else ".conf"
        "${tunnel.name}$extension" to FileUtils.ALL_FILE_TYPES
    } else {
        "wgtunnel_export_${Instant.now().toUserFriendlyTimestamp()}.zip" to
            FileUtils.ZIP_FILE_MIME_TYPE
    }
}

// Always a zip, even with a single tunnel inside, and named for the group rather than the tunnel
fun TunnelGroup.asExportFileName(): Pair<String, String> =
    "$name.zip" to FileUtils.ZIP_FILE_MIME_TYPE
