package com.zaneschepke.wireguardautotunnel.ui.common.functions

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.delay

/**
 * Wall-clock "now" that ticks only while the screen is actually showing the app
 * (lifecycle STARTED). A plain produceState/LaunchedEffect loop keeps waking the
 * main thread every second even after the app is backgrounded or the screen is
 * off, as long as the Activity is still alive — a steady battery drain while a
 * VPN is connected. This pauses the loop when the app is not visible and
 * refreshes the value immediately when it becomes visible again.
 */
@Composable
fun rememberTickingNow(enabled: Boolean = true, period: Duration = 1.seconds): State<Long> {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    return produceState(System.currentTimeMillis(), enabled, lifecycle, period) {
        if (!enabled) return@produceState
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            value = System.currentTimeMillis()
            while (true) {
                delay(period)
                value = System.currentTimeMillis()
            }
        }
    }
}
