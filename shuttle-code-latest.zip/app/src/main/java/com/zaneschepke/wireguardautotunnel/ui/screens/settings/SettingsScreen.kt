package com.zaneschepke.wireguardautotunnel.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ViewQuilt
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.SettingsBackupRestore
import androidx.compose.material.icons.outlined.ViewHeadline
import androidx.compose.material.icons.outlined.VpnLock
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.unit.dp
import com.dokar.sonner.ToastType
import com.zaneschepke.wireguardautotunnel.MainActivity
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.ui.LocalIsAndroidTV
import com.zaneschepke.wireguardautotunnel.ui.LocalNavController
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.functions.rememberFileImportLauncherForResult
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.navigation.Route
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.components.BackupBottomSheet
import com.zaneschepke.wireguardautotunnel.ui.screens.settings.components.BackupEncryptionDialog
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.capitalize
import com.zaneschepke.wireguardautotunnel.viewmodel.SettingsViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState

/**
 * Shuttle's Settings: only what the user asked for.
 *
 * Kept: appearance (themes) + language, kill switch, auto-connect
 * (start on boot), per-app selection, connection log, backup/export,
 * widget & Quick Settings tile info, about. Everything else WG Tunnel
 * ships (backend/proxy mode, DNS, monitoring & recovery, advanced,
 * security/app lock, Android integrations, scripts, remote control…)
 * is hidden from the UI — the navigation entries are removed here, the
 * underlying engine code is untouched.
 */
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {
    val context = LocalContext.current
    val navController = LocalNavController.current
    val isTv = LocalIsAndroidTV.current

    val locale = Locale.current.platformLocale

    val uiState by viewModel.collectAsState()

    if (uiState.isLoading) return

    var showBackupSheet by remember { mutableStateOf(false) }
    var showEncryptionDialog by remember { mutableStateOf(false) }
    var isRestoreAction by remember { mutableStateOf(false) }
    var pendingRestorePassword by remember { mutableStateOf<String?>(null) }
    val launchTvRestore =
        rememberFileImportLauncherForResult(
            onNoFileExplorer = {
                sharedViewModel.showSnackMessage(
                    StringValue.StringResource(R.string.error_no_file_explorer),
                    ToastType.Error,
                )
            },
            onData = { uri ->
                (context as? MainActivity)?.restoreFromUri(uri, pendingRestorePassword)
                pendingRestorePassword = null
            },
            onCancel = {
                pendingRestorePassword = null
                sharedViewModel.showSnackMessage(
                    StringValue.StringResource(R.string.restore_failed),
                    ToastType.Error,
                )
            },
        )

    if (showBackupSheet) {
        BackupBottomSheet(
            onBackup = {
                showBackupSheet = false
                isRestoreAction = false
                showEncryptionDialog = true
            },
            onRestore = {
                showBackupSheet = false
                isRestoreAction = true
                showEncryptionDialog = true
            },
            onDismiss = { showBackupSheet = false },
        )
    }

    if (showEncryptionDialog) {
        BackupEncryptionDialog(
            isRestore = isRestoreAction,
            onConfirm = { _, password ->
                showEncryptionDialog = false
                val activity = context as? MainActivity ?: return@BackupEncryptionDialog
                if (isRestoreAction) {
                    if (isTv) {
                        pendingRestorePassword = password
                        launchTvRestore()
                    } else {
                        activity.beginRestore(password)
                    }
                } else {
                    activity.beginBackup(password)
                }
            },
            onDismiss = { showEncryptionDialog = false },
        )
    }

    val appMode = uiState.settings.tunnelMode
    val killSwitchOn = appMode == TunnelMode.LOCK_DOWN
    val isAlwaysOnEnabled = uiState.settings.isAlwaysOnVpnEnabled
    // Split tunneling is unavailable in proxy mode (kept from the
    // original Advanced screen); Shuttle never offers proxy mode.
    val proxyDisabled = appMode == TunnelMode.PROXY

    // Shuttle (user 2026-11-24, approved preview): settings are
    // grouped into big rounded cards by topic — Appearance,
    // Connection, Privacy, Backup & system — with a tinted squircle
    // behind every row icon and lime switches while on. The rows and
    // their actions are unchanged; only the grouping and styling are
    // new.
    // Floating bars like home (user 2026-11-24 22:13): the content
    // scrolls beneath the frosted top bar and bottom nav and fades
    // gradually at both edges. Top clearance = the floating bar
    // (20dp banner pad + 64dp TopAppBar) + the approved 10dp gap,
    // bottom clearance = 140dp, exactly like home's list — so no
    // row is ever hidden under either bar.
    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.verticalScroll(rememberScrollState())
                .fillMaxSize()
                .statusBarsPadding()
                // Top 70dp (was 94dp): the overlay bar now starts at y=0
                // (no statusBarsPadding — its scrim must cover the status
                // bar strip, user 2026-11-24 23:56), so 70 + status bar
                // (~24dp) = 94dp keeps the 10dp gap under the 84dp bar.
                .padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.appearance))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(Icons.AutoMirrored.Outlined.ViewQuilt)
                    },
                    title = stringResource(R.string.appearance),
                    onClick = { navController.push(Route.Appearance) },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.settings_group_connection))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.VpnLock) },
                    title = stringResource(R.string.kill_switch).capitalize(locale),
                    description = { DescriptionText(stringResource(R.string.lockdown_desc)) },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = killSwitchOn,
                            onClick = {
                                sharedViewModel.setAppMode(
                                    if (it) TunnelMode.LOCK_DOWN else TunnelMode.VPN,
                                )
                            },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    onClick = {
                        sharedViewModel.setAppMode(
                            if (killSwitchOn) TunnelMode.VPN else TunnelMode.LOCK_DOWN,
                        )
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Restore) },
                    title = stringResource(R.string.restart_at_boot),
                    description = {
                        DescriptionText(stringResource(R.string.tunnel_boot_description))
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.settings.isRestoreOnBootEnabled,
                            onClick = { viewModel.setRestoreOnBootEnabled(it) },
                            enabled = !isAlwaysOnEnabled,
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    enabled = !isAlwaysOnEnabled,
                    onClick = {
                        viewModel.setRestoreOnBootEnabled(
                            !uiState.settings.isRestoreOnBootEnabled,
                        )
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.settings_group_privacy))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Apps) },
                    title = stringResource(R.string.split_tunneling_for_all_tunnels),
                    description = {
                        DescriptionText(
                            stringResource(R.string.split_tunneling_for_all_tunnels_desc),
                        )
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.settings.isGlobalSplitTunnelEnabled,
                            onClick = { viewModel.setGlobalSplitTunneling(it) },
                            enabled = !proxyDisabled,
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    enabled = !proxyDisabled,
                    onClick = {
                        uiState.globalTunnelConfig?.let {
                            navController.push(Route.SplitTunnelGlobal(id = it.id))
                        }
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.ViewHeadline) },
                    title = stringResource(R.string.local_logging),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.monitoring.isLocalLogsEnabled,
                            onClick = { viewModel.setLocalLogging(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    description = {
                        DescriptionText(stringResource(R.string.local_logging_desc))
                    },
                    onClick = { navController.push(Route.Logs) },
                    containerColor = Color.Transparent,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.settings_group_backup_system))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(Icons.Outlined.SettingsBackupRestore)
                    },
                    title = stringResource(R.string.backup_and_restore),
                    onClick = { showBackupSheet = true },
                    trailing = { modifier ->
                        IconButton(modifier = modifier, onClick = { showBackupSheet = true }) {
                            Icon(
                                Icons.Outlined.ExpandMore,
                                contentDescription = stringResource(R.string.select),
                            )
                        }
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Widgets) },
                    title = stringResource(R.string.shuttle_widget_tile_title),
                    description = {
                        DescriptionText(stringResource(R.string.shuttle_widget_tile_desc))
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
        ShuttleSettingsCard {
            SurfaceRow(
                leading = { ShuttleSettingIcon(Icons.Outlined.Info) },
                title = stringResource(R.string.about),
                onClick = { navController.push(Route.Support) },
                containerColor = Color.Transparent,
            )
        }
    }
}
