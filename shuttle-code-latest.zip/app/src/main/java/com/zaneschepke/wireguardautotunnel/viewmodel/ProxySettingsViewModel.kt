package com.zaneschepke.wireguardautotunnel.viewmodel

import androidx.lifecycle.ViewModel
import com.dokar.sonner.ToastType
import com.wgtunnel.backend.model.isValidProxyBindAddress
import com.wgtunnel.backend.model.parseProxyBindAddress
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.orchestration.TunnelCoordinator
import com.zaneschepke.wireguardautotunnel.domain.repository.GlobalEffectRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.ProxySettingsRepository
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.GlobalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.state.ProxySettingsUiState
import com.zaneschepke.wireguardautotunnel.util.StringValue
import kotlinx.coroutines.flow.combine
import org.orbitmvi.orbit.OrbitContainerHost
import org.orbitmvi.orbit.viewmodel.orbitContainer

class ProxySettingsViewModel(
    private val proxySettingsRepository: ProxySettingsRepository,
    private val globalEffectRepository: GlobalEffectRepository,
    private val tunnelCoordinator: TunnelCoordinator,
) : OrbitContainerHost<ProxySettingsUiState, ProxySettingsUiState, Nothing>, ViewModel() {

    override val container =
        orbitContainer<ProxySettingsUiState, Nothing>(
            ProxySettingsUiState(),
            buildSettings = { repeatOnSubscribedStopTimeout = 5000L },
        ) {
            combine(tunnelCoordinator.backendStatus, proxySettingsRepository.flow) {
                    backendStatus,
                    settings ->
                    if (state.isLoading) {
                        ProxySettingsUiState(
                            proxySettings = settings,
                            backendStatus = backendStatus,
                            isLoading = false,
                            socks5Enabled = settings.socks5ProxyEnabled,
                            httpEnabled = settings.httpProxyEnabled,
                            allowSocks4 = settings.allowSocks4,
                            socksBindAddress = settings.socks5ProxyBindAddress ?: "",
                            httpBindAddress = settings.httpProxyBindAddress ?: "",
                            proxyUsername = settings.proxyUsername ?: "",
                            proxyPassword = settings.proxyPassword ?: "",
                        )
                    } else {
                        state.copy(backendStatus = backendStatus)
                    }
                }
                .collect { reduce { it } }
        }

    fun save(restart: Boolean = false) = intent {
        val current = state

        val updated =
            current.proxySettings
                .copy(
                    socks5ProxyEnabled = current.socks5Enabled,
                    httpProxyEnabled = current.httpEnabled,
                    allowSocks4 = current.allowSocks4,
                    socks5ProxyBindAddress = current.socksBindAddress.ifBlank { null },
                    httpProxyBindAddress = current.httpBindAddress.ifBlank { null },
                    proxyUsername = current.proxyUsername.ifBlank { null },
                    proxyPassword = current.proxyPassword.ifBlank { null },
                )
                .let { if (it.canAllowSocks4) it else it.copy(allowSocks4 = false) }

        val isHttpDefault = updated.httpProxyBindAddress == null
        val isSocks5Default = updated.socks5ProxyBindAddress == null

        // Validate bind addresses
        if (!isSocks5Default && !updated.socks5ProxyBindAddress.isValidProxyBindAddress()) {
            return@intent reduce { state.copy(isSocks5BindAddressError = true) }
        }
        if (!isHttpDefault && !updated.httpProxyBindAddress.isValidProxyBindAddress()) {
            return@intent reduce { state.copy(isHttpBindAddressError = true) }
        }
        // Validate different ports
        if (!isHttpDefault && !isSocks5Default) {
            val socksPort = updated.socks5ProxyBindAddress.parseProxyBindAddress()?.second
            val httpPort = updated.httpProxyBindAddress.parseProxyBindAddress()?.second
            if (socksPort == null || httpPort == null || socksPort == httpPort) {
                return@intent postSideEffect(
                    GlobalSideEffect.Snackbar(
                        StringValue.StringResource(R.string.ports_must_differ),
                        ToastType.Error,
                    ),
                )
            }
        }
        // Validate username and password (both null or both not null)
        if (!areBothNullOrBothNotNull(updated.proxyUsername, updated.proxyPassword)) {
            return@intent reduce {
                state.copy(
                    isUserNameError = updated.proxyUsername == null,
                    isPasswordError = updated.proxyPassword == null,
                )
            }
        }

        if (updated.proxyPassword?.any { it.isWhitespace() } == true) {
            postSideEffect(
                GlobalSideEffect.Snackbar(
                    StringValue.StringResource(R.string.password_no_spaces),
                    ToastType.Error,
                ),
            )
            return@intent reduce { state.copy(isPasswordError = true) }
        }

        proxySettingsRepository.upsert(updated)
        if (restart) tunnelCoordinator.restartActiveTunnels()

        postSideEffect(
            GlobalSideEffect.Snackbar(
                StringValue.StringResource(R.string.config_changes_saved),
                ToastType.Success,
            ),
        )
        postSideEffect(GlobalSideEffect.PopBackStack)
    }

    fun clearHttpBindError() = intent { reduce { state.copy(isHttpBindAddressError = false) } }

    fun clearSocks5BindError() = intent { reduce { state.copy(isSocks5BindAddressError = false) } }

    fun clearUsernameError() = intent { reduce { state.copy(isPasswordError = false) } }

    fun clearPasswordError() = intent { reduce { state.copy(isPasswordError = false) } }

    suspend fun postSideEffect(globalSideEffect: GlobalSideEffect) {
        globalEffectRepository.post(globalSideEffect)
    }

    private fun areBothNullOrBothNotNull(s1: String?, s2: String?) = (s1 == null) == (s2 == null)

    fun onSocks5EnabledChanged(enabled: Boolean) = intent {
        reduce { state.copy(socks5Enabled = enabled) }
    }

    fun onHttpEnabledChanged(enabled: Boolean) = intent {
        reduce { state.copy(httpEnabled = enabled) }
    }

    fun onSocksBindChanged(value: String) = intent {
        reduce { state.copy(socksBindAddress = value, isSocks5BindAddressError = false) }
    }

    fun onHttpBindChanged(value: String) = intent {
        reduce { state.copy(httpBindAddress = value, isHttpBindAddressError = false) }
    }

    fun onUsernameChanged(value: String) = intent {
        reduce {
            state.copy(
                proxyUsername = value,
                isUserNameError = false,
                // SOCKS4 has no auth - turn the toggle off rather than leave it silently
                // ignored once credentials are configured.
                allowSocks4 = if (value.isBlank()) state.allowSocks4 else false,
            )
        }
    }

    fun onAllowSocks4Changed(allowed: Boolean) = intent {
        reduce { state.copy(allowSocks4 = allowed) }
    }

    fun onPasswordChanged(value: String) = intent {
        reduce { state.copy(proxyPassword = value, isPasswordError = false) }
    }

    fun onPasswordVisibilityChanged(value: Boolean) = intent {
        reduce { state.copy(passwordVisible = value) }
    }
}
