package com.zaneschepke.wireguardautotunnel.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Raw .ovpn text editor for OpenVPN tunnels. The text is re-parsed on
 * save (via [OpenVpnCoordinator.updateOvpnText]) so an invalid config
 * is rejected with an error instead of being stored.
 */
class OpenVpnEditViewModel(
    private val tunnelRepository: TunnelRepository,
    private val openVpnCoordinator: OpenVpnCoordinator,
    val tunnelId: Int,
) : ViewModel() {

    /**
     * The tunnel as last loaded from the DB. Fix9: save() used to read
     * this from a `SharingStarted.WhileSubscribed` StateFlow that
     * NOTHING ever collected — so its value stayed null forever and
     * save() returned at its first line, silently, on every tap.
     * The user filled in the username/password, tapped the save icon,
     * and nothing was ever written (no error, no confirmation — the
     * screen just sat there). The loaded config is now kept in a
     * plain field, updated on every DB emission by the init
     * collector below (which DOES run).
     */
    private var currentTunnel: TunnelConfig? = null

    private val _text = MutableStateFlow<String?>(null)
    /** Null until the tunnel loads; the screen seeds the editor from it. */
    val text: StateFlow<String?> = _text.asStateFlow()

    private val _username = MutableStateFlow("")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _serverOverride = MutableStateFlow("")
    val serverOverride: StateFlow<String> = _serverOverride.asStateFlow()

    /** Credentials as loaded, to know whether the fields changed. */
    private var loadedUsername = ""
    private var loadedPassword = ""
    private var loadedServerOverride = ""

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    private val _saveError = MutableStateFlow(false)
    val saveError: StateFlow<Boolean> = _saveError.asStateFlow()

    /** The credentials could not be written (see save()). */
    private val _credentialsError = MutableStateFlow(false)
    val credentialsError: StateFlow<Boolean> = _credentialsError.asStateFlow()

    init {
        viewModelScope.launch {
            tunnelRepository.flow.collect { tunnels ->
                val current = tunnels.firstOrNull { it.id == tunnelId }
                if (current != null) {
                    // Always keep the latest DB state for save().
                    currentTunnel = current
                }
                if (current != null && _text.value == null) {
                    _text.value = current.ovpnText
                    loadedUsername = current.ovpnUsername
                    _username.value = current.ovpnUsername
                    // Saved password lives on the encrypted profile.
                    val (_, savedPassword) =
                        openVpnCoordinator.loadSavedCredentials(current)
                    loadedPassword = savedPassword
                    _password.value = savedPassword
                    loadedServerOverride = current.ovpnServerOverride
                    _serverOverride.value = current.ovpnServerOverride
                }
            }
        }
    }

    fun onTextChanged(newText: String) {
        _text.value = newText
    }

    fun onUsernameChanged(newUsername: String) {
        _username.value = newUsername
    }

    fun onPasswordChanged(newPassword: String) {
        _password.value = newPassword
    }

    fun onServerOverrideChanged(newServerOverride: String) {
        _serverOverride.value = newServerOverride
    }

    fun save() {
        val current = currentTunnel ?: return
        val newText = _text.value ?: return
        viewModelScope.launch {
            var updated = current
            if (newText != current.ovpnText) {
                updated = openVpnCoordinator.updateOvpnText(current, newText)
                    .getOrElse {
                        _saveError.value = true
                        return@launch
                    }
                currentTunnel = updated
            }
            // Credentials are stored on the encrypted profile (Keystore),
            // never as plaintext; the core then uses them automatically
            // at connect time, with no prompt.
            val username = _username.value
            val password = _password.value
            if (username != loadedUsername || password != loadedPassword) {
                // Fix9: the result is checked now. saveCredentials
                // used to return Unit and fail SILENTLY (e.g. when the
                // stored profile was unreadable), while save() still
                // reported success — so the user believed the
                // credentials were saved and they were not.
                val credentialsSaved =
                    openVpnCoordinator.saveCredentials(updated, username, password)
                if (!credentialsSaved) {
                    _credentialsError.value = true
                    return@launch
                }
                loadedUsername = username
                loadedPassword = password
            }
            // Server override (user 2026-11-27): stored on the config
            // row, applied to the profile copy at connect time — the
            // stored .ovpn text is never touched.
            val serverOverride = _serverOverride.value.trim()
            if (serverOverride != loadedServerOverride) {
                updated = updated.copy(ovpnServerOverride = serverOverride)
                tunnelRepository.save(updated)
                currentTunnel = updated
                loadedServerOverride = serverOverride
            }
            _saved.value = true
        }
    }

    fun consumeSaveError() {
        _saveError.value = false
    }

    fun consumeCredentialsError() {
        _credentialsError.value = false
    }
}
