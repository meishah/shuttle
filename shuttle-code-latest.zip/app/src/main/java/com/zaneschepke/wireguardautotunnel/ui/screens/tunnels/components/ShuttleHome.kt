package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import android.text.format.Formatter
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.QrCode
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Circle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.NetworkPing
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnState
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup
import com.zaneschepke.wireguardautotunnel.ui.state.DisplayTunnelState
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelListRow
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelsUiState
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroOnGradient
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotBottomLeft
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotBottomMid
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotBottomRight
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotCentre
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotMidLeft
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotMidRight
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotTopLeft
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotTopMid
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotTopRight
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotWaveBottom
import com.zaneschepke.wireguardautotunnel.ui.theme.HeroPilotWaveRight
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.OnLimeConnect
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavenderContainer
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavenderDeep
import com.zaneschepke.wireguardautotunnel.ui.theme.TileDark
import com.zaneschepke.wireguardautotunnel.ui.theme.TileLight
import com.zaneschepke.wireguardautotunnel.ui.theme.TileOnNavy
import com.zaneschepke.wireguardautotunnel.ui.theme.TileSelected
import com.zaneschepke.wireguardautotunnel.util.extensions.toUptimeDisplay
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import com.zaneschepke.wireguardautotunnel.ui.common.functions.rememberTickingNow
import kotlinx.coroutines.launch

/**
 * Shuttle's own home screen pieces (original code, Orion Store style:
 * Material 3 Expressive, spring motion, shape morphing, Material You
 * colours). This is what makes the home screen visibly Shuttle instead
 * of WG Tunnel: a branded hero with a big morphing connect button, a
 * Shuttle empty state, and tunnel/group cards instead of plain rows.
 *
 * Nothing here touches tunnel logic: all state comes from [TunnelsUiState]
 * (real backend / OpenVPN-bridge state only — connected is shown only
 * when the tunnel is really up) and all taps call back into the
 * existing ViewModel actions.
 */

/**
 * Light theme = light surface (White). The theme-aware tile/pill
 * colours (fix9, user 17:52) key off this: navy tiles, dark pills and
 * white text belong to the dark themes only; the light theme gets
 * pale-lavender tiles, light pills and dark text. Decided by surface
 * luminance, so explicit Light / Dark / Dynamic choices all follow —
 * isSystemInDarkTheme() would be wrong for an explicitly chosen theme.
 * Internal: shared with TunnelList.kt (same package).
 */
@Composable
internal fun isLightShuttleTheme(): Boolean =
    MaterialTheme.colorScheme.surface.luminance() > 0.5f

/** The user's shuttle mark in a black rounded tile. Uses the dedicated
 * in-app asset (ic_shuttle_mark, larger art) — NOT the launcher
 * foreground, which is padded down to the adaptive-icon safe zone. */
@Composable
fun ShuttleMark(size: Dp, cornerRadius: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier =
            modifier
                .size(size)
                .clip(RoundedCornerShape(cornerRadius))
                .background(Color.Black)
                .padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_shuttle_mark),
            contentDescription = stringResource(R.string.app_name),
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

/**
 * Connected hero background — EXACTLY the Orion Pilot card reference
 * (user 18:56: "دقیقا این زمینه رو بساز",
 * workspace/user/files/122554_10_vuqt.jpg, and again 2026-11-25 with
 * workspace/user/files/123461_4_bvz3.jpg). COMPLETELY STATIC: no
 * drifting gradient, no moving waves — the only motion on the hero is
 * the small green flower next to "Connected", which keeps rotating
 * slowly (user 18:56: "فقط اون چیز سبز کنار کانکت بچرخه کافیه").
 *
 * Since 2026-11-25 the Pilot gradient is used in BOTH themes (user:
 * change the hero background to the Pilot card) — the light theme no
 * longer has its own pale-lavender hero. Hero text is therefore
 * near-white (HeroOnGradient) in both themes.
 *
 * Why the old background looked wrong on her phone (1.3 screenshots):
 * a 4-stop diagonal gradient whose dark return (#3B2D8F at 1.00)
 * re-appeared at the bottom-right, plus one huge solid white flower
 * blob (0.22 alpha over half the card) whose wavy edge read as big
 * dark-navy wave shapes next to a pale washed-out slab. The reference
 * has neither: it is a smooth purple-to-blue field built from a dark
 * vertical spine plus large soft radial blobs at the sampled colours,
 * with two barely-visible feathered waves.
 *
 * The layering below is the PIL replica validated against the
 * reference's 3x3 sampled grid (all 9 points within ~8/255 per
 * channel): base vertical gradient (top-mid → centre → bottom-mid),
 * six corner/edge radial blobs, two subtle elliptical waves.
 *
 * Internal: shared with the About screen (SupportScreen), whose hero
 * card uses the exact same gradient.
 */
internal fun Modifier.connectedHeroBackground(isLight: Boolean): Modifier = drawBehind {
    drawRect(
        brush =
            Brush.verticalGradient(
                listOf(HeroPilotTopMid, HeroPilotCentre, HeroPilotBottomMid),
            ),
    )
    // Corner / edge blobs at the sampled colours.
    drawHeroBlob(cx = 0.02f, cy = 0.02f, rx = 0.55f, ry = 0.55f, color = HeroPilotTopLeft)
    drawHeroBlob(cx = 0.00f, cy = 0.50f, rx = 0.42f, ry = 0.42f, color = HeroPilotMidLeft)
    drawHeroBlob(cx = 1.00f, cy = 0.00f, rx = 0.50f, ry = 0.50f, color = HeroPilotTopRight)
    drawHeroBlob(cx = 1.00f, cy = 0.50f, rx = 0.55f, ry = 0.55f, color = HeroPilotMidRight)
    drawHeroBlob(cx = 0.95f, cy = 1.00f, rx = 0.50f, ry = 0.50f, color = HeroPilotBottomRight)
    drawHeroBlob(cx = 0.00f, cy = 1.00f, rx = 0.42f, ry = 0.42f, color = HeroPilotBottomLeft)
    // Two barely-visible feathered waves (reference: wave-right
    // #504CBA, wave-bottom #3756C0) — very low contrast on purpose.
    drawHeroBlob(cx = 0.85f, cy = 0.30f, rx = 0.45f, ry = 0.55f, color = HeroPilotWaveRight, alpha = 0.5f)
    drawHeroBlob(cx = 0.70f, cy = 1.05f, rx = 0.55f, ry = 0.45f, color = HeroPilotWaveBottom, alpha = 0.5f)
}

/**
 * One soft elliptical radial blob: [color] at full strength in the
 * centre, feathering to transparent at the ellipse edge (three-stop
 * falloff, soft tail). cx/cy/rx/ry are fractions of the draw area.
 */
private fun DrawScope.drawHeroBlob(
    cx: Float,
    cy: Float,
    rx: Float,
    ry: Float,
    color: Color,
    alpha: Float = 1f,
) {
    val center = Offset(size.width * cx, size.height * cy)
    // Ellipse via a scale transform about the blob centre: draw a
    // circle of radius max(rx, ry) and squash it to (rx, ry).
    val r = maxOf(rx * size.width, ry * size.height)
    val sx = (rx * size.width) / r
    val sy = (ry * size.height) / r
    withTransform({ scale(sx, sy, center) }) {
        drawCircle(
            brush =
                Brush.radialGradient(
                    colorStops =
                        arrayOf(
                            0.0f to color.copy(alpha = alpha),
                            0.6f to color.copy(alpha = alpha * 0.55f),
                            1.0f to color.copy(alpha = 0f),
                        ),
                    center = center,
                    radius = r,
                ),
            radius = r,
            center = center,
        )
    }
}

/**
 * A clean SYMMETRIC flower (user 18:57: "گلشم یخورده خوشکل ترش کن
 * چرا انقد کجک لوجه"): even, balanced petals — equal size, evenly
 * spaced around the centre, smooth rounded lobes, no lopsided bulge.
 * The old flowerBlobPath broke the symmetry with a seed phase shift
 * and a second harmonic, so one side bulged and the petals were
 * uneven. This one is a pure cosine: perfectly 6-fold symmetric, a
 * neat little flower, not a lumpy blob.
 */
private fun symmetricFlowerPath(cx: Float, cy: Float, r: Float, petals: Int = 6): Path {
    val path = Path()
    val points = 72
    for (i in 0..points) {
        val angle = (i.toFloat() / points) * 2f * PI.toFloat()
        val wobble = 1f + 0.12f * cos(petals * angle)
        val x = cx + cos(angle) * r * wobble
        val y = cy + sin(angle) * r * wobble
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

/**
 * Small lime flower (Orion "Look & feel" petal shape) that rotates
 * slowly while connected. The rotation is driven by the hero rotation
 * Animatable, so it pauses whenever the hero animation pauses.
 * This is the ONLY animation on the hero (user 18:56) — the
 * background itself is completely static.
 */
@Composable
private fun RotatingFlowerIcon(rotationDegrees: Float, modifier: Modifier = Modifier) {
    Canvas(
        // GPU-composited rotation: the flower path is drawn once and the
        // layer rotates, so a frame costs no re-draw.
        modifier = modifier.size(20.dp).graphicsLayer { rotationZ = rotationDegrees },
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        // 10 petals (user 2026-11-24, approved preview): more, rounder
        // petals — the flower reads close to a circle, neat and
        // symmetrical, not a pointy star.
        drawPath(
            path = symmetricFlowerPath(cx = cx, cy = cy, r = size.width * 0.48f, petals = 10),
            color = LimeConnect,
        )
    }
}

/**
 * Hero card at the top of the home screen: Shuttle branding, the real
 * connection status of the active tunnel (if any), live stats while
 * connected, and one big spring-morphing connect/disconnect button.
 * With no configs at all the button opens the import flow instead.
 */
@Composable
fun ShuttleHomeHero(
    activeTunnelName: String?,
    activeState: DisplayTunnelState,
    /** Specific failure reason (e.g. the OpenVPN watchdog error) — shown under the status line when failed, so a dead tunnel never fails silently. */
    errorMessage: String? = null,
    configCount: Int,
    groupCount: Int,
    hasTunnels: Boolean,
    statsContent: (@Composable () -> Unit)?,
    onToggle: () -> Unit,
    onImportClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val connected = activeState is DisplayTunnelState.Connected
    val connecting =
        activeState is DisplayTunnelState.ResolvingDns ||
            activeState is DisplayTunnelState.EstablishingConnection
    val failed = activeState is DisplayTunnelState.HandshakeFailure

    fun <T> heroSpring() =
        spring<T>(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        )

    val containerColor by
        animateColorAsState(
            targetValue =
                when {
                    connected -> MaterialTheme.colorScheme.primaryContainer
                    failed -> MaterialTheme.colorScheme.errorContainer
                    connecting -> MaterialTheme.colorScheme.tertiaryContainer
                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                },
            animationSpec = heroSpring<Color>(),
            label = "heroContainerColor",
        )
    val onContainerColor =
        when {
            connected -> MaterialTheme.colorScheme.onPrimaryContainer
            failed -> MaterialTheme.colorScheme.onErrorContainer
            connecting -> MaterialTheme.colorScheme.onTertiaryContainer
            else -> MaterialTheme.colorScheme.onSurface
        }

    // The hero background is COMPLETELY STATIC (user 18:56: "نمیخواد
    // اصلا متحرک باشه") — the gradient and waves are drawn once in
    // connectedHeroBackground() and never move. The ONLY motion on the
    // hero is the small green flower next to "Connected", which keeps
    // rotating slowly (one turn per ~20s, user 18:56: "فقط اون چیز
    // سبز کنار کانکت بچرخه کافیه"). The rotation runs only while
    // connected AND resumed, so it costs no battery when not visible.
    val rotationAnim = remember { Animatable(0f) }
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner, connected) {
        if (!connected) return@LaunchedEffect
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            launch {
                rotationAnim.animateTo(
                    360f,
                    animationSpec =
                        infiniteRepeatable(
                            animation = tween(durationMillis = 20000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart,
                        ),
                )
            }
        }
    }
    // Text on the connected gradient: near-white on the deep purple
    // Pilot gradient in BOTH themes (user 2026-11-25). Other states
    // keep the theme onContainer colour for their flat backgrounds.
    val isLight = isLightShuttleTheme()
    val heroTextColor =
        when {
            connected -> HeroOnGradient
            else -> onContainerColor
        }

    Column(
        // Gap budget (user 19:57, approved preview 19:58):
        // chips→hero is the bar's 10dp fade zone only, hero→Ping
        // is spacedBy 5dp + actions-row 5dp — both 10dp, equal.
        // So the hero item itself carries NO vertical padding:
        // the old top 2dp + bottom 4dp stacked on top of the
        // spacedBy and the actions-row padding (14dp visible
        // instead of 10dp). Same bug as the tiles' 4dp+4dp,
        // which made the tile gaps 13dp instead of 5dp.
        modifier = modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp),
    ) {
        Box(
            modifier =
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .then(
                        if (connected) Modifier.connectedHeroBackground(isLight)
                        else Modifier.background(containerColor),
                    )
                    .animateContentSize(animationSpec = heroSpring()),
        ) {
            Column(
                // A bit more compact (user 2026-11-24: the connection-
                // info card a bit smaller): 10dp padding and 6dp
                // section gaps instead of 12dp / 8dp.
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
            // No Shuttle icon / "Shuttle" title in the hero (user
            // 2026-11-24: too crowded) — the config name (or the
            // count when disconnected) is the header instead.
            Text(
                text =
                    activeTunnelName
                        ?: if (hasTunnels) {
                            val countText =
                                stringResource(
                                    R.string.shuttle_home_config_count,
                                    configCount,
                                )
                            buildString {
                                append(countText)
                                if (groupCount > 0) append(" · $groupCount groups")
                            }
                        } else {
                            stringResource(R.string.shuttle_home_protocols)
                        },
                style = MaterialTheme.typography.titleLargeEmphasized,
                color = heroTextColor,
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // One green connected indicator per place, not two: while
                // connected the rotating flower (left of "Connected") is
                // the indicator, so the status dot is hidden. Other
                // states keep their dot — it is their only status mark.
                // Small lime flower (Orion "Look & feel" petal shape)
                // left of "Connected", rotating slowly — one full turn
                // per ~20s, driven by the hero rotation Animatable, so
                // it pauses whenever the hero animation pauses.
                if (connected) {
                    RotatingFlowerIcon(rotationDegrees = rotationAnim.value)
                }
                if (!connected) {
                    Icon(
                        Icons.Rounded.Circle,
                        contentDescription = null,
                        tint = remember(activeState) { activeState.asColor() },
                        modifier = Modifier.size(14.dp),
                    )
                }
                Text(
                    text = stringResource(activeState.labelRes()),
                    style = MaterialTheme.typography.titleMediumEmphasized,
                    color = heroTextColor,
                )
            }

            AnimatedVisibility(
                visible = failed && errorMessage != null,
                enter =
                    expandVertically(animationSpec = heroSpring()) + fadeIn(),
                exit =
                    shrinkVertically(animationSpec = heroSpring()) + fadeOut(),
            ) {
                Text(
                    text = errorMessage.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = heroTextColor.copy(alpha = 0.9f),
                )
            }

            AnimatedVisibility(
                visible = statsContent != null,
                enter =
                    expandVertically(animationSpec = heroSpring()) + fadeIn(),
                exit =
                    shrinkVertically(animationSpec = heroSpring()) + fadeOut(),
            ) {
                statsContent?.invoke()
            }

            ShuttleHeroButton(
                connected = connected,
                connecting = connecting,
                failed = failed,
                hasTunnels = hasTunnels,
                onClick = if (hasTunnels) onToggle else onImportClick,
            )
            }
        }
    }
}

/** Big morphing connect/disconnect button for the hero card. */
@Composable
private fun ShuttleHeroButton(
    connected: Boolean,
    connecting: Boolean,
    failed: Boolean,
    hasTunnels: Boolean,
    onClick: () -> Unit,
) {
    fun <T> heroSpring() =
        spring<T>(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        )

    // Fully rounded pill: corner radius = half the 40dp height, in every
    // state (user: the lime buttons' corners must be completely round).
    // Compact (fix6 follow-up): the hero button was a tall full-width
    // pill — now 40dp high, still full-width and tappable.
    val cornerRadius = 20.dp
    val containerColor by
        animateColorAsState(
            targetValue =
                when {
                    // Lime green (from the user's reference picture) for
                    // both Connect and Disconnect; only a failed tunnel
                    // reads as an error.
                    connected -> LimeConnect
                    failed -> MaterialTheme.colorScheme.errorContainer
                    connecting -> MaterialTheme.colorScheme.surfaceContainerHighest
                    hasTunnels -> LimeConnect
                    else -> MaterialTheme.colorScheme.primary
                },
            animationSpec = heroSpring<Color>(),
            label = "heroButtonContainerColor",
        )
    val contentColor by
        animateColorAsState(
            targetValue =
                when {
                    connected -> OnLimeConnect
                    failed -> MaterialTheme.colorScheme.onErrorContainer
                    connecting -> MaterialTheme.colorScheme.onSurfaceVariant
                    hasTunnels -> OnLimeConnect
                    else -> MaterialTheme.colorScheme.onPrimary
                },
            animationSpec = heroSpring<Color>(),
            label = "heroButtonContentColor",
        )

    val labelRes =
        when {
            // While connecting the button is Cancel: tapping aborts the
            // in-progress connect (WG backend stop / OpenVPN stop, which
            // also disarms the 45s watchdog) and returns to disconnected.
            connecting -> R.string.cancel
            connected || failed -> R.string.ovpn_disconnect
            !hasTunnels -> R.string.shuttle_home_import_config
            else -> R.string.ovpn_connect
        }
    // A failed tunnel retries on tap, so its button reads "Connect".
    val effectiveLabelRes =
        if (failed) R.string.ovpn_connect else labelRes

    Box(
        modifier =
            Modifier.fillMaxWidth()
                .height(40.dp)
                .clip(RoundedCornerShape(cornerRadius))
                .background(containerColor)
                .clickable(
                    role = Role.Button,
                    onClick = onClick,
                ),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = Triple(connected, connecting, failed),
            transitionSpec = {
                (fadeIn(animationSpec = heroSpring<Float>()) +
                        scaleIn(animationSpec = heroSpring<Float>()))
                    .togetherWith(
                        fadeOut(animationSpec = heroSpring<Float>()) +
                            scaleOut(animationSpec = heroSpring<Float>()),
                    )
            },
            label = "heroButtonContent",
        ) { (isConnected, isConnecting, isFailed) ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                when {
                    isConnecting -> {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    isConnected -> {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    isFailed -> {
                        Icon(
                            Icons.Rounded.Refresh,
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    else -> {
                        Icon(
                            Icons.Rounded.PowerSettingsNew,
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
                Text(
                    text = stringResource(effectiveLabelRes),
                    style = MaterialTheme.typography.titleMediumEmphasized,
                    color = contentColor,
                )
            }
        }
    }
}

/**
 * Empty state: the shuttle mark, a plain invitation, and a big import
 * button. Replaces WG Tunnel's "Nothing here… yet." + sad document.
 */
@Composable
fun ShuttleEmptyState(onImportClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        ShuttleMark(size = 96.dp, cornerRadius = 28.dp)
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = stringResource(R.string.shuttle_home_empty_title),
            style = MaterialTheme.typography.titleLargeEmphasized,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.shuttle_home_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = onImportClick) {
            Icon(
                Icons.Filled.Add,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = stringResource(R.string.shuttle_home_import_config))
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = ".conf · .awg · .ovpn · .zip",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
            textAlign = TextAlign.Center,
        )
    }
}

/** Expressive group header card: folder in a tonal circle, name, counts, chevron. */
@Composable
fun ShuttleGroupHeader(
    row: TunnelListRow.GroupHeader,
    uiState: TunnelsUiState,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val containerColor by
        animateColorAsState(
            targetValue =
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceContainer,
            animationSpec =
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow,
                ),
            label = "groupHeaderColor",
        )
    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(containerColor)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier =
                    Modifier.size(34.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (row.visibleExpanded) Icons.Outlined.FolderOpen
                    else Icons.Outlined.Folder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(18.dp),
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = row.group.name,
                    style = MaterialTheme.typography.titleMediumEmphasized,
                )
                if (row.childCount > 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text =
                                pluralStringResource(
                                    R.plurals.group_tunnel_count,
                                    row.childCount,
                                    row.childCount,
                                ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (row.activeCount > 0) {
                            Text(
                                text = "·",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text =
                                    stringResource(
                                        R.string.group_active_count,
                                        row.activeCount,
                                    ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
            if (row.childCount > 0) {
                Icon(
                    if (row.visibleExpanded) Icons.Rounded.ExpandLess
                    else Icons.Rounded.ExpandMore,
                    contentDescription =
                        stringResource(
                            if (row.visibleExpanded) R.string.collapse_group
                            else R.string.expand_group,
                        ),
                )
            }
        }
    }
}

/**
 * The connection-info content of a MORPHED tile (user 2026-11-24):
 * when a config is tapped to connect, its own tile expands (animated)
 * and becomes the Connect/hero tile — status row + stats + Disconnect
 * button, on the hero gradient. Rendered as the tile's expandedContent.
 * The flower rotates slowly while connected (one turn per ~20s, same
 * as the top hero); the rotation only runs while connected, so it
 * costs no battery when the tile is idle.
 */
@Composable
internal fun ShuttleTunnelHeroContent(
    displayState: DisplayTunnelState,
    statsContent: (@Composable () -> Unit)?,
    onDisconnect: () -> Unit,
) {
    val connected = displayState is DisplayTunnelState.Connected
    val connecting =
        displayState is DisplayTunnelState.ResolvingDns ||
            displayState is DisplayTunnelState.EstablishingConnection
    val failed = displayState is DisplayTunnelState.HandshakeFailure
    val heroTextColor =
        when {
            connected -> HeroOnGradient
            else -> MaterialTheme.colorScheme.onSurface
        }
    val rotationAnim = remember { Animatable(0f) }
    LaunchedEffect(connected) {
        if (!connected) return@LaunchedEffect
        rotationAnim.animateTo(
            360f,
            animationSpec =
                infiniteRepeatable(
                    animation = tween(durationMillis = 20000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart,
                ),
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (connected) {
                RotatingFlowerIcon(rotationDegrees = rotationAnim.value)
            }
            if (!connected) {
                Icon(
                    Icons.Rounded.Circle,
                    contentDescription = null,
                    tint = remember(displayState) { displayState.asColor() },
                    modifier = Modifier.size(14.dp),
                )
            }
            Text(
                text = stringResource(displayState.labelRes()),
                style = MaterialTheme.typography.titleSmallEmphasized,
                color = heroTextColor,
            )
        }
        if (statsContent != null) {
            statsContent()
        }
        ShuttleHeroButton(
            connected = connected,
            connecting = connecting,
            failed = failed,
            hasTunnels = true,
            onClick = onDisconnect,
        )
    }
}

/**
 * Actions in the per-tile ⋮ menu (user 2026-11-24: long-press is
 * removed — each config carries its own ⋮ menu instead).
 */
enum class TunnelMenuAction {
    Pin,
    Share,
    ShareAsQr,
    Edit,
    Rename,
    MoveToGroup,
    Ping,
    Delete,
}

/**
 * Expressive tunnel card, Orion app-list style: 28dp rounded container
 * (primaryContainer while running) with a subtle blob-motif background,
 * large squircle icon tile, status dot, emphasized name, ping / server
 * lines, the morphing connect button, and live stats while running.
 * Tap opens the tunnel detail, long-press selects — same behaviour as
 * the old row.
 */
@Composable
fun ShuttleTunnelCard(
    tunnel: TunnelConfig,
    displayState: DisplayTunnelState,
    isRunning: Boolean,
    selected: Boolean,
    isFirst: Boolean,
    isLast: Boolean,
    description: (@Composable () -> Unit)?,
    expandedContent: (@Composable () -> Unit)?,
    onClick: () -> Unit,
    onMenuAction: (TunnelMenuAction) -> Unit,
    trailing: @Composable (Modifier) -> Unit,
    modifier: Modifier = Modifier,
) {
    fun <T> cardSpring() =
        spring<T>(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        )

    // Single flat colour (user 2026-11-24, approved preview): NO
    // flower blob, NO separate idle/running shades — one flat
    // colour per theme (dark #262638, light white). The SELECTED
    // tile is a clearly darker purple #7C74D0, so the selection is
    // visible at a glance (pin-selection bug fix).
    // MORPHED tile (user 2026-11-24): when a config is connected its
    // own tile IS the hero — expandedContent is set, so the tile
    // takes the hero gradient background instead of the flat colour,
    // and its text turns the hero colours.
    val isLight = isLightShuttleTheme()
    val isHero = expandedContent != null
    val containerColor by
        animateColorAsState(
            targetValue =
                when {
                    selected -> TileSelected
                    isLight -> TileLight
                    else -> TileDark
                },
            animationSpec = cardSpring<Color>(),
            label = "tunnelCardColor",
        )
    // Corner radii by position (user 2026-11-24, measured from her
    // photo: first tile top 21dp / bottom 8dp, every other tile
    // 8dp on all corners; the LAST tile gets 21dp bottom corners so
    // the list reads as one rounded card, top and bottom).
    val cardShape =
        when {
            isFirst -> {
                RoundedCornerShape(
                    topStart = 21.dp,
                    topEnd = 21.dp,
                    bottomStart = 8.dp,
                    bottomEnd = 8.dp,
                )
            }
            isLast -> {
                RoundedCornerShape(
                    topStart = 8.dp,
                    topEnd = 8.dp,
                    bottomStart = 21.dp,
                    bottomEnd = 21.dp,
                )
            }
            else -> RoundedCornerShape(8.dp)
        }
    Column(
        modifier =
            modifier
                .fillMaxWidth()
                // Tiles are always 16dp from each edge, exactly like
                // the hero (user 18:53: "کاشیای کانفیگا وسط نیستن
                // رفتن سمت راست"). The old code indented grouped
                // children by 40dp, but the flat filtered list shows
                // no group headers at all — the indent was a pure
                // bug: the tiles sat ~24dp right of the hero.
                // NO vertical padding here (user 19:57): the old
                // top 4dp + bottom 4dp stacked on the LazyColumn's
                // 5dp spacedBy, so the visible tile gap was 13dp
                // instead of the approved 5dp. spacedBy alone is
                // the whole gap now.
                .padding(start = 16.dp, end = 16.dp)
                .clip(cardShape)
                .then(
                    if (isHero) Modifier.connectedHeroBackground(isLight)
                    else Modifier.background(containerColor),
                )
                // No long-press (user 2026-11-24: removed) — tap
                // connects/disconnects, the ⋮ menu holds the actions.
                .clickable(onClick = onClick)
                .animateContentSize(animationSpec = cardSpring())
                .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // No letter tile (user 2026-11-24, approved preview):
            // the protocol is written in small text under the name
            // instead (see tunnelRowDescription). No protocol logo
            // either — just the name and the protocol line. The
            // status dot lived on the letter tile, so it goes with
            // it; the tile's state is shown by the morphing hero
            // (connected/connecting) and the lime checkmark.
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                // Pinned configs carry a small pin glyph after the
                // name (18dp — big enough to see clearly at a glance,
                // still within the text line height, so the tile height,
                // padding and spacing do not change).
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tunnel.name,
                        style = MaterialTheme.typography.titleSmallEmphasized,
                        // Selected tile is the dark purple #7C74D0, so
                        // the name is white. Dark theme: the tile is
                        // dark slate, so the name is explicit white.
                        // Light theme: the tile is white, so the name
                        // is the theme's dark onSurface.
                        color =
                            when {
                                isHero -> HeroOnGradient
                                selected -> Color.White
                                isLight -> MaterialTheme.colorScheme.onSurface
                                else -> TileOnNavy
                            },
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (tunnel.isPinned) {
                        Icon(
                            Icons.Filled.PushPin,
                            contentDescription = stringResource(R.string.pin),
                            tint =
                                when {
                                        isHero -> HeroOnGradient
                                    selected -> Color.White
                                    isLight -> MaterialTheme.colorScheme.onSurface
                                    else -> TileOnNavy
                                },
                            modifier = Modifier.size(18.dp).padding(start = 4.dp),
                        )
                    }
                }
                description?.invoke()
            }
            trailing(Modifier)
            // Per-tile ⋮ menu (user 2026-11-24): replaces long-press.
            var showMenu by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        Icons.Outlined.MoreVert,
                        contentDescription = stringResource(R.string.more_options),
                        tint =
                            when {
                                isHero -> HeroOnGradient
                                selected -> Color.White
                                isLight -> MaterialTheme.colorScheme.onSurface
                                else -> TileOnNavy
                            },
                        modifier = Modifier.size(20.dp),
                    )
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                ) {
                    DropdownMenuItem(
                        text = {
                            Text(
                                stringResource(
                                    if (tunnel.isPinned) R.string.unpin else R.string.pin,
                                ),
                            )
                        },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Pin)
                        },
                        leadingIcon = {
                            Icon(
                                if (tunnel.isPinned) Icons.Filled.PushPin
                                else Icons.Outlined.PushPin,
                                contentDescription = null,
                            )
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.share)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Share)
                        },
                        leadingIcon = {
                            Icon(Icons.Outlined.Share, contentDescription = null)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.share_as_qr)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.ShareAsQr)
                        },
                        leadingIcon = {
                            Icon(Icons.Outlined.QrCode, contentDescription = null)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.edit_tunnel)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Edit)
                        },
                        leadingIcon = {
                            Icon(Icons.Outlined.Edit, contentDescription = null)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename_tunnel)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Rename)
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Outlined.DriveFileRenameOutline,
                                contentDescription = null,
                            )
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.move_to_group)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.MoveToGroup)
                        },
                        leadingIcon = {
                            Icon(Icons.Outlined.Folder, contentDescription = null)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.ping_tunnel)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Ping)
                        },
                        leadingIcon = {
                            Icon(Icons.Rounded.NetworkPing, contentDescription = null)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete)) },
                        onClick = {
                            showMenu = false
                            onMenuAction(TunnelMenuAction.Delete)
                        },
                        leadingIcon = {
                            Icon(Icons.Outlined.Delete, contentDescription = null)
                        },
                    )
                }
            }
        }
        if (expandedContent != null) {
            expandedContent()
        }
    }
}

/**
 * Orion-style pill search bar at the top of the home screen: a fully
 * rounded dark pill with a lavender search icon. Filters the tunnel
 * list by name / server as the user types. COMPACT (fix8, size kept
 * in fix9): the whole bar is 40dp tall. Fix9: the bar is a
 * [BasicTextField], NOT a Material3 TextField — TextField enforces a
 * 56dp minimum height, and the 40dp Box clamp sliced the text off at
 * the top (her 17:19 screenshot: "Search configs" with clipped
 * ascenders; the fix8 "16 + 16 = 32 ≤ 40, nothing clips" arithmetic
 * was wrong because the TextField's own layout still needs its full
 * 56dp). BasicTextField has no minimum height, so the 12sp/16dp line
 * sits centred in the 40dp bar with the placeholder fully visible.
 * Placement (fix9, her 17:19 instruction): back in the scrolling
 * content — it scrolls away with the list again, as originally.
 */
@Composable
fun ShuttleSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .height(40.dp)
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        // BasicTextField, NOT Material3 TextField: TextField enforces
        // a 56dp minimum height, and the 40dp Box clamp cut the text
        // off at the top (her 17:19 screenshot). BasicTextField has
        // no minimum height — the 12sp line sits centred in the 40dp
        // bar with the placeholder fully visible.
        val focusManager = LocalFocusManager.current
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle =
                MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions =
                KeyboardActions(
                    onSearch = { focusManager.clearFocus() },
                ),
            decorationBox = { innerTextField ->
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (query.isEmpty()) {
                            Text(
                                text = stringResource(R.string.shuttle_home_search_hint),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                            )
                        }
                        innerTextField()
                    }
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = { onQueryChange("") },
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
    }
}

/**
 * Orion-style segmented pill control: the selected pill is lavender
 * with dark text, the others are dark pills with grey text. Fix9
 * (user 17:29): the GROUPS live here now — one chip per group next
 * to All, with the round Add-group button right after All. Tapping a
 * group chip filters the list to that group's configs; the big
 * expandable group rows in the list are gone. The protocol chips
 * (WireGuard / OpenVPN) are removed — she does not need them.
 * Long-pressing a group chip opens that group's actions (rename /
 * ungroup / delete). The row scrolls horizontally when there are
 * many groups.
 */
@Composable
fun ShuttleGroupFilter(
    selectedGroupId: Int?,
    allCount: Int,
    groups: List<TunnelGroup>,
    groupCounts: Map<Int, Int>,
    onSelectGroup: (Int?) -> Unit,
    onAddGroupClick: () -> Unit,
    onGroupLongPress: (TunnelGroup) -> Unit,
    modifier: Modifier = Modifier,
) {
    // ONE single capsule (user 2026-11-24, approved preview): All · N
    // | + | WireGuard | Tunnelbear | Snowhaze… in one fully-round pill
    // instead of separate pills. The outer capsule carries the
    // surfaceContainerHigh background the unselected chips used to
    // have; each segment is transparent unless selected, and segments
    // are separated by thin 1dp dividers. The row scrolls horizontally
    // inside the capsule when there are many groups. Overall height is
    // unchanged (chip vertical padding 6dp + 4dp capsule padding top
    // and bottom, same 8dp the old row's vertical padding added), so
    // the chips→hero 10dp gap — measured from this content bottom —
    // is unaffected.
    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ShuttleGroupChip(
                label = stringResource(R.string.shuttle_home_filter_all),
                count = allCount,
                isSelected = selectedGroupId == null,
                onClick = { onSelectGroup(null) },
            )
            ShuttleGroupDivider()
            // Right after the All chip (user 15:25) — not at the end.
            ShuttleAddGroupButton(onClick = onAddGroupClick)
            groups.sortedBy { it.position }.forEach { group ->
                ShuttleGroupDivider()
                ShuttleGroupChip(
                    label = group.name,
                    count = groupCounts[group.id] ?: 0,
                    isSelected = selectedGroupId == group.id,
                    onClick = { onSelectGroup(group.id) },
                    onLongPress = { onGroupLongPress(group) },
                )
            }
        }
    }
}

/** Thin 1dp divider between the segments of the single filter capsule. */
@Composable
private fun ShuttleGroupDivider() {
    Box(
        modifier =
            Modifier
                .width(1.dp)
                .height(20.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
    )
}

@Composable
private fun ShuttleGroupChip(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongPress: (() -> Unit)? = null,
) {
    // Selected segment: lavender background with DARK text in BOTH
    // themes (user 17:52) — never a dark pill with light text. The
    // deep-lavender primary + white text the old code used fails
    // this in the light theme. Unselected segments are transparent:
    // the single outer capsule behind them provides the
    // surfaceContainerHigh background.
    val containerColor by
        animateColorAsState(
            targetValue =
                if (isSelected) OrionLavender
                else Color.Transparent,
            animationSpec =
                spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow,
                ),
            label = "filterChipColor",
        )
    val contentColor =
        if (isSelected) OnSelectedCapsule
        else MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        modifier =
            Modifier.clip(RoundedCornerShape(50))
                .background(containerColor)
                .combinedClickable(
                    role = Role.Button,
                    onClick = onClick,
                    onLongClick = onLongPress,
                )
                .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "$label · $count",
            style = MaterialTheme.typography.labelLargeEmphasized,
            color = contentColor,
            maxLines = 1,
        )
    }
}

/**
 * Shared Orion-style action pill for the home screen (Ping servers).
 * Dark theme: a dark rounded pill (#3E3C5E) with a light lavender
 * icon and near-white label. Light theme (user 17:52, final
 * approval): a LIGHT lavender pill with dark text — never the dark
 * pill in the light theme.
 */
@Composable
private fun ShuttleHomePill(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    // Optional trailing counter (ping progress "45/100"): set in
    // monospace with a fixed digit width so the pill never changes
    // width while the numbers tick up — no flicker, no layout jump.
    counter: String? = null,
) {
    val isLight = isLightShuttleTheme()
    val pillColor =
        if (isLight) MaterialTheme.colorScheme.primaryContainer
        else OrionLavenderContainer
    val textColor =
        if (isLight) MaterialTheme.colorScheme.onPrimaryContainer
        else Color(0xFFF2F2F4)
    val iconTint = if (isLight) OrionLavenderDeep else OrionLavender
    Box(
        modifier =
            modifier
                .clip(RoundedCornerShape(50))
                .background(pillColor)
                .clickable(role = Role.Button, onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(14.dp),
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLargeEmphasized,
                color = textColor,
                maxLines = 1,
            )
            if (counter != null) {
                Text(
                    text = counter,
                    style = MaterialTheme.typography.labelLargeEmphasized,
                    fontFamily = FontFamily.Monospace,
                    color = textColor,
                    maxLines = 1,
                )
            }
        }
    }
}

/**
 * Plain "+" segment inside the single filter capsule (user 2026-11-24):
 * just a plus sign, NO separate pill background or circle — the outer
 * capsule is the only pill. Same segment geometry as the group chips
 * (12dp horizontal / 6dp vertical padding) so the row height is
 * unchanged. Tapping opens the group-name dialog; the group is created
 * empty and tunnels move into it from the selection actions.
 */
@Composable
fun ShuttleAddGroupButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier =
            modifier
                .clip(RoundedCornerShape(50))
                .clickable(role = Role.Button, onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Filled.Add,
            contentDescription = stringResource(R.string.add_group),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
    }
}

/**
 * Visible "Ping servers" pill on its own row, centered: pinging no
 * longer hides in the overflow (⋮) menu. Tapping measures every server
 * (ICMP, with a TCP-connect fallback for OpenVPN servers that block
 * ICMP) and shows the latency on each row; sorting by lowest ping
 * stays in the Reorder sheet. While a run is in flight the pill shows
 * live progress ("45/100") next to the label: the pinged number is
 * padded to the digit width of the total and set in monospace, so the
 * pill keeps a constant width for the whole run — no flicker, no
 * layout jump as the numbers tick up. Locale.US: %d must always render
 * ASCII digits (a Persian-locale default would render non-ASCII digits
 * and break the fixed width). When the run ends the counter disappears
 * and the pill returns to the plain "Ping servers" label.
 */
@Composable
fun ShuttlePingButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    pinged: Int? = null,
    total: Int? = null,
) {
    val counter =
        if (pinged != null && total != null && total > 0) {
            String.format(Locale.US, "%${total.toString().length}d/%d", pinged, total)
        } else {
            null
        }
    ShuttleHomePill(
        icon = Icons.Rounded.NetworkPing,
        label = stringResource(R.string.ping_servers),
        counter = counter,
        onClick = onClick,
        modifier = modifier,
    )
}

/**
 * Live statistics for a connected OpenVPN tunnel: data volume, connection
 * time (ticking once per second, only while this row is visible) and the
 * public IP / country fetched once after connect. Shown only in the top
 * hero card — never duplicated on the tunnel row.
 */
@Composable
internal fun OpenVpnStatisticsRow(state: OpenVpnState.Connected) {
    val context = LocalContext.current
    val now by rememberTickingNow()
    val style = MaterialTheme.typography.bodySmall
    // Near-white on the connected hero's purple Pilot gradient in
    // both themes — never outline/onSurfaceVariant there (washed out
    // on the gradient).
    val color = HeroOnGradient
    val ipCountry = listOfNotNull(state.ip, state.country).joinToString(" · ")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text =
                    stringResource(
                        R.string.ovpn_stats_download,
                        Formatter.formatFileSize(context, state.bytesIn),
                    ),
                style = style,
                color = color,
            )
            Text(
                text =
                    stringResource(
                        R.string.ovpn_stats_upload,
                        Formatter.formatFileSize(context, state.bytesOut),
                    ),
                style = style,
                color = color,
            )
        }
        Text(
            text =
                stringResource(
                    R.string.uptime_template,
                    state.connectedAtMs.toUptimeDisplay(now),
                ),
            style = style,
            color = color,
        )
        if (ipCountry.isNotEmpty()) {
            Text(
                text = ipCountry,
                style = style,
                color = color,
            )
        }
    }
}
