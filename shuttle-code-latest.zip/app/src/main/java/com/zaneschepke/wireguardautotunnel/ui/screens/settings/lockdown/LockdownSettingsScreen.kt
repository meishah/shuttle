package com.zaneschepke.wireguardautotunnel.ui.screens.settings.lockdown

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DataUsage
import androidx.compose.material.icons.outlined.Lan
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsLabel
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.dialog.InfoDialog
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.viewmodel.LockdownViewModel
import com.zaneschepke.wireguardautotunnel.viewmodel.SharedAppViewModel
import org.koin.androidx.compose.koinViewModel
import org.koin.compose.viewmodel.koinActivityViewModel
import org.orbitmvi.orbit.compose.collectAsState
import org.orbitmvi.orbit.compose.collectSideEffect

/**
 * Restyled like Settings (user 2026-11-25, approved preview): the
 * three toggles sit in one big rounded card with tinted-squircle
 * icons and lime switches. Rows and actions unchanged.
 */
@Composable
fun LockdownSettingsScreen(
    viewModel: LockdownViewModel = koinViewModel(),
    sharedViewModel: SharedAppViewModel = koinActivityViewModel(),
) {

    val uiState by viewModel.collectAsState()

    sharedViewModel.collectSideEffect {
        if (it is LocalSideEffect.SaveChanges) viewModel.setShowSaveModal(true)
    }

    if (uiState.isLoading) return

    if (uiState.showSaveModal) {
        InfoDialog(
            onDismiss = { viewModel.setShowSaveModal(false) },
            onAttest = { viewModel.setLockdownSettings() },
            title = stringResource(R.string.save_changes),
            body = {
                Text(
                    stringResource(
                        R.string.restart_message_template,
                        stringResource(R.string.kill_switch),
                    ),
                )
            },
            confirmText = stringResource(R.string._continue),
        )
    }

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding()
                .padding(top = 70.dp, bottom = 140.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ShuttleSettingsLabel(stringResource(R.string.configuration))
            ShuttleSettingsCard {
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Lan) },
                    title = stringResource(R.string.allow_lan_traffic),
                    description = {
                        Text(
                            text = stringResource(R.string.bypass_lan_for_kill_switch),
                            style =
                                MaterialTheme.typography.bodySmall.copy(
                                    MaterialTheme.colorScheme.outline,
                                ),
                        )
                    },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.bypassLan,
                            onClick = { viewModel.setBypassLan(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    onClick = { viewModel.setBypassLan(!uiState.bypassLan) },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    SurfaceRow(
                        leading = { ShuttleSettingIcon(Icons.Outlined.DataUsage) },
                        title = stringResource(R.string.metered_tunnel),
                        trailing = { modifier ->
                            SwitchWithDivider(
                                checked = uiState.metered,
                                onClick = { viewModel.setMetered(it) },
                                modifier = modifier,
                                checkedTrackColor = LimeConnect,
                            )
                        },
                        onClick = { viewModel.setMetered(!uiState.metered) },
                        containerColor = Color.Transparent,
                    )
                    ShuttleSettingsDivider()
                }
                SurfaceRow(
                    leading = {
                        ShuttleSettingIcon(ImageVector.vectorResource(R.drawable.host))
                    },
                    title = stringResource(R.string.dual_stack),
                    description = { DescriptionText(stringResource(R.string.dual_stack_description)) },
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = uiState.dualStack,
                            onClick = { viewModel.setDualStack(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                        )
                    },
                    onClick = { viewModel.setDualStack(!uiState.dualStack) },
                    containerColor = Color.Transparent,
                )
            }
        }
    }
}
