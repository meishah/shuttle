package com.zaneschepke.wireguardautotunnel.domain.model

import com.wgtunnel.backend.Tunnel
import com.wgtunnel.parser.Config
import com.wgtunnel.parser.InterfaceSection
import com.wgtunnel.parser.PeerSection
import com.wgtunnel.parser.crypto.Key
import com.zaneschepke.wireguardautotunnel.data.entity.TunnelConfig.Companion.GLOBAL_CONFIG_NAME
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelSummary
import com.zaneschepke.wireguardautotunnel.util.extensions.defaultName

data class TunnelConfig(
    val id: Int = 0,
    val name: String,
    val tunnelNetworks: List<String> = emptyList(),
    val isMobileDataTunnel: Boolean = false,
    val isPrimaryTunnel: Boolean = false,
    val quickConfig: String = "",
    val isEthernetTunnel: Boolean = false,
    val isIpv6Preferred: Boolean = false,
    val position: Int = 0,
    val autoTunnelApps: List<String> = listOf(),
    val isMetered: Boolean = false,
    val ipv6RestoreEnabled: Boolean = false,
    val tunnelBSSIDs: List<String> = emptyList(),
    val isDDNSTunnel: Boolean = false,
    val groupId: Int? = null,
    val entryTunnelId: Int? = null,
    // Shuttle: OpenVPN rows (see entity). quickConfig is empty for them.
    val isOpenVpn: Boolean = false,
    val ovpnUuid: String? = null,
    val ovpnText: String = "",
    val ovpnUsername: String = "",
    // Optional per-config server override (user 2026-11-27): when set,
    // connect to this address instead of the config's own remote.
    val ovpnServerOverride: String = "",
    val autoReconnect: Boolean = true,
    // Last measured ping (ms), persisted in the DB — shown on the row until
    // a new ping replaces it (the in-memory map clears on connect).
    val lastPingMs: Double? = null,
    // Pinned: sorts to the top of the list within its group (and in
    // the All view). Persisted in the DB (is_pinned).
    val isPinned: Boolean = false,
) {

    fun toSummary() = TunnelSummary(id = id, name = name)

    /** Only valid for WireGuard/AmneziaWG rows — never call on OpenVPN rows. */
    fun getConfig(): Config {
        check(!isOpenVpn) { "getConfig() called on an OpenVPN tunnel" }
        return Config.parseQuickString(quickConfig)
    }

    /** First `remote` host from the .ovpn text, for pinging. Null for WG rows. */
    val ovpnEndpointHost: String?
        get() {
            if (!isOpenVpn) return null
            return Regex("""(?m)^\s*remote\s+(\S+)""").find(ovpnText)?.groupValues?.getOrNull(1)
        }

    /** Port from the first `remote` line of the .ovpn text (default 1194). Null for WG rows. */
    val ovpnEndpointPort: Int?
        get() {
            if (!isOpenVpn) return null
            val m =
                Regex("""(?m)^\s*remote\s+\S+(?:\s+(\d+))?""").find(ovpnText) ?: return 1194
            return m.groupValues.getOrNull(1)?.toIntOrNull() ?: 1194
        }

    /** Server display name for OpenVPN rows: first remote host:port. */
    val ovpnServerLabel: String?
        get() {
            if (!isOpenVpn) return null
            val m = Regex("""(?m)^\s*remote\s+(\S+)(?:\s+(\d+))?""").find(ovpnText) ?: return null
            val host = m.groupValues[1]
            val port = m.groupValues.getOrNull(2)?.takeIf { it.isNotEmpty() }
            return if (port != null) "$host:$port" else host
        }

    val isGlobalConfig: Boolean
        get() = name == GLOBAL_CONFIG_NAME

    fun toBackendTunnel(
        monitoringSettings: MonitoringSettings,
        scriptsEnabled: Boolean,
        generalSettings: GeneralSettings,
    ): Tunnel = BackendTunnel(this, generalSettings, monitoringSettings, scriptsEnabled)

    private class BackendTunnel(
        private val config: TunnelConfig,
        private val generalSettings: GeneralSettings,
        private val monitoringSettings: MonitoringSettings,
        override val scriptsEnabled: Boolean,
    ) : Tunnel {

        override val id: Int
            get() = config.id

        override val name: String
            get() = config.name

        override val isMetered: Boolean
            get() = config.isMetered

        override val strictSplitTunnel: Boolean
            get() = generalSettings.strictSplitTunnelEnabled

        override val ipStrategy: Tunnel.IpStrategy
            get() =
                if (config.isIpv6Preferred)
                    Tunnel.IpStrategy.PreferIpv6(recoveryEnabled = config.ipv6RestoreEnabled)
                else Tunnel.IpStrategy.Ipv4Only

        override val features: Set<Tunnel.Feature>
            get() = buildSet {
                if (monitoringSettings.tunnelStatisticsEnabled) {
                    add(
                        Tunnel.Feature.ActiveConfigMonitor(
                            monitoringSettings.tunnelStatisticsPollInterval,
                        ),
                    )
                }
                add(
                    Tunnel.Feature.Recovery(
                        seamlessRecovery = generalSettings.seamlessRecoveryEnabled,
                        dynamicDnsRecovery = config.isDDNSTunnel,
                        ipv4Fallback = config.isIpv6Preferred,
                        ipv6Recovery = config.ipv6RestoreEnabled,
                        bounceDelaySeconds = generalSettings.seamlessRecoveryBounceDelaySec,
                    ),
                )
            }

        override fun updateState(state: Tunnel.State) = Unit
    }

    companion object {

        fun fromConfig(config: Config, nameIfMissing: String? = null): TunnelConfig {
            return TunnelConfig(
                name = config.name ?: nameIfMissing ?: config.defaultName(),
                quickConfig = config.asQuickString(),
            )
        }

        fun generateDefaultGlobalConfig(): TunnelConfig {
            val privateKey: String = Key.generatePrivateKey().toBase64()
            val publicKey: String = Key.generatePrivateKey().toBase64()
            val config =
                Config(
                    `interface` =
                        InterfaceSection(address = "10.0.0.2/32", privateKey = privateKey),
                    peers =
                        listOf(
                            PeerSection(
                                publicKey = publicKey,
                                endpoint = "server.example.com:51820",
                                allowedIPs = "0.0.0.0/0",
                            ),
                        ),
                )
            return TunnelConfig(name = GLOBAL_CONFIG_NAME, quickConfig = config.asQuickString())
        }
    }
}
