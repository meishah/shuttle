package com.zaneschepke.wireguardautotunnel.ui.navigation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleTopScrim
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.ShuttleGroupFilter
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.ShuttleMark
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.ShuttleSearchBar
import com.zaneschepke.wireguardautotunnel.ui.state.NavbarState
import com.zaneschepke.wireguardautotunnel.ui.theme.LockedDownBannerHeight
import com.zaneschepke.wireguardautotunnel.ui.theme.OnSelectedCapsule
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender
import java.util.Locale

/**
 * The home screen's floating top bar (user 18:48, 18:53): the
 * approved preview's arrangement, pixel for pixel — the two top
 * capsules (SHUTTLE left, + right — the ⋮ menu was removed in 1.5,
 * user 20:01: "اینم کلا بردار نیاز نمیشه"), the search capsule
 * DIRECTLY under them, then the group chips row, all inside ONE
 * frosted bar that fades gradually at its bottom edge (10dp fade
 * zone, approved preview spacing).
 *
 * This REPLACES the Material3 TopAppBar (DynamicTopAppBar) on the
 * home route. The frosted backdrop is a plain gradient scrim (see
 * ShuttleHaze.kt): Haze 1.7.0's progressive blur never rendered on her
 * phone — the capsules floated over the hero with no frosted backdrop
 * at all (user 18:48: "بالا اصلا محو نیست", 19:53: "ببین اصلا محو بالا
 * وجود نداره"). A Brush scrim cannot fail to render.
 * The search and chips used to be LazyColumn items, so they scrolled
 * away from the capsules and sat detached from them; they live in this
 * bar now and never scroll away.
 *
 * In reorder/selection mode the bar shrinks to just the mode row
 * (back/close + title + mode actions) — search and chips are
 * hidden there, and the list's top padding drops to match (see
 * TunnelList).
 */
@Composable
fun ShuttleHomeTopBar(
    navBarState: NavbarState,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedGroupId: Int?,
    allCount: Int,
    groups: List<TunnelGroup>,
    groupCounts: Map<Int, Int>,
    onSelectGroup: (Int?) -> Unit,
    onAddGroupClick: () -> Unit,
    onGroupLongPress: (TunnelGroup) -> Unit,
    // True when there is anything to search or filter: with no
    // configs and no groups the search and chips capsules are
    // hidden too (user 2026-11-28) — the empty state has its own
    // Import button and nothing to search or filter.
    hasContent: Boolean = true,
    // Reports the bottom edge of the bar's VISIBLE content — the
    // chips row in normal mode, the mode row in reorder/selection
    // mode — in root px, so MainActivity can place the hero
    // exactly 10dp below it (fix15). This is NOT the bar's layout
    // bottom: the layout extends 18dp below the content (8dp
    // Column spacedBy + 10dp fade Spacer), so measuring the layout
    // bottom put the hero 28dp below the chips in 50811.
    onContentBottomPx: (Float) -> Unit = {},
    // Reports the bar's OWN layout height in px (excluding the status
    // bar the caller pads outside). This is a single self-contained
    // measurement — no root coordinates, no dependence on where the
    // list happens to be — so the home screen can derive a clearance
    // that can never be smaller than the bar itself, on any phone.
    onBarHeightPx: (Int) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    // Reorder/selection mode: the bar shows the back/close button
    // and the mode title instead of the SHUTTLE capsule.
    val inMode = navBarState.topLeading != null
    Box(
        modifier =
            modifier
                .onSizeChanged { onBarHeightPx(it.height) }
                .fillMaxWidth()
                .shuttleTopScrim()
                .padding(top = LockedDownBannerHeight)
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 0.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Row 1: the two top capsules.
            Row(
                modifier =
                    Modifier.fillMaxWidth()
                        .onGloballyPositioned { coords ->
                            // In reorder/selection mode — and in the
                            // empty state, where search and chips are
                            // hidden — this row IS the last visible
                            // content, so its bottom is the content
                            // edge. In normal mode the chips below
                            // are the edge — ignore this.
                            if (inMode || !hasContent) {
                                onContentBottomPx(coords.positionInRoot().y + coords.size.height)
                            }
                        },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (inMode) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        navBarState.topLeading?.invoke()
                        navBarState.topTitle?.let {
                            Text(
                                it,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleLarge,
                            )
                        }
                    }
                } else {
                    // The SHUTTLE capsule: the real app icon + title
                    // in one pill — lavender background with DARK
                    // text in BOTH themes (user 17:52), "SHUTTLE"
                    // in ALL CAPS, extra-bold (user 15:12 / fix8).
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier =
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(OrionLavender)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                    ) {
                        ShuttleMark(size = 28.dp, cornerRadius = 8.dp)
                        Text(
                            navBarState.topTitle?.uppercase(Locale.ROOT) ?: "SHUTTLE",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = OnSelectedCapsule,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    }
                }
                // Right: the actions capsule (+/⋮, or the
                // mode-specific actions) — one pill, same lavender.
                Box { navBarState.topTrailing?.invoke() }
            }
            if (!inMode && hasContent) {
                // Row 2: the search capsule, DIRECTLY under the two
                // top capsules, grouped with them (user 18:48).
                // The search bar carries 12dp of its own horizontal
                // padding; 4dp more here lines it up with the
                // capsules at 16dp.
                ShuttleSearchBar(
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                // Row 3: the group chips (All · N, + button, groups).
                ShuttleGroupFilter(
                    selectedGroupId = selectedGroupId,
                    allCount = allCount,
                    groups = groups,
                    groupCounts = groupCounts,
                    onSelectGroup = onSelectGroup,
                    onAddGroupClick = onAddGroupClick,
                    onGroupLongPress = onGroupLongPress,
                    // The chips row is the last visible content in
                    // normal mode — its bottom is the content edge
                    // (fix15). In reorder/selection mode this row
                    // is not composed, so it never reports there.
                    modifier =
                        Modifier.onGloballyPositioned { coords ->
                            onContentBottomPx(coords.positionInRoot().y + coords.size.height)
                        },
                )
            }
            // Fade zone: 10dp of empty space at the bottom of the
            // bar — the scrim's gradient fades to clear across it,
            // so there is no hard line where the bar ends and the
            // hero shows through under the fade, exactly as in the
            // approved preview spacing (user 19:58: "عالیه همینو
            // میخوام"). The hero sits 10dp below the CONTENT edge
            // (chips / mode row bottom, reported via
            // onContentBottomPx) — NOT 10dp below this spacer.
            // The fade zone overlaps that 10dp gap. Measuring the
            // bar's layout bottom (which includes this spacer plus
            // the 8dp spacedBy above it) put the hero 28dp below
            // the chips in 50811 (fix15).
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
