package com.zaneschepke.wireguardautotunnel.core.openvpn

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import timber.log.Timber

/**
 * Durable, Keystore-encrypted store for OpenVPN passwords, keyed by the
 * STABLE tunnel (config) id.
 *
 * Why this exists (OVPN password bug): the password used to live ONLY on
 * the Java-serialized VpnProfile file, keyed by the profile UUID — but
 * that UUID is regenerated on every reparse (ConfigParser mints a new
 * random UUID per parse), and the file is deleted whenever it cannot be
 * deserialized (e.g. profiles written by pre-fix7 builds with obfuscated
 * class names are pruned as unreadable). Every rebuild (connect-time in
 * startInternal, updateOvpnText, the provideCredentials heal path)
 * creates a password-less profile from the .ovpn text — credentials were
 * stripped at import — and discards the old one, so the password was
 * silently lost while the username survived (it is ALSO in the Room DB
 * as ovpnUsername). Keying the password by the stable config id, in a
 * Keystore-encrypted store, makes it survive profile rebuilds, pruning
 * and UUID changes. The profile remains the runtime source the core
 * reads; this store is the durable fallback, and the profile is healed
 * from it whenever it is found lacking (see loadSavedCredentials).
 *
 * All operations are failure-tolerant and never throw: if the encrypted
 * prefs cannot be created (Keystore unavailable, …) the store silently
 * degrades to a no-op and the profile remains the only store, exactly
 * as before. Callers run on Dispatchers.IO; init does disk I/O.
 */
class OvpnPasswordStore(private val appContext: Context) {

    private val prefs: SharedPreferences? by lazy {
        runCatching {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        }.onFailure {
            Timber.e(it, "OvpnPasswordStore: encrypted prefs unavailable; OVPN passwords will not survive profile rebuilds")
        }.getOrNull()
    }

    /** Persist [password] for [configId]; a blank password removes the entry. */
    fun savePassword(configId: Int, password: String) {
        val p = prefs ?: return
        runCatching {
            // commit(), not apply(): the caller just told the user the
            // credentials are saved — the write must be on disk before
            // save() returns. Small prefs file, IO thread, cheap.
            val editor = p.edit()
            if (password.isEmpty()) editor.remove(keyFor(configId))
            else editor.putString(keyFor(configId), password)
            editor.commit()
        }.onFailure {
            Timber.e(it, "OvpnPasswordStore: failed to save password for config $configId")
        }
    }

    /** Durable password for [configId], or "" when none is stored / unavailable. */
    fun loadPassword(configId: Int): String {
        val p = prefs ?: return ""
        return runCatching { p.getString(keyFor(configId), "") ?: "" }
            .onFailure {
                Timber.e(it, "OvpnPasswordStore: failed to load password for config $configId")
            }.getOrDefault("")
    }

    companion object {
        private const val PREFS_NAME = "ovpn_credentials"

        /**
         * Stable key: the tunnel id never changes, unlike the profile
         * UUID (regenerated on every reparse). Keying by the id is what
         * makes the password survive profile rebuilds.
         */
        internal fun keyFor(configId: Int): String = "ovpn_password_$configId"
    }
}
