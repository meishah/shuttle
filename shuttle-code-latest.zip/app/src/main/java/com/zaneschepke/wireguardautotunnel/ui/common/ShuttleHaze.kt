package com.zaneschepke.wireguardautotunnel.ui.common

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Telegram-style frosted bars for the floating top/bottom bars (user
 * 17:46–17:49): a surface-coloured scrim, strongest at the bar and
 * fading smoothly to fully transparent at the bar's edge — a progressive
 * gradient, so there is NO hard line where the frost ends and the clear
 * list begins. The blur is strongest at the bar and the fade is gradual
 * on BOTH bars (user 18:48 / 19:53: "اون خط باید کم کم محو بشه").
 *
 * Why a plain gradient scrim and NOT Haze (fix11, 1.5): Haze 1.7.0's
 * progressive blur NEVER rendered on her Samsung SM-S721B (Android 17)
 * — the top bar showed nothing at all (no blur, not even the tint,
 * which the progressive gradient masks) and the bottom bar showed a
 * full blur with a hard edge — in 1.3 AND in 1.4, after two different
 * fixes (TopAppBar -> plain Box, backgroundColor removed). Best
 * evidence for the cause: the symptoms are exactly what a gradient
 * span of under one pixel would produce (top gradient 0.55->1.0 all
 * above the bar's pixels = ~0 intensity everywhere; bottom gradient
 * 0->0.7 = ~1 intensity everywhere), but the library's gradient math
 * could not be verified from the compiled AAR, and there is no emulator
 * to test hypotheses on. A Brush.verticalGradient is drawn by Compose
 * itself: it cannot fail to render, and a smooth gradient cannot have
 * a hard line. The frosted look is the same as the approved preview's
 * fade; the bars keep the same heights and fade zones.
 *
 * Battery: a static brush costs nothing while scrolling — no blur
 * re-rendering at all.
 */
@Composable
fun Modifier.shuttleTopScrim(): Modifier {
    val surface = MaterialTheme.colorScheme.surface
    return background(
        Brush.verticalGradient(
            // Uniform frost through the capsules and the search
            // capsule, then a LONG gradual fade to clear — the fade
            // starts at ~60% of the bar height (around the search /
            // chips boundary) and runs to the bar's bottom edge, so
            // content scrolling under the bar fades out gradually
            // over ~40% of the bar (~76dp), exactly like the bottom
            // scrim's long fade (user 21:13: "محو پایین خوبه ولی
            // محو شدن بالای صفحه مثل پایین کم کم نیست"). The old
            // gradient held full frost until 94% and faded only
            // across the 10dp fade zone, so the hero went from
            // dimmed to fully bright across 10dp — a visible edge
            // just above "Connected". The chips/search pills are
            // opaque, so the weakening frost behind them costs
            // nothing in readability; the fade is visible through
            // the gaps between the pills and the fade zone.
            0.00f to surface.copy(alpha = 0.92f),
            0.60f to surface.copy(alpha = 0.92f),
            0.80f to surface.copy(alpha = 0.55f),
            1.00f to Color.Transparent,
        ),
    )
}

@Composable
fun Modifier.shuttleBottomScrim(): Modifier {
    val surface = MaterialTheme.colorScheme.surface
    return background(
        Brush.verticalGradient(
            // Fully clear at the top of the slot, fading in smoothly
            // to full frost at the screen edge (user 17:49: the blur
            // must reach the very bottom edge).
            0.00f to Color.Transparent,
            0.45f to surface.copy(alpha = 0.80f),
            1.00f to surface.copy(alpha = 0.92f),
        ),
    )
}
