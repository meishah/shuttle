package com.zaneschepke.wireguardautotunnel.viewmodel

import android.net.Uri
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dokar.sonner.ToastType
import com.wgtunnel.parser.Config
import com.wgtunnel.parser.ConfigParseException
import com.wgtunnel.parser.archive.ConfigArchive
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.core.lock.AppLockManager
import com.zaneschepke.wireguardautotunnel.core.openvpn.OpenVpnCoordinator
import com.zaneschepke.wireguardautotunnel.core.orchestration.AutoTunnelCoordinator
import com.zaneschepke.wireguardautotunnel.core.orchestration.TunnelBackendCoordinator
import com.zaneschepke.wireguardautotunnel.core.orchestration.TunnelCoordinator
import com.zaneschepke.wireguardautotunnel.core.tunnel.StrictSplitDefaults
import com.zaneschepke.wireguardautotunnel.domain.enums.TunnelMode
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelGroup
import com.zaneschepke.wireguardautotunnel.domain.repository.AppStateRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.GeneralSettingRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.GlobalEffectRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.SelectedTunnelsRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelGroupRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelsSelection
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.GlobalSideEffect
import com.zaneschepke.wireguardautotunnel.domain.sideeffect.NotificationPendingAction
import com.zaneschepke.wireguardautotunnel.service.ServiceManager
import com.zaneschepke.wireguardautotunnel.service.autotunnel.AutoTunnelStateHolder
import com.zaneschepke.wireguardautotunnel.ui.sideeffect.LocalSideEffect
import com.zaneschepke.wireguardautotunnel.ui.state.DisplayTunnelState
import com.zaneschepke.wireguardautotunnel.ui.state.GlobalAppUiState
import com.zaneschepke.wireguardautotunnel.ui.state.TunnelsUiState
import com.zaneschepke.wireguardautotunnel.ui.state.nextChildPosition
import com.zaneschepke.wireguardautotunnel.ui.state.nextRootPosition
import com.zaneschepke.wireguardautotunnel.ui.state.shiftForInsertAfter
import com.zaneschepke.wireguardautotunnel.ui.state.shiftRootPositionsBy
import com.zaneschepke.wireguardautotunnel.ui.state.sortGroupChildrenByName
import com.zaneschepke.wireguardautotunnel.ui.state.sortRootByName
import com.zaneschepke.wireguardautotunnel.ui.state.ungroupKeepingOrder
import com.zaneschepke.wireguardautotunnel.ui.state.uniqueDisplayName
import com.zaneschepke.wireguardautotunnel.ui.theme.Theme
import com.zaneschepke.wireguardautotunnel.util.FileUtils
import com.zaneschepke.wireguardautotunnel.util.LocaleUtil
import com.zaneschepke.wireguardautotunnel.util.StringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.QuickConfig
import com.zaneschepke.wireguardautotunnel.util.extensions.TunnelName
import com.zaneschepke.wireguardautotunnel.util.extensions.asExportFileName
import com.zaneschepke.wireguardautotunnel.util.extensions.asFileExportName
import com.zaneschepke.wireguardautotunnel.util.extensions.asStringValue
import com.zaneschepke.wireguardautotunnel.util.extensions.isFileAccessDenied
import com.zaneschepke.wireguardautotunnel.util.extensions.saveTunnelsUniquely
import com.zaneschepke.wireguardautotunnel.util.network.NetworkUtils
import io.ktor.client.HttpClient
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.contentType
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.orbitmvi.orbit.OrbitContainerHost
import org.orbitmvi.orbit.viewmodel.orbitContainer
import timber.log.Timber
import xyz.teamgravity.pin_lock_compose.PinManager

class SharedAppViewModel(
    private val appStateRepository: AppStateRepository,
    private val serviceManager: ServiceManager,
    private val tunnelCoordinator: TunnelCoordinator,
    private val autoTunnelCoordinator: AutoTunnelCoordinator,
    private val globalEffectRepository: GlobalEffectRepository,
    private val tunnelRepository: TunnelRepository,
    private val tunnelGroupRepository: TunnelGroupRepository,
    private val settingsRepository: GeneralSettingRepository,
    private val autoTunnelStateHolder: AutoTunnelStateHolder,
    private val selectedTunnelsRepository: SelectedTunnelsRepository,
    private val tunnelBackendCoordinator: TunnelBackendCoordinator,
    private val httpClient: HttpClient,
    private val fileUtils: FileUtils,
    private val networkUtils: NetworkUtils,
    private val appLockManager: AppLockManager,
    private val strictSplitDefaults: StrictSplitDefaults,
    private val openVpnCoordinator: OpenVpnCoordinator,
) : OrbitContainerHost<GlobalAppUiState, GlobalAppUiState, LocalSideEffect>, ViewModel() {

    val globalSideEffect = globalEffectRepository.flow

    private val _supportAutoUpdateRequests = MutableSharedFlow<Boolean>(extraBufferCapacity = 1)
    val supportAutoUpdateRequests = _supportAutoUpdateRequests.asSharedFlow()

    fun requestSupportAutoUpdate(startDownload: Boolean) {
        _supportAutoUpdateRequests.tryEmit(startDownload)
    }

    // Sticky, the Support screen may not be composed yet when this is requested
    private val _showUpdateStatusRequested = MutableStateFlow(false)
    val showUpdateStatusRequested = _showUpdateStatusRequested.asStateFlow()

    fun requestShowUpdateStatus() {
        _showUpdateStatusRequested.value = true
    }

    fun consumeShowUpdateStatus() {
        _showUpdateStatusRequested.value = false
    }

    private val _showSplitSystemApps = MutableStateFlow(false)
    val showSplitSystemApps = _showSplitSystemApps.asStateFlow()
    private var splitSystemAppsTunnelId: Int? = null

    fun prepareSplitSystemApps(tunnelId: Int) {
        if (splitSystemAppsTunnelId != tunnelId) {
            splitSystemAppsTunnelId = tunnelId
            _showSplitSystemApps.value = false
        }
    }

    fun setShowSplitSystemApps(show: Boolean) {
        _showSplitSystemApps.value = show
    }

    fun clearSplitSystemApps(tunnelId: Int) {
        if (splitSystemAppsTunnelId == tunnelId) {
            splitSystemAppsTunnelId = null
            _showSplitSystemApps.value = false
        }
    }

    val strictSplitNotice =
        strictSplitDefaults.notice.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000L),
            null,
        )

    fun acknowledgeStrictSplitNotice() = intent { strictSplitDefaults.acknowledge() }

    fun answerStrictSplitSuggestion(enable: Boolean) = intent {
        strictSplitDefaults.answer(enable)
        if (enable) tunnelCoordinator.restartActiveTunnels()
    }

    private val reorderDraft = MutableStateFlow<ReorderDraft?>(null)
    private val pingLatencies = MutableStateFlow<Map<Int, Double>>(emptyMap())
    private val pingInFlight = MutableStateFlow(false)

    // The tunnels currently visible on the home list (expanded groups'
    // children + root tunnels, after search + protocol filter). The
    // list reports them; pinging scopes to exactly this set — never to
    // configs in a collapsed group or hidden by a filter.
    private val _visibleTunnelIds = MutableStateFlow<Set<Int>?>(null)

    fun setVisibleTunnelIds(ids: Set<Int>) {
        _visibleTunnelIds.value = ids
    }

    /** Live ping progress for the Ping servers pill: pinged / total of
     * the current run. Null when no ping is running. Lives in the
     * activity-scoped ViewModel so it survives navigation and resets
     * cleanly when the run ends. */
    data class PingProgress(val pinged: Int, val total: Int)

    private val _pingProgress = MutableStateFlow<PingProgress?>(null)
    val pingProgress: StateFlow<PingProgress?> = _pingProgress.asStateFlow()

    // Home list search + protocol filter. Kept here (activity-scoped
    // ViewModel), NOT in the composable's remember: opening a config
    // detail and pressing back must return to the same filtered/group
    // view instead of resetting to All.
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Group filter (the top chips row): null = All, otherwise the
    // entered group whose configs the list shows. Kept here
    // (activity-scoped ViewModel), NOT in the composable's remember:
    // opening a config detail and pressing back must return to the
    // same group view instead of resetting to All. Creating a group
    // selects it at once (createGroup / createGroupAndMoveSelected),
    // and importing while a group is entered targets that group.
    // (The old protocol filter chips — WireGuard / OpenVPN — were
    // removed at the user's request; groups are the filter now.)
    private val _selectedGroupId = MutableStateFlow<Int?>(null)
    val selectedGroupId: StateFlow<Int?> = _selectedGroupId.asStateFlow()

    fun setSelectedGroupFilter(groupId: Int?) {
        _selectedGroupId.value = groupId
        // Persisted, so reopening the app restores the same group
        // instead of resetting to All (user 19:56).
        viewModelScope.launch { appStateRepository.setSelectedGroupId(groupId) }
    }

    // Same, for the Orbit intents below (create/ungroup/delete):
    // setting the filter also persists it.
    private suspend fun applySelectedGroupFilter(groupId: Int?) {
        _selectedGroupId.value = groupId
        appStateRepository.setSelectedGroupId(groupId)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private val openVpnUiState =
        combine(openVpnCoordinator.state, openVpnCoordinator.activeTunnelId) { state, id ->
            state to id
        }

    // NOTE: kotlinx-coroutines' typed combine() caps at 5 flows, so the
    // OpenVPN state is folded in with a second, 3-flow combine below
    // instead of a single 6/7-flow combine.
    private val baseTunnelsUiState =
        combine(
                tunnelRepository.userTunnelsFlow,
                tunnelGroupRepository.flow,
                tunnelCoordinator.backendStatus,
                selectedTunnelsRepository.flow,
                reorderDraft,
            ) { tunnels, groups, backendStatus, selection, draft ->
                val displayStates =
                    backendStatus.activeTunnels.mapValues { (_, activeTunnel) ->
                        DisplayTunnelState.from(activeTunnel)
                    }

                TunnelsUiState(
                    tunnels = draft?.tunnels ?: tunnels,
                    groups = draft?.groups ?: groups,
                    backendStatus = backendStatus,
                    displayStates = displayStates,
                    selectedTunnels = selection.tunnels,
                    selectedGroups = selection.groups,
                    isLoading = false,
                    isReorderMode = draft != null,
                    reorderScopeGroupId = draft?.scopeGroupId,
                    reorderLatencies = draft?.latencies.orEmpty(),
                )
            }

    val tunnelsUiState =
        combine(
                baseTunnelsUiState,
                openVpnUiState,
                pingLatencies,
            ) { ui, ovpn, latencies ->
                val (ovpnState, ovpnId) = ovpn
                ui.copy(
                    openVpnState = ovpnState,
                    openVpnActiveId = ovpnId,
                    pingLatencies =
                        if (ui.backendStatus.activeTunnels.isEmpty() &&
                            ovpnId == null
                        ) latencies else emptyMap(),
                )
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), TunnelsUiState())

    override val container =
        orbitContainer<GlobalAppUiState, LocalSideEffect>(
            GlobalAppUiState(),
            buildSettings = { repeatOnSubscribedStopTimeout = 5_000L },
        ) {
            intent {
                combine(
                        tunnelRepository.userTunnelsFlow
                            .map { tuns -> tuns.associate { it.id to it.name } }
                            .distinctUntilChanged(),
                        settingsRepository.flow,
                        autoTunnelStateHolder.active,
                        tunnelsUiState
                            .map {
                                TunnelsChrome(
                                    loading = it.isLoading,
                                    selectedTunCount = it.selectedCount,
                                    canMoveToGroup = it.canMoveToGroup,
                                    isReorderMode = it.isReorderMode,
                                    reorderScopeTitle = it.reorderScopeGroup?.name,
                                    hasGroups = it.groups.isNotEmpty(),
                                    canReorder = it.tunnels.size + it.groups.size > 1,
                                    hasActiveTunnel = it.hasActiveTunnel,
                                    openVpnTunnelIds =
                                        it.tunnels.filter { tun -> tun.isOpenVpn }
                                            .map { tun -> tun.id }
                                            .toSet(),
                                )
                            }
                            .distinctUntilChanged(),
                        appStateRepository.flow,
                    ) { tunNames, settings, autoTunnelActive, chrome, appState ->
                        state.copy(
                            theme = settings.theme,
                            tunnelMode = settings.tunnelMode,
                            tunnelNames = tunNames,
                            alreadyDonated = settings.alreadyDonated,
                            isAutoTunnelActive = autoTunnelActive,
                            isLocationDisclosureShown = appState.isLocationDisclosureShown,
                            isBatteryOptimizationShown = appState.isBatteryOptimizationDisableShown,
                            shouldShowDonationSnackbar = appState.shouldShowDonationSnackbar,
                            isDesktopPromptShown = appState.isDesktopPromptShown,
                            selectedTunnelCount = chrome.selectedTunCount,
                            canMoveToGroup = chrome.canMoveToGroup,
                            isReorderMode = chrome.isReorderMode,
                            reorderScopeTitle = chrome.reorderScopeTitle,
                            hasGroups = chrome.hasGroups,
                            canReorder = chrome.canReorder,
                            hasActiveTunnel = chrome.hasActiveTunnel,
                            openVpnTunnelIds = chrome.openVpnTunnelIds,
                            pinLockEnabled = settings.isPinLockEnabled,
                            isScreenRecordingProtectionEnabled =
                                settings.screenRecordingSecurityEnabled,
                            isAppLoaded = !chrome.loading,
                        )
                    }
                    .collect { newState -> reduce { newState } }
            }
            intent {
                appLockManager.unlocked.collect { unlocked ->
                    reduce { state.copy(isPinVerified = unlocked) }
                }
            }
            intent {
                // Clear ping results when a tunnel is active
                combine(
                        tunnelCoordinator.backendStatus.map { it.activeTunnels.isNotEmpty() },
                        openVpnCoordinator.activeTunnelId.map { it != null },
                    ) { wgActive, ovpnActive -> wgActive || ovpnActive }
                    .distinctUntilChanged()
                    .collect { hasActiveTunnel ->
                        if (hasActiveTunnel) pingLatencies.value = emptyMap()
                    }
            }
            intent {
                // Remember the group filter across app restarts
                // (user 19:56: "هر وقت اپو باز میکنم میره روی
                // پوشه all, میخوام رو همون پوشه ای که قبلا بودم
                // بمونه"): reopening the app shows the group she
                // was last on, not All. Applied once the groups
                // have loaded; if the saved group was deleted
                // meanwhile, it stays on All.
                val savedId = appStateRepository.getSelectedGroupId() ?: return@intent
                val groups = tunnelGroupRepository.flow.first()
                if (groups.any { it.id == savedId }) {
                    _selectedGroupId.value = savedId
                }
            }
        }

    fun startTunnel(tunnelConfig: TunnelConfig) = intent {
        if (state.tunnelMode == TunnelMode.VPN) {
            if (!serviceManager.hasVpnPermission())
                return@intent postSideEffect(
                    GlobalSideEffect.RequestVpnPermission(TunnelMode.VPN, tunnelConfig),
                )
        }
        if (
            !serviceManager.hasNotificationPermission() &&
                !appStateRepository.isNotificationPermissionRequested()
        ) {
            appStateRepository.setNotificationPermissionRequested(true)
            return@intent postSideEffect(
                GlobalSideEffect.RequestNotificationPermission(
                    NotificationPendingAction.StartTunnel(tunnelConfig),
                ),
            )
        }
        tunnelCoordinator.startTunnel(tunnelConfig)
    }

    fun toggleAutoTunnel() = intent { autoTunnelCoordinator.toggle() }

    fun postSideEffect(localSideEffect: LocalSideEffect) = intent {
        postSideEffect(localSideEffect)
    }

    fun setLocationDisclosureShown() = intent {
        appStateRepository.setLocationDisclosureShown(true)
    }

    fun setTheme(theme: Theme) = intent { settingsRepository.updateTheme(theme) }

    fun setLocale(locale: String) = intent {
        // pre-T the stored value is reapplied on startup, on T+ the system persists it
        if (!LocaleUtil.isSystemManaged) settingsRepository.updateLocale(locale)
        withContext(Dispatchers.Main) { LocaleUtil.changeLocale(locale) }
    }

    fun syncLocale() = intent {
        val stored = settingsRepository.flow.firstOrNull()?.locale ?: return@intent
        if (stored == LocaleUtil.OPTION_PHONE_LANGUAGE) return@intent
        if (LocaleUtil.isSystemManaged) {
            // one-time handoff to the system, without overriding a locale set in system settings
            if (AppCompatDelegate.getApplicationLocales().isEmpty) {
                withContext(Dispatchers.Main) { LocaleUtil.changeLocale(stored) }
            }
            settingsRepository.updateLocale(LocaleUtil.OPTION_PHONE_LANGUAGE)
        } else {
            withContext(Dispatchers.Main) { LocaleUtil.changeLocale(stored) }
        }
    }

    fun setPinLockEnabled(enabled: Boolean) = intent {
        if (!enabled) PinManager.clearPin()
        settingsRepository.updatePinLockEnabled(enabled)
    }

    fun stopTunnel(tunnelConfig: TunnelConfig) = intent {
        tunnelCoordinator.stopTunnel(tunnelConfig.id)
    }

    /**
     * Reconnect to the tunnel the user last used (persisted across
     * restarts); falls back to the first tunnel only when there is no
     * last-used one. Used by the hero Connect button after a disconnect.
     */
    fun startLastUsedTunnel() {
        viewModelScope.launch {
            val target =
                tunnelCoordinator.getLastUsedTunnel()
                    ?: tunnelRepository.userTunnelsFlow.firstOrNull()?.firstOrNull()
                    ?: return@launch
            startTunnel(target)
        }
    }

    fun setAppMode(mode: TunnelMode) = intent {
        if (mode == TunnelMode.VPN || mode == TunnelMode.LOCK_DOWN) {
            if (!serviceManager.hasVpnPermission()) {
                return@intent postSideEffect(GlobalSideEffect.RequestVpnPermission(mode, null))
            }
        }

        tunnelBackendCoordinator.changeMode(mode)
    }

    fun setShouldShowDonationSnackbar(to: Boolean) = intent {
        appStateRepository.setShouldShowDonationSnackbar(to)
    }

    fun setDesktopPromptShown(shown: Boolean) = intent {
        appStateRepository.setDesktopPromptShown(shown)
    }

    fun showSnackMessage(message: StringValue, type: ToastType) = intent {
        postGlobalSideEffect(GlobalSideEffect.Snackbar(message, type))
    }

    suspend fun postSideEffect(globalSideEffect: GlobalSideEffect) {
        globalEffectRepository.post(globalSideEffect)
    }

    fun authenticated() = appLockManager.unlock()

    suspend fun postGlobalSideEffect(sideEffect: GlobalSideEffect) {
        globalEffectRepository.post(sideEffect)
    }

    fun disableBatteryOptimizationsShown() = intent {
        appStateRepository.setBatteryOptimizationDisableShown(true)
    }

    fun enterReorderMode() = intent {
        val ui = tunnelsUiState.value
        clearSelectedTunnels()
        reorderDraft.value =
            ReorderDraft(
                tunnels = ui.tunnels,
                groups = ui.groups,
                scopeGroupId = null,
                originalTunnels = ui.tunnels,
                originalGroups = ui.groups,
            )
    }

    fun cancelReorder() = intent { reorderDraft.value = null }

    fun exitReorderScope() = intent {
        reorderDraft.update { draft -> draft?.copy(scopeGroupId = null, sortAscending = null) }
    }

    fun enterReorderScope(groupId: Int) = intent {
        reorderDraft.update { draft -> draft?.copy(scopeGroupId = groupId, sortAscending = null) }
    }

    fun applyReorderDraft(groups: List<TunnelGroup>, tunnels: List<TunnelConfig>) {
        reorderDraft.update { draft -> draft?.copy(groups = groups, tunnels = tunnels) }
    }

    fun saveReorder() = intent {
        val draft = reorderDraft.value ?: return@intent
        tunnelGroupRepository.saveAll(draft.groups)
        val changedTunnels = changedFrom(draft.originalTunnels, draft.tunnels)
        if (changedTunnels.isNotEmpty()) {
            // Stamp the fresh sort-by-ping latencies onto the rows
            // before the whole-row @Update: the draft tunnels predate
            // the ping, so saving them as-is would clobber the
            // persisted lastPingMs back to stale null — the same bug
            // as pingTunnels' reorder (user 22:05/22:06).
            val stamped =
                changedTunnels.map { it.copy(lastPingMs = draft.latencies[it.id] ?: it.lastPingMs) }
            tunnelRepository.updateAll(stamped)
        }
        reorderDraft.value = null
        postSideEffect(
            GlobalSideEffect.Snackbar(
                StringValue.StringResource(R.string.config_changes_saved),
                ToastType.Success,
            ),
        )
    }

    fun sortReorderByName() = intent {
        val draft = reorderDraft.value ?: return@intent
        val nextAscending =
            when (draft.sortAscending) {
                null -> true
                true -> false
                false -> null
            }
        if (nextAscending == null) {
            reorderDraft.value =
                draft.copy(
                    tunnels = draft.originalTunnels,
                    groups = draft.originalGroups,
                    sortAscending = null,
                )
            return@intent
        }
        val (groups, tunnels) =
            if (draft.scopeGroupId != null) {
                draft.groups to
                    sortGroupChildrenByName(draft.tunnels, draft.scopeGroupId, nextAscending)
            } else {
                sortRootByName(draft.groups, draft.tunnels, nextAscending)
            }
        reorderDraft.value =
            draft.copy(tunnels = tunnels, groups = groups, sortAscending = nextAscending)
    }

    fun sortReorderByLatency() = intent {
        val draft = reorderDraft.value ?: return@intent
        if (pingInFlight.value) return@intent
        pingInFlight.value = true
        postSideEffect(
            GlobalSideEffect.Snackbar(
                StringValue.StringResource(R.string.pinging_servers),
                ToastType.Info,
            ),
        )
        try {
            val scopeId = draft.scopeGroupId
            val targets =
                if (scopeId != null) draft.tunnels.filter { it.groupId == scopeId }
                else draft.tunnels.filter { it.groupId == null }
            if (targets.isNotEmpty()) _pingProgress.value = PingProgress(0, targets.size)
            val results = pingSorted(targets) { pinged, total ->
                _pingProgress.value = PingProgress(pinged, total)
            }
            val ordered = results.map { it.first }
            val tunnels =
                if (scopeId != null) {
                    val others = draft.tunnels.filter { it.groupId != scopeId }
                    others + ordered.mapIndexed { index, tunnel -> tunnel.copy(position = index) }
                } else {
                    val grouped = draft.tunnels.filter { it.groupId != null }
                    val slots =
                        draft.tunnels
                            .filter { it.groupId == null }
                            .sortedBy { it.position }
                            .map { it.position }
                    val rewritten = ordered.mapIndexed { index, tunnel ->
                        tunnel.copy(position = slots.getOrElse(index) { tunnel.position })
                    }
                    grouped + rewritten
                }
            val measured = results.associate { (tunnel, ms) -> tunnel.id to ms }
            reorderDraft.value =
                draft.copy(
                    tunnels = tunnels,
                    sortAscending = null,
                    latencies = draft.latencies + measured,
                )
            // Persist the last ping per tunnel so the row keeps showing
            // it after connecting / restarting (in-memory map clears).
            results.forEach { (tunnel, ms) -> tunnelRepository.setLastPingMs(tunnel.id, ms) }
            if (tunnelCoordinator.backendStatus.first().activeTunnels.isEmpty()) {
                pingLatencies.value = pingLatencies.value + measured
            }
        } finally {
            pingInFlight.value = false
            _pingProgress.value = null
        }
    }

    fun pingTunnels() = intent {
        if (pingInFlight.value) return@intent
        if (tunnelCoordinator.backendStatus.first().activeTunnels.isNotEmpty()) return@intent
        val allTunnels = tunnelRepository.userTunnelsFlow.first()
        // Scope (fix7): only the configs currently shown on screen —
        // the expanded groups' children + root tunnels, after search
        // + protocol filter. Nothing in a collapsed group or hidden
        // by a filter is pinged — or reordered — by this run. The
        // visible set is snapshotted here, so switching groups or
        // filters mid-ping cannot corrupt the run's counts.
        val visibleIds = _visibleTunnelIds.value
        val targets =
            if (visibleIds != null) allTunnels.filter { it.id in visibleIds }
            else allTunnels
        if (targets.isEmpty()) return@intent
        pingInFlight.value = true
        _pingProgress.value = PingProgress(0, targets.size)
        postSideEffect(
            GlobalSideEffect.Snackbar(
                StringValue.StringResource(R.string.pinging_servers),
                ToastType.Info,
            ),
        )
        try {
            val results = pingSorted(targets) { pinged, total ->
                _pingProgress.value = PingProgress(pinged, total)
            }
            // Reorder the list by ping (fix6 follow-up, user 13:56):
            // reachable servers first, by latency ascending, and
            // unreachable servers (Double.MAX_VALUE) at the END of the
            // list. Reordering is per scope — the root list and each
            // group separately — so group membership is untouched.
            // pingSorted already returns latency-ascending order with
            // unreachable last; positions just make the UI show it
            // (TunnelListRows sorts children by position).
            //
            // Fix9 — the fix7 "only reorder scopes this run FULLY
            // covered" guard is WHY unreachable configs never moved:
            // pinging from a filtered view (e.g. the WireGuard filter,
            // 186 of the 231 configs in that group) left every scope
            // partly covered, so NO positions were ever rewritten —
            // latencies were displayed but the order never changed
            // (user 17:35: 85ms, unreachable, 117ms, 123ms).
            // Partial scopes now reorder CORRECTLY instead of being
            // skipped: within each scope the new order is pinged
            // reachable (latency ascending) + unpinged (kept in their
            // current relative order) + pinged unreachable. Unpinged
            // members are never moved past each other and never
            // dropped — only the pinged members are sorted around
            // them — so a scoped run can never scramble hidden
            // tunnels, and unreachable always ends up last among
            // the configs that were actually pinged.
            val byScope = results.groupBy { it.first.groupId }
            val reordered = mutableListOf<TunnelConfig>()
            fun reorderScope(members: List<TunnelConfig>, scoped: List<Pair<TunnelConfig, Double>>) {
                if (members.isEmpty()) return
                val ordered = members.sortedBy { it.position }
                val pingedIds = scoped.map { it.first.id }.toSet()
                val reachable = scoped.filter { it.second < Double.MAX_VALUE }.map { it.first }
                val unreachable = scoped.filter { it.second == Double.MAX_VALUE }.map { it.first }
                val unpinged = ordered.filter { it.id !in pingedIds }
                val newOrder = reachable + unpinged + unreachable
                // Root positions are shared with group headers, so
                // root members reuse their existing slots; group
                // children are 0-based within their group.
                val slots =
                    if (members.first().groupId == null) ordered.map { it.position }
                    else newOrder.indices.toList()
                newOrder.forEachIndexed { index, tunnel ->
                    val newPosition = slots.getOrElse(index) { index }
                    if (tunnel.position != newPosition) {
                        reordered += tunnel.copy(position = newPosition)
                    }
                }
            }
            reorderScope(allTunnels.filter { it.groupId == null }, byScope[null].orEmpty())
            byScope.forEach { (groupId, scoped) ->
                if (groupId == null) return@forEach
                reorderScope(allTunnels.filter { it.groupId == groupId }, scoped)
            }
            if (reordered.isNotEmpty()) tunnelRepository.updateAll(reordered)
            // Persist the last ping per tunnel AFTER the position
            // rewrite above — NOT before it (user 22:05/22:06: pings
            // vanished the moment she connected). The rewrite saves
            // whole rows from the pre-run snapshot via Room @Update,
            // so persisting first got clobbered back to the stale
            // (null) lastPingMs for every tunnel whose position
            // moved; only unmoved tunnels kept a value, so the row's
            // persisted fallback was missing exactly for the moved
            // ones once the in-memory map cleared on connect.
            // Persisting last makes the DB the final state, so every
            // pinged tunnel keeps showing its last ping while
            // connected and after restart.
            results.forEach { (tunnel, ms) -> tunnelRepository.setLastPingMs(tunnel.id, ms) }
            if (tunnelCoordinator.backendStatus.first().activeTunnels.isEmpty()) {
                // Merge, don't replace: a scoped run must not wipe the
                // in-memory latencies of tunnels it did not ping.
                pingLatencies.value =
                    pingLatencies.value + results.associate { (tunnel, ms) -> tunnel.id to ms }
            }
        } finally {
            pingInFlight.value = false
            _pingProgress.value = null
        }
    }

    /**
     * Creates an empty group from the visible "Add group" entry on the
     * home screen — unlike createGroupAndMoveSelected it needs no
     * selected tunnels. The group lands at the top, expanded, with a
     * unique name; tunnels are moved into it from the selection actions.
     */
    fun createGroup(name: String) = intent {
        val ui = tunnelsUiState.value
        val unique = uniqueDisplayName(name, ui.groups.map { it.name }, "Group")
        // New groups land at the top
        val (shiftedGroups, shiftedTunnels) = shiftRootPositionsBy(ui.groups, ui.tunnels, 1)
        tunnelGroupRepository.saveAll(shiftedGroups)
        if (shiftedTunnels.isNotEmpty()) tunnelRepository.updateAll(shiftedTunnels)
        val groupId =
            tunnelGroupRepository.save(TunnelGroup(name = unique, position = 0, expanded = true))
        // The new group's chip appears in the top row at once AND the
        // user is taken into it (user 17:36): the list switches to
        // the new (empty) group so a config can be added straight
        // into it from the + button.
        applySelectedGroupFilter(groupId)
    }

    fun createGroupAndMoveSelected(name: String) = intent {
        val ui = tunnelsUiState.value
        val selected = selectedTunnelsForMove(ui)
        if (selected.isEmpty()) return@intent
        val unique = uniqueDisplayName(name, ui.groups.map { it.name }, "Group")
        // New groups land at the top
        val (shiftedGroups, shiftedTunnels) = shiftRootPositionsBy(ui.groups, ui.tunnels, 1)
        tunnelGroupRepository.saveAll(shiftedGroups)
        if (shiftedTunnels.isNotEmpty()) tunnelRepository.updateAll(shiftedTunnels)
        val groupId =
            tunnelGroupRepository.save(TunnelGroup(name = unique, position = 0, expanded = true))
        moveToGroup(groupId, selected, ui.tunnels)
        // Enter the new group at once, like createGroup.
        applySelectedGroupFilter(groupId)
    }

    fun renameGroup(group: TunnelGroup, name: String) = intent {
        val unique =
            uniqueDisplayName(
                name,
                tunnelsUiState.value.groups.filter { it.id != group.id }.map { it.name },
                "Group",
            )
        tunnelGroupRepository.save(group.copy(name = unique))
    }

    fun toggleGroupExpanded(group: TunnelGroup) = intent {
        tunnelGroupRepository.setExpanded(group.id, !group.expanded)
    }

    fun ungroup(group: TunnelGroup) = intent {
        val ui = tunnelsUiState.value
        val (groups, tunnels) = ungroupKeepingOrder(ui.groups, ui.tunnels, group.id)
        val changedTunnels = changedFrom(ui.tunnels, tunnels)
        if (changedTunnels.isNotEmpty()) tunnelRepository.updateAll(changedTunnels)
        tunnelGroupRepository.saveAll(groups)
        tunnelGroupRepository.delete(group)
        selectedTunnelsRepository.clear()
        // The group is gone — its chip is gone too, so the list
        // must fall back to All instead of filtering to a dead id.
        if (_selectedGroupId.value == group.id) applySelectedGroupFilter(null)
    }

    fun deleteGroupAndTunnels(group: TunnelGroup) = intent {
        val children = tunnelsUiState.value.tunnels.filter { it.groupId == group.id }
        val activeTunIds =
            tunnelCoordinator.backendStatus.firstOrNull()?.activeTunnels?.map { it.key }
        if (children.any { activeTunIds?.contains(it.id) == true })
            return@intent postSideEffect(
                GlobalSideEffect.Snackbar(
                    StringValue.StringResource(R.string.delete_active_message),
                    ToastType.Error,
                ),
            )
        if (children.isNotEmpty()) tunnelRepository.delete(children)
        tunnelGroupRepository.delete(group)
        selectedTunnelsRepository.clear()
        // The group is gone — its chip is gone too, so the list
        // must fall back to All instead of filtering to a dead id.
        if (_selectedGroupId.value == group.id) applySelectedGroupFilter(null)
    }

    fun moveSelectedToGroup(groupId: Int) = intent {
        val ui = tunnelsUiState.value
        val toMove = selectedTunnelsForMove(ui)
        if (toMove.isEmpty()) return@intent
        moveToGroup(groupId, toMove, ui.tunnels)
    }

    /**
     * The tunnels a Move-to-group acts on: the selected tunnels PLUS
     * the children of any selected group. Fix9: moving used to look
     * only at selected TUNNELS, so long-pressing a group header and
     * choosing Move moved nothing at all — the group's configs stayed
     * where they were while the user thought she had moved them.
     */
    private fun selectedTunnelsForMove(ui: TunnelsUiState): List<TunnelConfig> {
        val fromGroups =
            ui.selectedGroups.flatMap { group ->
                ui.tunnels.filter { it.groupId == group.id }
            }
        return (ui.selectedTunnels + fromGroups).distinctBy { it.id }
    }

    private fun changedFrom(
        before: List<TunnelConfig>,
        after: List<TunnelConfig>,
    ): List<TunnelConfig> {
        val beforeById = before.associateBy { it.id }
        return after.filter { tunnel ->
            val prior = beforeById[tunnel.id]
            prior == null || prior.position != tunnel.position || prior.groupId != tunnel.groupId
        }
    }

    private suspend fun moveToGroup(
        groupId: Int,
        selected: List<TunnelConfig>,
        all: List<TunnelConfig>,
    ) {
        var next = nextChildPosition(all, groupId)
        val ids = selected.map { it.id }.toSet()
        tunnelRepository.updateAll(
            all.filter { it.id in ids }.map { it.copy(groupId = groupId, position = next++) },
        )
        clearSelectedTunnels()
    }

    // Releases only the selected tunnels from their groups
    fun ungroupSelected() = intent {
        val ui = tunnelsUiState.value
        if (!ui.canUngroup) return@intent
        var next = nextRootPosition(ui.groups, ui.tunnels)
        val ids = ui.selectedTunnels.map { it.id }.toSet()
        val tunnels =
            ui.tunnels.filter { it.id in ids }.map { it.copy(groupId = null, position = next++) }
        if (tunnels.isNotEmpty()) tunnelRepository.updateAll(tunnels)
        clearSelectedTunnels()
    }

    fun exportGroup(group: TunnelGroup, uri: Uri?) = intent {
        val children = tunnelsUiState.value.tunnels.filter { it.groupId == group.id }
        if (children.isEmpty()) {
            postSideEffect(
                GlobalSideEffect.Snackbar(
                    StringValue.StringResource(R.string.no_tunnels_in_group),
                    ToastType.Warning,
                ),
            )
            return@intent
        }
        val (fileName, mimeType) = group.asExportFileName()
        postSideEffect(
            GlobalSideEffect.ExportFile(
                uri = uri,
                fileName = fileName,
                mimeType = mimeType,
                successMessage = StringValue.StringResource(R.string.export_success),
                prepareFile = { shareFile ->
                    // Always a zip, even for one tunnel, so the group name survives the export
                    fileUtils
                        .writeConfigArchive(shareFile, children.asArchiveEntries())
                        .getOrThrow()
                },
                onComplete = {},
            ),
        )
    }

    private suspend fun pingSorted(
        tunnels: List<TunnelConfig>,
        onProgress: ((pinged: Int, total: Int) -> Unit)? = null,
    ): List<Pair<TunnelConfig, Double>> {
        return withContext(Dispatchers.IO) {
            // Counts every completion (reachable or not) so the pill's
            // X/N counter is exact; AtomicInteger because the pings
            // finish concurrently on IO threads.
            val done = AtomicInteger(0)
            val total = tunnels.size
            tunnels
                .map { tunnel ->
                    async {
                        val config =
                            try {
                                tunnel.getConfig()
                            } catch (_: Exception) {
                                null
                            }
                        val endpoint =
                            tunnel.ovpnEndpointHost
                                ?: config?.peers?.firstOrNull()?.host
                        val latency =
                            if (endpoint != null) {
                                try {
                                    // 3 pings, a single dropped packet on an otherwise reachable
                                    // server would otherwise show as unreachable. Each tunnel is
                                    // pinged concurrently, so this doesn't multiply by tunnel count
                                    val stats = networkUtils.pingWithStats(endpoint, 3)
                                    if (stats.isReachable) {
                                        stats.rttAvg
                                    } else {
                                        // Many VPN servers block ICMP: a failed ping
                                        // must not mean "unreachable" when the server's
                                        // VPN port answers. For OpenVPN tunnels, fall
                                        // back to a TCP connect to host:port from the
                                        // .ovpn and use that for the latency + sort.
                                        tcpFallbackLatency(tunnel, endpoint)
                                            ?: Double.MAX_VALUE
                                    }
                                } catch (_: Exception) {
                                    tcpFallbackLatency(tunnel, endpoint) ?: Double.MAX_VALUE
                                }
                            } else {
                                Double.MAX_VALUE
                            }
                        tunnel to latency
                    }.also { deferred ->
                        deferred.invokeOnCompletion {
                            onProgress?.invoke(done.incrementAndGet(), total)
                        }
                    }
                }
                .awaitAll()
                .sortedBy { it.second }
        }
    }

    /**
     * TCP-connect latency for an OpenVPN tunnel whose server blocks ICMP:
     * time to open a TCP connection to the `remote` host:port from the
     * .ovpn (e.g. au2.shvpn.ch:1198). Null for WireGuard rows (no OVPN
     * port to connect to) and when the port refuses every attempt.
     */
    private suspend fun tcpFallbackLatency(tunnel: TunnelConfig, endpoint: String): Double? {
        if (!tunnel.isOpenVpn) return null
        val port = tunnel.ovpnEndpointPort ?: return null
        return networkUtils.tcpConnectLatency(endpoint, port)
    }

    fun importTunnelConfigs(configs: Map<QuickConfig, TunnelName>) = intent {
        try {
            val ui = tunnelsUiState.value
            // Import target (fix9, user 17:36): when a group is
            // entered (its chip selected), new configs land IN that
            // group — not at the root. Imports used to always land
            // at the root, so configs added right after creating a
            // group never appeared inside it.
            val targetGroupId = _selectedGroupId.value
            val tunnelConfigs =
                configs.entries.mapIndexed { index, (quick, name) ->
                    val config = Config.parseQuickString(quick)
                    config.validate()
                    // Group imports append at the end of the group;
                    // root imports keep landing at the top.
                    val position =
                        if (targetGroupId != null) {
                            nextChildPosition(ui.tunnels, targetGroupId) + index
                        } else {
                            index
                        }
                    TunnelConfig.fromConfig(config, name)
                        .copy(groupId = targetGroupId, position = position)
                }
            if (targetGroupId == null) {
                // New tunnels land at the top (root only)
                val (shiftedGroups, shiftedTunnels) =
                    shiftRootPositionsBy(ui.groups, ui.tunnels, tunnelConfigs.size)
                tunnelGroupRepository.saveAll(shiftedGroups)
                if (shiftedTunnels.isNotEmpty()) tunnelRepository.updateAll(shiftedTunnels)
            }
            tunnelRepository.saveTunnelsUniquely(tunnelConfigs, state.tunnelNames.map { it.value })
        } catch (e: Exception) {
            if (e is ConfigParseException) {
                postSideEffect(GlobalSideEffect.Snackbar(e.asStringValue(), ToastType.Error))
            } else {
                postSideEffect(
                    GlobalSideEffect.Snackbar(
                        StringValue.StringResource(R.string.config_error),
                        ToastType.Error,
                    ),
                )
            }
        }
    }

    fun importFromClipboard(conf: String) {
        importTunnelConfigs(mapOf(conf to null))
    }

    fun importFromQr(conf: String) = intent { importFromClipboard(conf) }

    fun promptWgImport(url: String) = intent { reduce { state.copy(pendingWgImportUrl = url) } }

    fun dismissWgImport() = intent { reduce { state.copy(pendingWgImportUrl = null) } }

    fun importFromUrl(url: String) = intent {
        reduce { state.copy(pendingWgImportUrl = null) }
        try {
            httpClient.prepareGet(url).execute { response ->
                if (response.status.value !in 200..299) {
                    throw IOException("Server returned error: ${response.status.value}")
                }

                val body = response.bodyAsText()

                val contentType = response.contentType()
                val isHtml =
                    (contentType?.match(ContentType.Text.Html) == true) ||
                        body.trimStart().let {
                            it.startsWith("<!DOCTYPE", ignoreCase = true) ||
                                it.startsWith("<html", ignoreCase = true)
                        }

                if (isHtml) {
                    postSideEffect(
                        GlobalSideEffect.Snackbar(
                            StringValue.StringResource(R.string.error_invalid_config_url),
                            ToastType.Error,
                        ),
                    )
                    return@execute
                }

                importFromClipboard(body)
            }
        } catch (e: Exception) {
            Timber.e(e)
            postSideEffect(
                GlobalSideEffect.Snackbar(
                    StringValue.StringResource(R.string.error_download_failed),
                    ToastType.Error,
                ),
            )
        }
    }

    fun importFromUri(uri: Uri) = intent {
        // Import target for the OpenVPN branch below (fix9): the
        // entered group, or the root when All is selected.
        val allTunnels = tunnelRepository.userTunnelsFlow.first()
        val targetGroupId = _selectedGroupId.value
        fileUtils
            .readFilesFromUri(uri)
            .onSuccess { files ->
                val siblings =
                    files.associate { it.name to it.text }
                val ovpnFiles =
                    files.filter {
                        it.name.lowercase().endsWith(FileUtils.OVPN_FILE_EXTENSION)
                    }
                val wgFiles =
                    files.filter {
                        val lower = it.name.lowercase()
                        lower.endsWith(FileUtils.CONF_FILE_EXTENSION) ||
                            lower.endsWith(FileUtils.AWG_FILE_EXTENSION)
                    }
                // WireGuard / AmneziaWG configs go through the existing
                // parser path. Names come from the file names with the
                // extension stripped (single files and zip entries alike).
                if (wgFiles.isNotEmpty()) {
                    importTunnelConfigs(
                        wgFiles.associate {
                            it.text to
                                it.name
                                    .removeSuffix(FileUtils.CONF_FILE_EXTENSION)
                                    .removeSuffix(FileUtils.AWG_FILE_EXTENSION)
                        },
                    )
                }
                // OpenVPN configs: parse + save the encrypted profile.
                // Sibling files (ca.crt, ta.key, …) are inlined from the
                // same zip by the coordinator.
                if (ovpnFiles.isNotEmpty()) {
                    val failures = mutableListOf<String>()
                    // Appended at the end of the entered group (or at
                    // the root as before when All is selected).
                    var nextPosition =
                        targetGroupId?.let { nextChildPosition(allTunnels, it) } ?: 0
                    ovpnFiles.forEach { file ->
                        openVpnCoordinator
                            .importOvpn(
                                name = file.name.removeSuffix(FileUtils.OVPN_FILE_EXTENSION),
                                text = file.text,
                                siblings = siblings,
                                groupId = targetGroupId,
                                position = nextPosition++,
                            )
                            .onFailure { error ->
                                failures +=
                                    "${file.name}: ${error.message ?: error::class.simpleName}"
                            }
                    }
                    if (failures.isNotEmpty()) {
                        postSideEffect(
                            GlobalSideEffect.Snackbar(
                                StringValue.StringResource(
                                    R.string.ovpn_import_failed,
                                    failures.joinToString("; "),
                                ),
                                ToastType.Error,
                            ),
                        )
                    }
                }
                if (ovpnFiles.isEmpty() && wgFiles.isEmpty()) {
                    postSideEffect(
                        GlobalSideEffect.Snackbar(
                            StringValue.StringResource(R.string.error_file_extension),
                            ToastType.Error,
                        ),
                    )
                }
            }
            .onFailure { error ->
                val message =
                    when {
                        // Broken Android TV and legacy pickers can return file:// without a read
                        // grant
                        error.isFileAccessDenied() ->
                            StringValue.StringResource(R.string.error_no_file_explorer)
                        error is IOException ->
                            StringValue.StringResource(R.string.error_download_failed)
                        else -> StringValue.StringResource(R.string.error_file_extension)
                    }
                postSideEffect(GlobalSideEffect.Snackbar(message, ToastType.Error))
            }
    }

    fun toggleSelectAllTunnels() = intent {
        val ui = tunnelsUiState.value
        // Fix9: "select all" used to select the FULL tunnel list even
        // while a filter / group / search was narrowing the screen —
        // so "select all" inside the OpenVPN filter actually selected
        // all 231 configs, and moving them put EVERYTHING into one
        // folder ("همه رفتن توی یه پوشه"). Select-all now means the
        // configs actually shown on screen (the same visible set the
        // ping run scopes to); hidden configs are never touched.
        val visibleIds = _visibleTunnelIds.value
        val visibleTunnels =
            if (visibleIds != null) ui.tunnels.filter { it.id in visibleIds } else ui.tunnels
        val allSelected =
            visibleTunnels.isNotEmpty() &&
                ui.selectedTunnels.size == visibleTunnels.size &&
                ui.selectedTunnels.containsAll(visibleTunnels)
        if (allSelected) {
            selectedTunnelsRepository.clear()
        } else {
            selectedTunnelsRepository.set(
                TunnelsSelection(tunnels = visibleTunnels, groups = emptyList()),
            )
        }
    }

    fun clearSelectedTunnels() = intent { selectedTunnelsRepository.clear() }

    fun toggleSelectedTunnel(tunnelId: Int) = intent {
        val ui = tunnelsUiState.value
        val selectedTuns =
            ui.selectedTunnels.toMutableList().apply {
                val removed = removeIf { it.id == tunnelId }
                if (!removed) addAll(ui.tunnels.filter { it.id == tunnelId })
            }
        selectedTunnelsRepository.set(
            TunnelsSelection(tunnels = selectedTuns, groups = ui.selectedGroups),
        )
    }

    fun toggleSelectedGroup(groupId: Int) = intent {
        val ui = tunnelsUiState.value
        val selectedGroups =
            ui.selectedGroups.toMutableList().apply {
                val removed = removeIf { it.id == groupId }
                if (!removed) addAll(ui.groups.filter { it.id == groupId })
            }
        selectedTunnelsRepository.set(
            TunnelsSelection(tunnels = ui.selectedTunnels, groups = selectedGroups),
        )
    }

    fun deleteSelectedTunnels() = intent {
        val ui = tunnelsUiState.value
        val activeTunIds =
            tunnelCoordinator.backendStatus.firstOrNull()?.activeTunnels?.map { it.key }.orEmpty() +
                listOfNotNull(openVpnCoordinator.activeTunnelId.value)
        val selectedTuns = ui.selectedTunnels
        if (selectedTuns.any { activeTunIds.contains(it.id) })
            return@intent postSideEffect(
                GlobalSideEffect.Snackbar(
                    StringValue.StringResource(R.string.delete_active_message),
                    ToastType.Error,
                ),
            )
        if (selectedTuns.isNotEmpty()) tunnelRepository.delete(selectedTuns)
        var groups = ui.groups
        val beforeUngroup = ui.tunnels.filter { tun -> selectedTuns.none { it.id == tun.id } }
        var tunnels = beforeUngroup
        ui.selectedGroups.forEach { group ->
            val result = ungroupKeepingOrder(groups, tunnels, group.id)
            groups = result.first
            tunnels = result.second
            tunnelGroupRepository.delete(group)
        }
        if (ui.selectedGroups.isNotEmpty()) {
            val changedTunnels = changedFrom(beforeUngroup, tunnels)
            if (changedTunnels.isNotEmpty()) tunnelRepository.updateAll(changedTunnels)
            tunnelGroupRepository.saveAll(groups)
        }
        clearSelectedTunnels()
    }

    fun copySelectedTunnel() = intent {
        // Fix9: copy used to duplicate only the FIRST selected
        // tunnel (firstOrNull) — selecting several configs and
        // hitting copy made a single copy. Now every selected
        // tunnel is copied, each right after its original, in the
        // same group. Positions are re-read per copy, because each
        // insert shifts the tunnels after it.
        val originals = tunnelsUiState.value.selectedTunnels.sortedBy { it.position }
        if (originals.isEmpty()) return@intent
        for (original in originals) {
            val ui = tunnelsUiState.value
            val current = ui.tunnels.firstOrNull { it.id == original.id } ?: continue
            if (current.isOpenVpn) {
                // An OpenVPN copy needs its own encrypted profile entry;
                // re-import the stored .ovpn text under a unique name.
                val (shiftedGroups, shiftedTunnels) =
                    shiftForInsertAfter(ui.groups, ui.tunnels, current.groupId, current.position)
                tunnelGroupRepository.saveAll(shiftedGroups)
                if (shiftedTunnels.isNotEmpty()) tunnelRepository.updateAll(shiftedTunnels)
                val imported =
                    openVpnCoordinator.importOvpn(
                        name = current.name,
                        text = current.ovpnText,
                        groupId = current.groupId,
                        position = current.position + 1,
                    )
                imported.onFailure {
                    postSideEffect(
                        GlobalSideEffect.Snackbar(
                            StringValue.StringResource(R.string.config_error),
                            ToastType.Error,
                        ),
                    )
                }
                // The copy inherits the original's saved credentials (via
                // the encrypted profile store — the stored .ovpn text no
                // longer carries inline credentials).
                val copied = imported.getOrNull()
                if (copied != null) {
                    openVpnCoordinator.copySavedCredentials(current, copied)
                }
            } else {
                val config = current.getConfig()
                // Placed right after the original, not appended to the end - shift everything after it
                // in the same scope (its group, or root) forward by one to open that slot.
                val (shiftedGroups, shiftedTunnels) =
                    shiftForInsertAfter(ui.groups, ui.tunnels, current.groupId, current.position)
                val copy =
                    TunnelConfig.fromConfig(config, current.name)
                        .copy(groupId = current.groupId, position = current.position + 1)
                tunnelGroupRepository.saveAll(shiftedGroups)
                if (shiftedTunnels.isNotEmpty()) tunnelRepository.updateAll(shiftedTunnels)
                tunnelRepository.saveTunnelsUniquely(listOf(copy), state.tunnelNames.map { it.value })
            }
        }
        clearSelectedTunnels()
    }

    fun exportSelectedTunnels(uri: Uri?) = intent {
        val ui = tunnelsUiState.value
        val selectedTunnels =
            (ui.selectedTunnels +
                    ui.selectedGroups.flatMap { group ->
                        ui.tunnels.filter { it.groupId == group.id }
                    })
                .distinctBy { it.id }
        if (selectedTunnels.isEmpty()) return@intent

        val (fileName, mimeType) = selectedTunnels.asFileExportName()
        postSideEffect(
            GlobalSideEffect.ExportFile(
                uri = uri,
                fileName = fileName,
                mimeType = mimeType,
                successMessage = StringValue.StringResource(R.string.export_success),
                prepareFile = { shareFile ->
                    if (selectedTunnels.size == 1) {
                        val tunnel = selectedTunnels.first()
                        if (tunnel.isOpenVpn) {
                            shareFile.writeText(tunnel.ovpnText)
                        } else {
                            shareFile.writeText(
                                ConfigArchive.withNameComment(tunnel.quickConfig, tunnel.name),
                            )
                        }
                        if (shareFile.length() == 0L) {
                            throw IOException("Failed to create config file")
                        }
                    } else if (selectedTunnels.any { it.isOpenVpn }) {
                        // Mixed WG + OpenVPN export: one zip, .conf entries
                        // for WireGuard and .ovpn entries for OpenVPN.
                        val entries =
                            selectedTunnels.map { tunnel ->
                                val ext =
                                    if (tunnel.isOpenVpn) FileUtils.OVPN_FILE_EXTENSION
                                    else FileUtils.CONF_FILE_EXTENSION
                                val fileName =
                                    tunnel.name
                                        .replace(Regex("[^a-zA-Z0-9._-]+"), "_") + ext
                                val content =
                                    if (tunnel.isOpenVpn) tunnel.ovpnText
                                    else tunnel.quickConfig
                                fileName to content
                            }
                        fileUtils.writeMixedConfigArchive(shareFile, entries).getOrThrow()
                    } else {
                        fileUtils
                            .writeConfigArchive(shareFile, selectedTunnels.asArchiveEntries())
                            .getOrThrow()
                    }
                },
                onComplete = { clearSelectedTunnels() },
            ),
        )
    }

    fun setScreenRecordingSecurity(to: Boolean) = intent {
        settingsRepository.updateScreenRecordingSecurity(to)
    }

    private fun Collection<TunnelConfig>.asArchiveEntries(): List<ConfigArchive.Entry> = filter {
        it.quickConfig.isNotBlank()
    }
        .map { ConfigArchive.Entry(it.name, it.quickConfig) }
}

private data class ReorderDraft(
    val tunnels: List<TunnelConfig>,
    val groups: List<TunnelGroup>,
    val scopeGroupId: Int?,
    val sortAscending: Boolean? = null,
    val originalTunnels: List<TunnelConfig>,
    val originalGroups: List<TunnelGroup>,
    val latencies: Map<Int, Double> = emptyMap(),
)

private data class TunnelsChrome(
    val loading: Boolean,
    val selectedTunCount: Int,
    val canMoveToGroup: Boolean,
    val isReorderMode: Boolean,
    val reorderScopeTitle: String?,
    val hasGroups: Boolean,
    val canReorder: Boolean,
    val hasActiveTunnel: Boolean,
    val openVpnTunnelIds: Set<Int> = emptySet(),
)
