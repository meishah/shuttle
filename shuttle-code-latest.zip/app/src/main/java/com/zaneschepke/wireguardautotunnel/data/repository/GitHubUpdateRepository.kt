package com.zaneschepke.wireguardautotunnel.data.repository

import android.os.Build
import com.zaneschepke.wireguardautotunnel.data.entity.Asset
import com.zaneschepke.wireguardautotunnel.data.entity.GitHubRelease
import com.zaneschepke.wireguardautotunnel.data.network.GitHubApi
import com.zaneschepke.wireguardautotunnel.domain.model.AppUpdate
import com.zaneschepke.wireguardautotunnel.domain.repository.UpdateRepository
import com.zaneschepke.wireguardautotunnel.util.NumberUtils
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import timber.log.Timber

class GitHubUpdateRepository(
    private val gitHubApi: GitHubApi,
    private val githubOwner: String,
    private val githubRepo: String,
    private val ioDispatcher: CoroutineDispatcher,
) : UpdateRepository {

    override suspend fun checkForUpdate(currentVersion: String): Result<AppUpdate?> =
        withContext(ioDispatcher) {
            // Guard: Shuttle may only ever offer its own releases. The
            // upstream WG Tunnel releases must NEVER be offered: installing
            // one would replace Shuttle with the real WG Tunnel app. If
            // this repository is ever wired to another owner/repo, the
            // check stays neutralized (always "no update") instead.
            if (githubOwner != SHUTTLE_OWNER || githubRepo != SHUTTLE_REPO) {
                Timber.w(
                    "Update check refused: repository is $githubOwner/$githubRepo, " +
                        "only $SHUTTLE_OWNER/$SHUTTLE_REPO may offer updates",
                )
                return@withContext Result.success(null)
            }

            // Latest stable release of meishah/shuttle (never "nightly",
            // never WG Tunnel's repo). Failures (no network, rate limit,
            // no release yet) propagate as Result.failure so the UI can
            // show the check-failed message instead of staying silent.
            val release = gitHubApi.getLatestRelease(githubOwner, githubRepo).getOrElse {
                return@withContext Result.failure(it)
            }
            val releaseVersion = release.tagName.trim().removePrefix("v").removePrefix("V")
            if (NumberUtils.compareVersions(releaseVersion, currentVersion) <= 0) {
                Timber.i("Already up to date (current=$currentVersion, latest=$releaseVersion)")
                return@withContext Result.success(null)
            }

            val apk = pickApkAsset(release)
            if (apk == null) {
                // A newer release exists but publishes no standalone APK
                // asset (e.g. only a zip of APKs). Still report the update
                // with no download URL: the dialog shows the new version
                // with a link to the release page, and a download attempt
                // reports failure instead of fetching the wrong file.
                Timber.i(
                    "Update $releaseVersion available but release has no APK asset " +
                        "(current=$currentVersion)",
                )
            } else {
                Timber.i(
                    "Update available: $releaseVersion (current=$currentVersion, " +
                        "asset=${apk.name})",
                )
            }
            Result.success(
                AppUpdate(
                    version = releaseVersion,
                    releaseUrl = release.htmlUrl,
                    apkUrl = apk?.browserDownloadUrl,
                    apkFileName = apk?.name,
                    apkSize = apk?.size?.takeIf { it > 0 },
                ),
            )
        }

    /**
     * Release APKs are named shuttle-standalone-v<version>[-arm64|-armv7].apk.
     * Prefer the build for this device's ABI, then the universal build
     * (no ABI marker), then any single APK in the release.
     */
    private fun pickApkAsset(release: GitHubRelease): Asset? {
        val apks = release.assets.filter { it.name.endsWith(".apk", ignoreCase = true) }
        if (apks.isEmpty()) return null
        if (apks.size == 1) return apks.first()
        val abis = Build.SUPPORTED_ABIS.toList()
        val abiAsset =
            when {
                "arm64-v8a" in abis -> apks.firstOrNull { "-arm64" in it.name }
                "armeabi-v7a" in abis ->
                    apks.firstOrNull { "-armv7" in it.name || "-armeabi" in it.name }
                "x86_64" in abis -> apks.firstOrNull { "-x64" in it.name }
                "x86" in abis -> apks.firstOrNull { "-x86" in it.name }
                else -> null
            }
        if (abiAsset != null) return abiAsset
        return apks.firstOrNull { asset ->
            ABI_MARKERS.none { it in asset.name }
        }
            ?: apks.first()
    }

    companion object {
        // The only repository Shuttle may offer updates from.
        const val SHUTTLE_OWNER = "meishah"
        const val SHUTTLE_REPO = "shuttle"

        private val ABI_MARKERS = listOf("-arm64", "-armv7", "-armeabi", "-x86", "-x64")
    }
}
