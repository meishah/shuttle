package com.zaneschepke.wireguardautotunnel.data.repository

import com.zaneschepke.wireguardautotunnel.data.network.GitHubApi
import com.zaneschepke.wireguardautotunnel.domain.model.AppUpdate
import com.zaneschepke.wireguardautotunnel.domain.repository.UpdateRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import timber.log.Timber

class GitHubUpdateRepository(
    private val gitHubApi: GitHubApi,
    private val githubOwner: String,
    private val githubRepo: String,
    private val ioDispatcher: CoroutineDispatcher,
) : UpdateRepository {

    override suspend fun checkForUpdate(currentVersion: String): Result<AppUpdate?> =
        withContext(ioDispatcher) {
            // Shuttle has no update feed of its own yet, and the upstream
            // WG Tunnel releases must NEVER be offered: installing one
            // would replace Shuttle with the real WG Tunnel app. So the
            // check is neutralized for now (always "no update") while the
            // surrounding structure (repository, worker, dialog, download)
            // stays in place for a Shuttle-owned update link later.
            Timber.i("Update check disabled: Shuttle has no update feed yet (current=$currentVersion)")
            Result.success(null)
        }
}
