package com.zaneschepke.wireguardautotunnel.ui.common.text

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun DescriptionText(
    text: String,
    modifier: Modifier = Modifier,
    disabled: Boolean = false,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    Text(
        text = text,
        style =
            MaterialTheme.typography.bodySmall.copy(
                // Default description colour is onSurfaceVariant,
                // never outline: in light, outline #7A8CA0 was
                // 2.80:1 on the settings cards — unreadable (user
                // 2026-11-27, light-theme audit). One change here
                // fixes all 84 DescriptionText call sites. Disabled
                // text renders the same: the old 0.4-alpha Disabled
                // grey was ~2:1 on the dark card and ~1.5:1 in
                // light. The `disabled` parameter is kept for the
                // call sites; it no longer dims the text.
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
        modifier = modifier,
        maxLines = maxLines,
        overflow = overflow,
    )
}

@Composable
fun DescriptionText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    disabled: Boolean = false,
) {
    Text(
        text = text,
        style =
            MaterialTheme.typography.bodySmall.copy(
                // Same as above: onSurfaceVariant for description
                // text, never outline (user 2026-11-27, light-theme
                // audit). Disabled renders the same, never dimmed.
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
        modifier = modifier,
    )
}
