package com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.overscroll
import androidx.compose.foundation.rememberOverscrollEffect
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.ui.common.LocalShuttleCardColor
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.scroll.appScrollbar
import com.zaneschepke.wireguardautotunnel.ui.common.shuttleSettingsCardColor
import com.zaneschepke.wireguardautotunnel.ui.common.textbox.ConfigurationTextBox

@Composable
fun TunnelPickerList(
    tunnels: List<TunnelConfig>,
    isSelected: (TunnelConfig) -> Boolean,
    onSelect: (TunnelConfig) -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
    leadingItem: (@Composable () -> Unit)? = null,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered =
        remember(tunnels, query) { tunnels.filter { it.name.contains(query, ignoreCase = true) } }

    val lazyListState = rememberLazyListState()
    val cardColor = shuttleSettingsCardColor()

    Column(modifier = modifier.fillMaxSize()) {
        ConfigurationTextBox(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
            value = query,
            onValueChange = { query = it },
            label = stringResource(R.string.search),
            hint = stringResource(R.string.search),
            trailing = { Icon(Icons.Outlined.Search, contentDescription = null) },
        )
        // The list sits inside one big rounded card, like the other
        // settings lists; rows are transparent so the card's flat
        // colour shows through.
        Box(
            modifier =
                Modifier.fillMaxSize()
                    .padding(start = 16.dp, end = 16.dp, bottom = 140.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(cardColor),
        ) {
            CompositionLocalProvider(LocalShuttleCardColor provides cardColor) {
                LazyColumn(
                    state = lazyListState,
                    modifier =
                        Modifier.fillMaxSize()
                            .overscroll(rememberOverscrollEffect())
                            .appScrollbar(
                                lazyListState.scrollIndicatorState,
                                Orientation.Vertical,
                            ),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp),
                    verticalArrangement = Arrangement.Top,
                    flingBehavior = ScrollableDefaults.flingBehavior(),
                ) {
                    if (leadingItem != null) {
                        item { leadingItem() }
                        if (filtered.isNotEmpty()) {
                            item { ShuttleSettingsDivider() }
                        }
                    }
                    itemsIndexed(filtered, key = { _, it -> it.id }) { index, tunnel ->
                        val selected = isSelected(tunnel)
                        SurfaceRow(
                            leading = leading,
                            title = tunnel.name,
                            trailing = {
                                if (selected) {
                                    Icon(
                                        Icons.Outlined.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            },
                            onClick = { onSelect(tunnel) },
                            containerColor = Color.Transparent,
                        )
                        if (index < filtered.size - 1) {
                            ShuttleSettingsDivider()
                        }
                    }
                }
            }
        }
    }
}
