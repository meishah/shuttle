package com.zaneschepke.wireguardautotunnel.notification

import android.app.Notification

interface TunnelNotificationService {

    fun buildVpnPersistentNotification(
        tunnelNotificationLines: Map<Int, TunnelNotificationLine>,
        options: TunnelNotificationOptions,
        lockdown: Boolean = false,
    ): Notification

    fun buildProxyPersistentNotification(
        tunnelNotificationLines: Map<Int, TunnelNotificationLine>,
        options: TunnelNotificationOptions,
    ): Notification

    fun showIpv4Fallback(tunnelName: String)

    fun showIpv6Recovery(tunnelName: String)

    fun showDynamicDnsUpdate(tunnelName: String)

    fun showSeamlessRecoveryAttempt(tunnelName: String)

    fun showVpnRequired()

    fun showSocks5PortUnavailable(port: Int, tunnelName: String)

    fun showHttpPortUnavailable(port: Int, tunnelName: String)

    fun showConfigMissingDns(tunnelName: String)

    fun showRootShellAccess()

    fun showError(message: String)
}
