package com.zaneschepke.wireguardautotunnel.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.ui.screens.tunnels.components.isLightShuttleTheme
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavender
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavenderContainer
import com.zaneschepke.wireguardautotunnel.ui.theme.OrionLavenderDeep
import com.zaneschepke.wireguardautotunnel.ui.theme.TileDark
import com.zaneschepke.wireguardautotunnel.ui.theme.TileLight

/**
 * Shuttle's Settings / About styling (Material 3 Expressive, user
 * 2026-11-24, approved preview): settings are grouped into big
 * rounded cards — one flat colour per theme, exactly like the config
 * tiles (dark #262638, light white) — with a small muted section
 * label above each card, a tinted squircle behind every row icon,
 * and lime switches while on.
 */

/** Card colour — the same flat colour as the config tiles. */
@Composable
fun shuttleSettingsCardColor(): Color =
    if (isLightShuttleTheme()) TileLight else TileDark

/** Muted section-label colour, readable on the screen background. */
@Composable
fun shuttleSettingsLabelColor(): Color =
    if (isLightShuttleTheme()) Color(0xFF6B6B80) else Color(0xFF9A97B8)

/**
 * The card colour, for content drawn inside a settings card that
 * needs to match it — e.g. ConfigurationTextBox's label notch, which
 * sits on the card background above the field. Unspecified outside
 * a card (falls back to the surface colour).
 */
val LocalShuttleCardColor = compositionLocalOf { Color.Unspecified }

/** Big rounded card holding a group of settings rows. */
@Composable
fun ShuttleSettingsCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cardColor = shuttleSettingsCardColor()
    Column(
        modifier =
            modifier
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(cardColor),
    ) {
        CompositionLocalProvider(LocalShuttleCardColor provides cardColor) {
            content()
        }
    }
}

/**
 * Card holding a group of text fields (Amnezia / config edit):
 * same flat colour and corners as a settings card, with 16dp inner
 * padding and 12dp between fields.
 */
@Composable
fun ShuttleSettingsFieldCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    ShuttleSettingsCard(modifier) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
        ) {
            content()
        }
    }
}

/** Thin divider between rows inside a settings card. */
@Composable
fun ShuttleSettingsDivider() {
    Box(
        modifier =
            Modifier.fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(1.dp)
                .background(
                    if (isLightShuttleTheme()) Color(0xFFD3CFE6) else Color(0xFF34344A),
                ),
    )
}

/** Small muted section label above a settings card. */
@Composable
fun ShuttleSettingsLabel(title: String, modifier: Modifier = Modifier) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = shuttleSettingsLabelColor(),
        modifier = modifier.padding(horizontal = 16.dp),
    )
}

/**
 * Row icon in a tinted squircle (38dp, 12dp corners) — lavender icon
 * on a lavender-tinted tile, matching the config-tile look.
 */
@Composable
fun ShuttleSettingIcon(icon: ImageVector, contentDescription: String? = null) {
    val isLight = isLightShuttleTheme()
    Box(
        modifier =
            Modifier.size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isLight) Color(0xFFE9E7FB) else OrionLavenderContainer,
                ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (isLight) OrionLavenderDeep else OrionLavender,
            modifier = Modifier.size(20.dp),
        )
    }
}
