package com.zaneschepke.wireguardautotunnel.core.openvpn

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import de.blinkt.openvpn.LaunchVPN
import de.blinkt.openvpn.VpnProfile
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.PasswordCache
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.ShuttleOpenVpn
import de.blinkt.openvpn.core.VpnStatus
import de.blinkt.openvpn.core.ConnectionStatus
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.domain.model.TunnelConfig
import com.zaneschepke.wireguardautotunnel.domain.repository.TunnelRepository
import com.zaneschepke.wireguardautotunnel.service.tile.TunnelTileRefresher
import java.io.StringReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import timber.log.Timber
import java.net.HttpURLConnection
import java.net.URL

/**
 * Shuttle's OpenVPN side: import, connect, status, auto-reconnect.
 *
 * WireGuard/AmneziaWG tunnels are handled by TunnelCoordinator; this
 * coordinator owns ONLY OpenVPN rows (TunnelConfig.isOpenVpn). The
 * OpenVPN core itself (ics-openvpn 0.7.69, :openvpn module) runs in the
 * :openvpn process; this class talks to it through ProfileManager (the
 * encrypted profile store — profiles are saved with ProfileEncryption,
 * i.e. an Android-Keystore-backed key, never as plaintext) and through
 * [ShuttleOpenVpn] (status bridge).
 *
 * Connected-state rule: [state] is Connected ONLY when the core reports
 * LEVEL_CONNECTED. A connect tap never flips the state — the bridge
 * reports the real tunnel state.
 */
sealed interface OpenVpnState {
    data object Disconnected : OpenVpnState
    data class Connecting(val message: String) : OpenVpnState
    data class Connected(
        val bytesIn: Long,
        val bytesOut: Long,
        val connectedAtMs: Long,
        val ip: String? = null,
        val country: String? = null,
    ) : OpenVpnState

    data class WaitingForInput(val need: String) : OpenVpnState
    data object AuthFailed : OpenVpnState
    data class Error(val message: String) : OpenVpnState
}

class OpenVpnCoordinator(
    private val appContext: Context,
    private val tunnelRepository: TunnelRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow<OpenVpnState>(OpenVpnState.Disconnected)
    val state: StateFlow<OpenVpnState> = _state.asStateFlow()

    private val _activeTunnelId = MutableStateFlow<Int?>(null)
    val activeTunnelId: StateFlow<Int?> = _activeTunnelId.asStateFlow()

    @Volatile
    private var userStopped = false

    @Volatile
    private var activeConfig: TunnelConfig? = null

    private var reconnectJob: Job? = null
    private var reconnectAttempts = 0
    private var connectedAtMs = 0L
    private var ipFetchedForUuid: String? = null

    /**
     * Durable OVPN password store (see OvpnPasswordStore): the password
     * used to live only on the serialized profile, keyed by a UUID that
     * changes on every reparse — so profile rebuilds/pruning silently
     * dropped it while the username survived (it is also in the DB).
     * Lazily created from appContext; its init is failure-tolerant.
     */
    private val passwordStore by lazy { OvpnPasswordStore(appContext) }

    /**
     * True once the tunnel reached LEVEL_CONNECTED in the current
     * attempt. Auto-reconnect is ONLY for a tunnel that was up and
     * then dropped — a start that never connected must fail ONCE and
     * stay failed (fix8: the crash loop relaunched failed starts
     * forever — coordinator retries + sticky service restarts + the
     * keep-alive job — while the user was not even touching the app).
     */
    private var everConnectedThisAttempt = false

    /**
     * Watchdog: the core must report *something* (any state change) within
     * [WATCHDOG_TIMEOUT_MS] of a connect, or the UI would sit at
     * "Connecting..." forever when the service never starts or dies
     * silently. Any bridge callback re-arms it; only total silence
     * from the core trips it.
     */
    private var watchdogJob: Job? = null

    private fun armWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = scope.launch {
            delay(WATCHDOG_TIMEOUT_MS)
            if (_state.value is OpenVpnState.Connecting) {
                Timber.w("OpenVPN watchdog: no core state for ${WATCHDOG_TIMEOUT_MS}ms")
                watchdogJob = null
                disarmDeadline()
                // The core never responded: do not auto-reconnect a dead
                // core, and do not leave the UI on "Connecting...".
                userStopped = true
                generation++
                _state.value = OpenVpnState.Error(
                    appContext.getString(R.string.ovpn_no_response),
                )
                _activeTunnelId.value = null
                activeConfig = null
                ShuttleOpenVpn.stopVpn(appContext)
            }
        }
    }

    private fun disarmWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = null
    }

    /**
     * Hard connect deadline (user 21:26 — the frozen hero): the 45s
     * watchdog above only fires when the core goes SILENT, but a
     * failing core RETRIES — `connect-retry 2 300` with
     * connect-retry-max "-1" (unlimited) — emitting a STATE change
     * every few seconds, and every one of those re-arms the watchdog
     * ("any word from the core is progress"). So a dead server kept
     * the hero on "Connecting..." for up to 300s per config, and
     * tapping config after config just restarted the clock — the tile
     * looked frozen/locked until she force-closed the app. The
     * deadline is a TOTAL bound from the start of the attempt: retry
     * chatter cannot extend it. It also bounds WaitingForInput (the
     * credentials prompt), which disarms the watchdog and otherwise
     * waits forever if the prompt never appears. A legit slow
     * connect has 120s; the user can always tap Connect again.
     */
    private var deadlineJob: Job? = null

    private fun armDeadline() {
        deadlineJob?.cancel()
        deadlineJob = scope.launch {
            delay(CONNECT_DEADLINE_MS)
            val current = _state.value
            if (current is OpenVpnState.Connecting ||
                current is OpenVpnState.WaitingForInput
            ) {
                Timber.w(
                    "OpenVPN connect deadline hit after ${CONNECT_DEADLINE_MS}ms in $current",
                )
                deadlineJob = null
                userStopped = true
                generation++
                _state.value = OpenVpnState.Error(
                    appContext.getString(R.string.ovpn_no_response),
                )
                _activeTunnelId.value = null
                activeConfig = null
                ShuttleOpenVpn.stopVpn(appContext)
            }
        }
    }

    private fun disarmDeadline() {
        deadlineJob?.cancel()
        deadlineJob = null
    }

    /**
     * Bumped on every start()/stop() so a delayed auto-reconnect from an
     * earlier connection can never fire after the user switched tunnels.
     */
    private var generation = 0

    /**
     * True once the most recent stop()'s core death has been confirmed
     * by a LEVEL_NOTCONNECTED callback. stop() clears it; the callback
     * — or a new start, which supersedes the pending stop — sets it
     * again. The coordinator waits on this before starting the next
     * tunnel, so a switch never starts the new core while the old one
     * is still dying.
     */
    private val _stopConfirmed = MutableStateFlow(true)
    val stopConfirmed: StateFlow<Boolean> = _stopConfirmed.asStateFlow()

    /**
     * Generation of the stop() whose core death is still unconfirmed,
     * and when it was issued (elapsedRealtime). A stop older than
     * [STALE_STOP_WINDOW_MS] is treated as settled: its core is long
     * dead (or never ran), so a later NOTCONNECTED cannot be its death.
     */
    @Volatile
    private var pendingStopGeneration: Int? = null

    @Volatile
    private var pendingStopAtMs: Long = 0L

    /** Generation and start time of the current connect attempt. */
    @Volatile
    private var attemptGeneration: Int = -1

    @Volatile
    private var attemptStartedAtMs: Long = 0L

    /** Call once from the Application after Koin starts. */
    fun bind() {
        ShuttleOpenVpn.init(appContext)
        ShuttleOpenVpn.addStateListener { bridgeState ->
            onBridgeState(bridgeState)
        }
        // If the :openvpn process was already running (e.g. after a
        // process restart), reflect its current state.
        onBridgeState(ShuttleOpenVpn.getCurrentState())
    }

    private fun onBridgeState(bridge: ShuttleOpenVpn.State) {
        val previous = _state.value
        // Any word from the core is progress: re-arm the watchdog while
        // still connecting; terminal states disarm it below.
        if (previous is OpenVpnState.Connecting) armWatchdog()
        when (bridge.level) {
            ConnectionStatus.LEVEL_CONNECTED -> {
                disarmWatchdog()
                disarmDeadline()
                everConnectedThisAttempt = true
                if (connectedAtMs == 0L) connectedAtMs = System.currentTimeMillis()
                reconnectAttempts = 0
                reconnectJob?.cancel()
                val connected = OpenVpnState.Connected(
                    bytesIn = bridge.bytesIn,
                    bytesOut = bridge.bytesOut,
                    connectedAtMs = connectedAtMs,
                    ip = (previous as? OpenVpnState.Connected)?.ip,
                    country = (previous as? OpenVpnState.Connected)?.country,
                )
                _state.value = connected
                maybeFetchIpCountry(bridge.connectedUuid)
                TunnelTileRefresher.refresh(appContext)
            }
            ConnectionStatus.LEVEL_WAITING_FOR_USER_INPUT -> {
                disarmWatchdog()
                val need = bridge.message.removePrefix("need ").trim()
                    .ifEmpty { "Auth" }
                _state.value = OpenVpnState.WaitingForInput(need)
            }
            ConnectionStatus.LEVEL_AUTH_FAILED -> {
                disarmWatchdog()
                disarmDeadline()
                _state.value = OpenVpnState.AuthFailed
                // Wrong credentials: never auto-retry.
                reconnectJob?.cancel()
                if (_activeTunnelId.value != null && userStopped.not()) {
                    // Keep the tunnel marked active so the user can fix the
                    // credentials and retry; do not clear on auth failure.
                }
            }
            ConnectionStatus.LEVEL_NOTCONNECTED -> {
                // Whatever stop was pending, this callback confirms the
                // old core died.
                _stopConfirmed.value = true
                val stale = isStaleNotConnected()
                pendingStopGeneration = null
                if (stale) {
                    // Death of the PREVIOUS core, arriving after a NEW
                    // attempt started (switch): it must not clobber
                    // the new attempt's Connecting state, clear its
                    // active id, or disarm its watchdog/deadline —
                    // the new attempt owns all of those now. The
                    // 120s connect deadline stays the backstop if the
                    // new attempt itself never comes up.
                    Timber.w(
                        "OpenVPN: ignoring stale NOTCONNECTED from previous core " +
                            "(attempt generation $attemptGeneration)",
                    )
                } else {
                    disarmWatchdog()
                    disarmDeadline()
                    connectedAtMs = 0L
                    ipFetchedForUuid = null
                    val wasActive = _activeTunnelId.value != null
                    // stop() now clears the active id immediately (21:26
                    // frozen hero), so wasActive is false after a user
                    // stop — but a disconnect still has to refresh the
                    // Quick Settings tile when the tunnel WAS up.
                    val wasConnected = previous is OpenVpnState.Connected
                    // The new attempt's core gave up without ever
                    // connecting: say so clearly instead of silently
                    // showing Disconnected (a switch whose new config
                    // fails must not look like a plain disconnect). A
                    // user stop, and a drop after connect, keep
                    // Disconnected.
                    val attemptFailed = wasActive && !userStopped &&
                        !everConnectedThisAttempt &&
                        previous is OpenVpnState.Connecting
                    if (attemptFailed) {
                        _state.value = OpenVpnState.Error(
                            appContext.getString(R.string.ovpn_no_response),
                        )
                        _activeTunnelId.value = null
                        activeConfig = null
                    } else if (previous !is OpenVpnState.Error) {
                        // A late NOTCONNECTED must not downgrade an
                        // Error the watchdog/deadline already reported.
                        _state.value = OpenVpnState.Disconnected
                    }
                    if (wasActive || wasConnected) {
                        TunnelTileRefresher.refresh(appContext)
                    }
                    if (wasActive && !userStopped) {
                        maybeAutoReconnect()
                    } else if (userStopped) {
                        _activeTunnelId.value = null
                        activeConfig = null
                    }
                }
            }
            else -> {
                if (_activeTunnelId.value != null) {
                    _state.value = OpenVpnState.Connecting(bridge.message)
                }
            }
        }
    }

    /**
     * True when this NOTCONNECTED is the death of the PREVIOUS core
     * arriving after a NEW attempt started (a switch): a stop is still
     * unconfirmed, the current attempt began after that stop, and the
     * attempt is fresh — a new core cannot genuinely fail this fast
     * (it must launch and exhaust its connect retries first), while
     * the old core's death, if it is coming, lands promptly after the
     * stop. A genuine failure of the new attempt is therefore never
     * swallowed for more than the attempt window.
     */
    private fun isStaleNotConnected(): Boolean {
        val stopGeneration = pendingStopGeneration ?: return false
        if (attemptGeneration <= stopGeneration) return false
        return SystemClock.elapsedRealtime() - attemptStartedAtMs <
            STALE_NOTCONNECTED_WINDOW_MS
    }

    private fun maybeAutoReconnect() {
        val config = activeConfig ?: return
        // Fix8: a start that never reached CONNECTED must NEVER be
        // retried — retrying a failed start is what kept relaunching
        // the crashing OpenVPN attempt (up to 5 coordinator retries
        // on top of the sticky service restarts). Fail once, stay
        // failed, until the user taps again. Auto-reconnect stays
        // for its real purpose: a tunnel that WAS up and then dropped.
        if (!everConnectedThisAttempt) {
            _activeTunnelId.value = null
            activeConfig = null
            return
        }
        if (!config.autoReconnect) {
            _activeTunnelId.value = null
            activeConfig = null
            return
        }
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            Timber.w("OpenVPN auto-reconnect gave up after $MAX_RECONNECT_ATTEMPTS attempts")
            _activeTunnelId.value = null
            activeConfig = null
            return
        }
        reconnectJob?.cancel()
        val delayMs = RECONNECT_BASE_DELAY_MS shl reconnectAttempts
        reconnectAttempts++
        val capturedGeneration = generation
        reconnectJob = scope.launch {
            delay(delayMs)
            if (generation == capturedGeneration && !userStopped &&
                _activeTunnelId.value != null
            ) {
                Timber.i("OpenVPN auto-reconnect attempt $reconnectAttempts")
                startInternal(config)
            }
        }
    }

    /** One-shot public-IP + country lookup, only while connected. */
    private fun maybeFetchIpCountry(uuid: String?) {
        if (uuid == null || uuid == ipFetchedForUuid) return
        ipFetchedForUuid = uuid
        scope.launch(Dispatchers.IO) {
            try {
                val url = URL("https://ip-api.com/json/?fields=status,query,country")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 6000
                    setRequestProperty("Accept", "application/json")
                }
                val body = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val json = JSONObject(body)
                if (json.optString("status") == "success") {
                    val ip = json.optString("query").takeIf { it.isNotEmpty() }
                    val country = json.optString("country").takeIf { it.isNotEmpty() }
                    val current = _state.value
                    if (current is OpenVpnState.Connected) {
                        _state.value = current.copy(ip = ip, country = country)
                    }
                }
            } catch (e: Exception) {
                // Best effort only: no retry loop, no polling (battery).
                Timber.d("IP/country lookup failed: ${e.message}")
            }
        }
    }

    /**
     * Import a raw .ovpn file. [siblings] maps bare filenames (from the
     * same ZIP) to their contents, so `ca foo.crt` style references can
     * be inlined. Returns the saved TunnelConfig on success.
     */
    suspend fun importOvpn(
        name: String,
        text: String,
        siblings: Map<String, String> = emptyMap(),
        groupId: Int? = null,
        position: Int = 0,
    ): Result<TunnelConfig> = withContext(Dispatchers.IO) {
        runCatching {
            // Provider files are often Windows CRLF with a UTF-8 BOM;
            // the BOM would otherwise corrupt the first directive.
            val cleanText = text.removePrefix("\uFEFF")
            val inlined = inlineExternalFiles(cleanText, siblings)
            // A .ovpn that still references external files we do not
            // have (a lone .ovpn next to its ca.crt, …) would parse
            // fine but could never connect — fail now with a message
            // that says which files are missing.
            val missing = missingExternalFiles(inlined)
            if (missing.isNotEmpty()) {
                throw IllegalStateException(
                    appContext.getString(
                        R.string.ovpn_missing_files,
                        missing.joinToString(", "),
                    ),
                )
            }
            val profile = parseProfile(inlined, name)
            // Credentials from a sibling auth file in the same ZIP
            // (auth-user-pass login.txt): onto the encrypted profile,
            // never into the stored .ovpn text.
            authFileCredentials(cleanText, siblings)?.let { (username, password) ->
                profile.mUsername = username
                profile.mPassword = password
            }
            // Credentials embedded in the file (auth-user-pass file or
            // inline block) land on the profile here; anything missing is
            // asked for at connect time via the user-input prompt.
            ProfileManager.saveProfile(appContext, profile)
            val uniqueName = uniqueTunnelName(name)
            val config = TunnelConfig(
                name = uniqueName,
                isOpenVpn = true,
                ovpnUuid = profile.uuidString,
                // Inline credential blocks are stripped from the stored
                // text (the credentials live on the encrypted profile);
                // a bare auth-user-pass line is kept so a rebuilt
                // profile still asks for credentials at connect time.
                ovpnText = stripInlineAuthUserPass(inlined),
                ovpnUsername = profile.mUsername ?: "",
                groupId = groupId,
                position = position,
            )
            tunnelRepository.save(config)
            tunnelRepository.findByTunnelName(uniqueName)
                ?: config
        }
    }

    /** Re-parse the stored .ovpn text and (re)save the profile. */
    suspend fun updateOvpnText(config: TunnelConfig, newText: String): Result<TunnelConfig> =
        withContext(Dispatchers.IO) {
            runCatching {
                val cleanText = newText.removePrefix("\uFEFF")
                val missing = missingExternalFiles(cleanText)
                if (missing.isNotEmpty()) {
                    throw IllegalStateException(
                        appContext.getString(
                            R.string.ovpn_missing_files,
                            missing.joinToString(", "),
                        ),
                    )
                }
                val profile = parseProfile(cleanText, config.name)
                // Preserve saved credentials across edits.
                val old = config.ovpnUuid?.let { ProfileManager.get(appContext, it) }
                if (old != null) {
                    if (profile.mUsername.isNullOrEmpty()) profile.mUsername = old.mUsername
                    if (profile.mPassword.isNullOrEmpty()) profile.mPassword = old.mPassword
                }
                // Durable fallback: the old profile may be gone (pruned as
                // unreadable), but the password is also kept encrypted,
                // keyed by the stable config id — a reparse must never
                // drop it.
                if (profile.mPassword.isNullOrEmpty()) {
                    val stored = passwordStore.loadPassword(config.id)
                    if (stored.isNotEmpty()) profile.mPassword = stored
                }
                if (profile.mUsername.isNullOrEmpty()) profile.mUsername = config.ovpnUsername
                ProfileManager.saveProfile(appContext, profile)
                val updated = config.copy(
                    ovpnText = stripInlineAuthUserPass(cleanText),
                    ovpnUuid = profile.uuidString,
                    ovpnUsername = profile.mUsername ?: "",
                )
                tunnelRepository.save(updated)
                updated
            }
        }

    /** Save username/password on the profile (encrypted profile store). Returns false when nothing was saved. */
    suspend fun saveCredentials(config: TunnelConfig, username: String, password: String): Boolean =
        provideCredentials(config, username, password, rememberPassword = true)

    /**
     * Saved username/password for an OVPN tunnel, read back from the
     * encrypted profile store (Keystore-backed, never plaintext). The
     * password is only ever shown in the user's own config editor.
     *
     * The password is read from the profile first; when the profile has
     * none (it was rebuilt/pruned — its UUID changes on every reparse)
     * the durable store, keyed by the stable config id, is the
     * fallback, and the profile is healed from it so the core and later
     * loads see the password too.
     */
    suspend fun loadSavedCredentials(config: TunnelConfig): Pair<String, String> =
        withContext(Dispatchers.IO) {
            val profile = config.ovpnUuid?.let { ProfileManager.get(appContext, it) }
            val username = profile?.mUsername ?: config.ovpnUsername
            var password = profile?.mPassword ?: ""
            if (password.isEmpty()) {
                val stored = passwordStore.loadPassword(config.id)
                if (stored.isNotEmpty()) {
                    password = stored
                    if (profile != null) {
                        profile.mPassword = stored
                        if (profile.mUsername.isNullOrEmpty()) profile.mUsername = config.ovpnUsername
                        runCatching { ProfileManager.saveProfile(appContext, profile) }
                    }
                }
            }
            username to password
        }

    /**
     * Copy saved credentials from one OVPN tunnel's encrypted profile to
     * another's (used when duplicating a config: the stored .ovpn text
     * no longer carries inline credentials, so they are copied via the
     * encrypted profile store instead).
     */
    suspend fun copySavedCredentials(from: TunnelConfig, to: TunnelConfig) =
        withContext(Dispatchers.IO) {
            // Durable copy first: it must happen even when the profiles
            // are missing (that is exactly when the profile copy below
            // cannot run and the password would otherwise be lost).
            val stored = passwordStore.loadPassword(from.id)
            if (stored.isNotEmpty()) passwordStore.savePassword(to.id, stored)
            val fromUuid = from.ovpnUuid ?: return@withContext
            val toUuid = to.ovpnUuid ?: return@withContext
            val source = ProfileManager.get(appContext, fromUuid) ?: return@withContext
            val target = ProfileManager.get(appContext, toUuid) ?: return@withContext
            if (!source.mUsername.isNullOrEmpty()) target.mUsername = source.mUsername
            if (!source.mPassword.isNullOrEmpty()) target.mPassword = source.mPassword
            ProfileManager.saveProfile(appContext, target)
        }

    /**
     * Hand credentials to a waiting tunnel. With [rememberPassword] they
     * are saved on the encrypted profile (so the next connect needs no
     * prompt); otherwise they are only handed to the running management
     * thread for this session.
     */
    suspend fun provideCredentials(
        config: TunnelConfig,
        username: String,
        password: String,
        rememberPassword: Boolean,
    ): Boolean = withContext(Dispatchers.IO) {
        val uuid = config.ovpnUuid ?: return@withContext false
        if (rememberPassword) {
            // Fix9: when the stored profile is unreadable (e.g. it
            // was serialized by an older build whose obfuscated
            // class name no longer resolves), get() returns null and
            // the old code silently returned WITHOUT saving — the
            // user believed the credentials were saved and they were
            // not. Heal the profile from the stored .ovpn text first
            // (the same rebuild the connect path does), then save
            // the credentials onto the rebuilt profile. Any failure
            // is reported to the caller instead of swallowed.
            val saved = runCatching {
                var profile = ProfileManager.get(appContext, uuid)
                var effectiveConfig = config
                if (profile == null) {
                    val rebuilt = parseProfile(config.ovpnText, config.name)
                    ProfileManager.saveProfile(appContext, rebuilt)
                    val updated = config.copy(ovpnUuid = rebuilt.uuidString)
                    tunnelRepository.save(updated)
                    if (uuid != rebuilt.uuidString) {
                        ProfileManager.discardUnreadableProfile(appContext, uuid)
                    }
                    effectiveConfig = updated
                    profile = ProfileManager.get(appContext, rebuilt.uuidString)
                        ?: return@runCatching false
                }
                profile.mUsername = username
                profile.mPassword = password
                ProfileManager.saveProfile(appContext, profile)
                tunnelRepository.save(effectiveConfig.copy(ovpnUsername = username))
                // Durable copy, keyed by the stable config id: the
                // profile is keyed by a UUID that changes on every
                // reparse, and its file can be pruned as unreadable —
                // either silently drops the password. A blank password
                // removes the stored entry. Never throws (no-op when
                // the encrypted store is unavailable).
                passwordStore.savePassword(effectiveConfig.id, password)
                true
            }.getOrElse {
                Timber.e(it, "Failed to save OpenVPN credentials for ${config.name}")
                false
            }
            if (!saved) return@withContext false
        }
        // Also hand it to the waiting management thread, if any.
        ShuttleOpenVpn.setCachedPassword(
            appContext, uuid, PasswordCache.AUTHPASSWORD, password,
        )
        true
    }

    /** Start the OpenVPN tunnel for [config]. Assumes WG tunnels are stopped. */
    fun start(config: TunnelConfig) {
        scope.launch {
            startInternal(config)
        }
    }

    private suspend fun startInternal(config: TunnelConfig) {
        withContext(Dispatchers.IO) {
            try {
                var profile = config.ovpnUuid?.let { ProfileManager.get(appContext, it) }
                if (profile == null) {
                    // Profile store lost or unreadable (e.g. the stored
                    // profile was serialized by an older build whose
                    // obfuscated class name no longer resolves — the
                    // "oa7; class invalid for deserialization" failure):
                    // rebuild from the stored .ovpn text. The user's
                    // config itself is healthy and untouched.
                    val oldUuid = config.ovpnUuid
                    profile = parseProfile(config.ovpnText, config.name)
                    // Restore saved credentials onto the rebuilt profile:
                    // the .ovpn text never carries them, and the old
                    // profile (with them) is about to be discarded.
                    // Username comes from the DB, password from the
                    // durable store (keyed by the stable config id) —
                    // without this the rebuild silently drops the
                    // password and the next connect prompts for it.
                    if (profile.mUsername.isNullOrEmpty()) profile.mUsername = config.ovpnUsername
                    if (profile.mPassword.isNullOrEmpty()) {
                        val stored = passwordStore.loadPassword(config.id)
                        if (stored.isNotEmpty()) profile.mPassword = stored
                    }
                    ProfileManager.saveProfile(appContext, profile)
                    val updated = config.copy(ovpnUuid = profile.uuidString)
                    tunnelRepository.save(updated)
                    // Drop the unreadable old profile file(s) so they
                    // are never retried again. This touches ONLY the
                    // internal serialized profile — never the user's
                    // configs in the app DB.
                    if (oldUuid != null && oldUuid != profile.uuidString) {
                        ProfileManager.discardUnreadableProfile(appContext, oldUuid)
                    }
                }
                // Never launch with a UUID that does not resolve: verify
                // the profile is actually findable now (import/rebuild
                // bugs used to leave an orphaned UUID behind, and
                // LaunchVPN would then silently do nothing).
                val resolved = ProfileManager.get(appContext, profile.uuidString)
                if (resolved == null) {
                    Timber.e("OpenVPN profile ${profile.uuidString} does not resolve after save")
                    _state.value = OpenVpnState.Error(
                        appContext.getString(R.string.ovpn_profile_missing),
                    )
                    _activeTunnelId.value = null
                    activeConfig = null
                    return@withContext
                }
                profile = resolved
                // A dead server must fail fast (user 21:26): the
                // vendored default is connect-retry-max "-1" (retry
                // forever — the fix3 logs showed "Used x 101 tries"),
                // so one bad config spins the core for up to 300s.
                // Cap it at 5 attempts when the config sets no limit
                // of its own; the coordinator deadline is the backstop.
                // Only the internal profile copy is touched — the
                // stored .ovpn text is unchanged.
                if (profile.mConnectRetryMax.isNullOrEmpty() ||
                    profile.mConnectRetryMax == "-1"
                ) {
                    profile.mConnectRetryMax = CORE_CONNECT_RETRY_MAX.toString()
                    ProfileManager.saveProfile(appContext, profile)
                }
                userStopped = false
                generation++
                // This attempt supersedes any pending stop confirmation,
                // and a stop issued long ago is settled: its core is
                // dead or never ran, so its death can no longer be
                // confused with this attempt's.
                _stopConfirmed.value = true
                if (pendingStopGeneration != null &&
                    SystemClock.elapsedRealtime() - pendingStopAtMs > STALE_STOP_WINDOW_MS
                ) {
                    pendingStopGeneration = null
                }
                attemptGeneration = generation
                attemptStartedAtMs = SystemClock.elapsedRealtime()
                reconnectAttempts = 0
                everConnectedThisAttempt = false
                connectedAtMs = 0L
                ipFetchedForUuid = null
                activeConfig = config
                _activeTunnelId.value = config.id
                _state.value = OpenVpnState.Connecting("")
                armWatchdog()
                armDeadline()
                val intent = Intent(appContext, LaunchVPN::class.java).apply {
                    putExtra(LaunchVPN.EXTRA_KEY, profile.uuidString)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
            } catch (e: Exception) {
                Timber.e(e, "Failed to start OpenVPN tunnel ${config.name}")
                disarmWatchdog()
                _state.value = OpenVpnState.Error(e.message ?: "Failed to start OpenVPN")
                _activeTunnelId.value = null
                activeConfig = null
            }
        }
    }

    /** Disconnect the running OpenVPN tunnel (user-initiated). */
    fun stop() {
        userStopped = true
        generation++
        // A real stop expects a death confirmation: the coordinator
        // waits for the old core's LEVEL_NOTCONNECTED before starting
        // the next tunnel. A spurious stop (nothing running) has no
        // core to die, and its confirmation would never arrive — so
        // only track the stop when something was actually active.
        if (_activeTunnelId.value != null ||
            _state.value !is OpenVpnState.Disconnected
        ) {
            pendingStopGeneration = generation
            pendingStopAtMs = SystemClock.elapsedRealtime()
            _stopConfirmed.value = false
        }
        reconnectJob?.cancel()
        disarmWatchdog()
        disarmDeadline()
        ShuttleOpenVpn.stopVpn(appContext)
        // The UI must never depend on the :openvpn process to become
        // responsive again: stopVpn() is an async bind plus a
        // management "signal SIGINT" that silently no-ops when the
        // management socket is down, and the LEVEL_NOTCONNECTED
        // callback it relies on may never arrive — that is the 21:26
        // frozen hero (Cancel tapped, watchdog already disarmed, the
        // state stuck on "Connecting..." until force-close). The user
        // asked to stop, so clear the state NOW; the callback below
        // is idempotent (it just confirms Disconnected).
        _activeTunnelId.value = null
        activeConfig = null
        _state.value = OpenVpnState.Disconnected
    }

    fun isActive(tunnelId: Int): Boolean = _activeTunnelId.value == tunnelId

    /** Log lines buffered in the UI process (forwarded from :openvpn). */
    fun getLogLines(context: Context): List<String> {
        return try {
            ShuttleOpenVpn.getLogBuffer()
                ?.mapNotNull { item -> runCatching { item.getString(context) }.getOrNull() }
                ?.takeLast(MAX_LOG_LINES)
                ?: emptyList()
        } catch (e: Exception) {
            Timber.e(e, "Failed to read OpenVPN log buffer")
            emptyList()
        }
    }

    private fun parseProfile(text: String, name: String): VpnProfile {
        val parser = ConfigParser()
        parser.parseConfig(StringReader(text))
        val profile = parser.convertProfile()
        profile.mName = name
        return profile
    }

    private suspend fun uniqueTunnelName(base: String): String {
        var candidate = base
        var n = 2
        while (tunnelRepository.findByTunnelName(candidate) != null) {
            candidate = "$base ($n)"
            n++
        }
        return candidate
    }

    companion object {
        private const val MAX_RECONNECT_ATTEMPTS = 5
        private const val RECONNECT_BASE_DELAY_MS = 2000L
        private const val MAX_LOG_LINES = 500
        /** No word from the OpenVPN core for this long = failed start. */
        private const val WATCHDOG_TIMEOUT_MS = 45_000L
        /** Total bound on one connect attempt, retry chatter included. */
        private const val CONNECT_DEADLINE_MS = 120_000L
        /** Cap on the core's own connect retries (default is unlimited). */
        private const val CORE_CONNECT_RETRY_MAX = 5
        /**
         * A stop whose core death is still unconfirmed after this long
         * is settled: its core is long dead (or never ran).
         */
        private const val STALE_STOP_WINDOW_MS = 10_000L
        /**
         * A connect attempt younger than this cannot genuinely have
         * failed yet, so a NOTCONNECTED inside it belongs to the
         * previous core (switch), not to this attempt.
         */
        private const val STALE_NOTCONNECTED_WINDOW_MS = 3_000L

        private val INLINE_DIRECTIVES = setOf(
            "ca", "cert", "key", "tls-auth", "tls-crypt", "tls-crypt-v2",
            "crl-verify", "extra-certs", "secret",
        )

        /**
         * Username/password from a sibling credentials file
         * (`auth-user-pass login.txt` in the same ZIP). Returns null
         * when the config has no auth file or the file is not a
         * sibling — the user is then prompted at connect time.
         */
        private fun authFileCredentials(
            text: String,
            siblings: Map<String, String>,
        ): Pair<String, String>? {
            if (siblings.isEmpty()) return null
            for (rawLine in text.lines()) {
                val parts = rawLine.trim().split(Regex("\\s+"))
                if (parts.getOrNull(0)?.lowercase() != "auth-user-pass") continue
                if (parts.size < 2) return null
                val fileName = parts[1]
                val content =
                    siblings[fileName] ?: siblings[fileName.substringAfterLast('/')]
                        ?: return null
                val lines = content.lines().filter { it.isNotBlank() }
                if (lines.size >= 2) return lines[0].trim() to lines[1].trim()
                return null
            }
            return null
        }

        /**
         * External-file directives (`ca foo.crt`, …) still present after
         * inlining — i.e. files the .ovpn needs that were not supplied
         * (lone .ovpn without its ca.crt). Inline blocks (`<ca>…</ca>`)
         * and `[inline]` markers are not missing.
         */
        private fun missingExternalFiles(text: String): List<String> {
            val missing = mutableListOf<String>()
            for (rawLine in text.lines()) {
                val parts = rawLine.trim().split(Regex("\\s+"))
                val directive = parts.getOrNull(0)?.lowercase() ?: continue
                if (directive !in INLINE_DIRECTIVES || parts.size < 2) continue
                // crl-verify <dir> dir: a directory, not a missing file.
                if (directive == "crl-verify" && parts.size >= 3 && parts[2] == "dir") continue
                val arg = parts[1]
                if (arg != "[inline]" && !arg.startsWith("<")) missing += arg
            }
            return missing.distinct()
        }

        /** Replace an inline `<auth-user-pass>…</auth-user-pass>` block with a bare directive. */
        private fun stripInlineAuthUserPass(text: String): String =
            text.replace(
                Regex("(?is)<auth-user-pass>.*?</auth-user-pass>"),
                "auth-user-pass",
            )

        /**
         * Replace `ca foo.crt`-style references with inline blocks when the
         * referenced file is available in [siblings]. `auth-user-pass
         * <file>` is always reduced to a bare `auth-user-pass` — the
         * referenced file does not exist on the phone, and leaving the
         * path in would record a credentials file the core can never
         * read; the parser then marks the profile as username/password
         * and the user is prompted (or a sibling credentials file is
         * applied by the caller). Lines that already use inline blocks,
         * or reference files we do not have, are untouched (the caller
         * reports missing files instead of saving a broken profile).
         */
        fun inlineExternalFiles(text: String, siblings: Map<String, String>): String {
            val out = StringBuilder()
            for (rawLine in text.lines()) {
                val line = rawLine.trim()
                val parts = line.split(Regex("\\s+"))
                val directive = parts.getOrNull(0)?.lowercase()
                if (directive in INLINE_DIRECTIVES && parts.size >= 2) {
                    val fileName = parts[1]
                    val content = siblings[fileName] ?: siblings[fileName.substringAfterLast('/')]
                    if (content != null) {
                        out.append("<$directive>\n").append(content.trim()).append("\n</$directive>\n")
                        // tls-auth carries a key-direction as a 2nd argument.
                        if (directive == "tls-auth" && parts.size >= 3) {
                            out.append("key-direction ${parts[2]}\n")
                        }
                        continue
                    }
                }
                if (directive == "auth-user-pass" && parts.size >= 2) {
                    out.append("auth-user-pass\n")
                    continue
                }
                out.append(rawLine).append('\n')
            }
            return out.toString()
        }
    }
}
