package com.zaneschepke.wireguardautotunnel.ui.screens.settings.appearance.notifications

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Launch
import androidx.compose.material.icons.outlined.AltRoute
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zaneschepke.wireguardautotunnel.R
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingIcon
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsCard
import com.zaneschepke.wireguardautotunnel.ui.common.ShuttleSettingsDivider
import com.zaneschepke.wireguardautotunnel.ui.common.button.SurfaceRow
import com.zaneschepke.wireguardautotunnel.ui.common.button.SwitchWithDivider
import com.zaneschepke.wireguardautotunnel.ui.common.text.DescriptionText
import com.zaneschepke.wireguardautotunnel.ui.theme.LimeConnect
import com.zaneschepke.wireguardautotunnel.util.extensions.launchNotificationSettings
import com.zaneschepke.wireguardautotunnel.viewmodel.SettingsViewModel
import org.koin.androidx.compose.koinViewModel
import org.orbitmvi.orbit.compose.collectAsState

@Composable
fun NotificationsScreen(viewModel: SettingsViewModel = koinViewModel()) {
    val context = LocalContext.current
    val settingsState by viewModel.collectAsState()

    Column(
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.Top),
        modifier =
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().padding(top = 70.dp, bottom = 140.dp),
    ) {
        ShuttleSettingsCard {
            SurfaceRow(
                leading = { ShuttleSettingIcon(Icons.Outlined.Settings) },
                title = stringResource(R.string.settings),
                trailing = { modifier ->
                    Icon(Icons.AutoMirrored.Outlined.Launch, null, modifier = modifier)
                },
                onClick = { context.launchNotificationSettings() },
                containerColor = Color.Transparent,
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.BAKLAVA && !settingsState.isLoading) {
                val settings = settingsState.settings
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.NotificationsActive) },
                    title = stringResource(R.string.live_updates),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = settings.isLiveUpdatesEnabled,
                            onClick = { viewModel.setLiveUpdatesEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = { DescriptionText(stringResource(R.string.live_updates_desc)) },
                    onClick = { viewModel.setLiveUpdatesEnabled(!settings.isLiveUpdatesEnabled) },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.AltRoute) },
                    title = stringResource(R.string.notification_show_origin),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = settings.isNotificationOriginEnabled,
                            onClick = { viewModel.setNotificationOriginEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = {
                        DescriptionText(stringResource(R.string.notification_show_origin_desc))
                    },
                    onClick = {
                        viewModel.setNotificationOriginEnabled(
                            !settings.isNotificationOriginEnabled,
                        )
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.SwapVert) },
                    title = stringResource(R.string.notification_show_transfer),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = settings.isNotificationTransferEnabled,
                            onClick = { viewModel.setNotificationTransferEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = {
                        DescriptionText(stringResource(R.string.notification_show_transfer_desc))
                    },
                    onClick = {
                        viewModel.setNotificationTransferEnabled(
                            !settings.isNotificationTransferEnabled,
                        )
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.Replay) },
                    title = stringResource(R.string.notification_show_recovery),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = settings.isNotificationRecoveryEnabled,
                            onClick = { viewModel.setNotificationRecoveryEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = {
                        DescriptionText(stringResource(R.string.notification_show_recovery_desc))
                    },
                    onClick = {
                        viewModel.setNotificationRecoveryEnabled(
                            !settings.isNotificationRecoveryEnabled,
                        )
                    },
                    containerColor = Color.Transparent,
                )
                ShuttleSettingsDivider()
                SurfaceRow(
                    leading = { ShuttleSettingIcon(Icons.Outlined.WarningAmber) },
                    title = stringResource(R.string.notification_failure_tint),
                    trailing = { modifier ->
                        SwitchWithDivider(
                            checked = settings.isNotificationFailureTintEnabled,
                            onClick = { viewModel.setNotificationFailureTintEnabled(it) },
                            modifier = modifier,
                            checkedTrackColor = LimeConnect,
                            // No page behind this row — it only flips
                            // the switch (user 2026-11-25).
                            showChevron = false,
                        )
                    },
                    description = {
                        DescriptionText(stringResource(R.string.notification_failure_tint_desc))
                    },
                    onClick = {
                        viewModel.setNotificationFailureTintEnabled(
                            !settings.isNotificationFailureTintEnabled,
                        )
                    },
                    containerColor = Color.Transparent,
                )
            }
        }
    }
}
