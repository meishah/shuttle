pluginManagement {
    repositories {
        mavenLocal()
        google()
        // Google mirror of Maven Central: direct Maven Central stalls
        // on TLS handshake from Gradle in this sandbox (30s timeouts);
        // the Google mirror serves the same artifacts and works.
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
        gradlePluginPortal()
    }
}

// NOTE (local build adaptation): removed the
// org.gradle.toolchains.foojay-resolver-convention plugin (1.0.0).
// It only auto-detects/installs JDK toolchains via Foojay; the build
// already has JDK 21 installed and uses -Dorg.gradle.java.home, and
// its artifact could not be resolved in this sandbox.

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        mavenLocal()
        google()
        maven { url = uri("https://maven-central.storage-download.googleapis.com/maven2") }
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "WG Tunnel"

// Local dev
// includeBuild("../core") {
//	dependencySubstitution {
//		substitute(module("com.wgtunnel:backend"))
//			.using(project(":backend"))
//		substitute(module("com.wgtunnel:backend-android"))
//			.using(project(":backend"))
//		substitute(module("com.wgtunnel:backend-android-jni"))
//			.using(project(":backend-android-jni"))
//		substitute(module("com.wgtunnel:hevtunnel"))
//			.using(project(":hevtunnel"))
//		substitute(module("com.wgtunnel:parser"))
//			.using(project(":parser"))
//	}
// }

include(":app")

include(":logcatter")

include(":networkmonitor")

include(":pinger")
include(":openvpn")
