object Constants {
    const val APP_ID = "com.zaneschepke.wireguardautotunnel"
    const val APP_NAME = "shuttle"

    // build types
    const val RELEASE = "release"
    const val NIGHTLY = "nightly"
}
